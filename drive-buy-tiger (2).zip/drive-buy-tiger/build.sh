#!/usr/bin/env bash
# Builds drive-buy-tiger.jar from the sources. Needs a JDK 17 or newer (javac + jar), nothing else:
# the two libraries the game needs (SQLite driver, slf4j) are already in the folder lib/.
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v javac >/dev/null 2>&1 || ! command -v jar >/dev/null 2>&1; then
  echo "javac / jar not found. Please install a JDK 17 or newer (see README.md)." >&2
  exit 1
fi

for f in lib/sqlite-jdbc.jar lib/slf4j-api.jar db/schema.sql db/seed.sql; do
  if [ ! -f "$f" ]; then
    echo "$f is missing - the zip file seems to be incomplete (see README.md, chapter 'Folder contents')." >&2
    exit 1
  fi
done

trap 'echo "Build failed. Is your JDK version 17 or newer? Check with: javac -version" >&2' ERR

rm -rf build
mkdir -p build/classes/db
find src/main/java -name '*.java' > build/sources.txt
javac -encoding UTF-8 --release 17 -cp "lib/*" -d build/classes @build/sources.txt
cp -R src/main/resources/. build/classes/
cp db/schema.sql db/seed.sql build/classes/db/

# The libraries are found through the jar's Class-Path, so they must stay in lib/ next to the jar.
cat > build/manifest.mf <<'MANIFEST'
Main-Class: drivebuytiger.Main
Class-Path: lib/sqlite-jdbc.jar lib/slf4j-api.jar
Enable-Native-Access: ALL-UNNAMED
MANIFEST
jar --create --file drive-buy-tiger.jar --manifest build/manifest.mf -C build/classes .
rm -rf build

echo "Built drive-buy-tiger.jar - start the game with ./start.sh (fill the database with ./seed.sh)"
