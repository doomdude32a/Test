# Drive Buy Tiger v2.1 (Java version with SQLite database)

Collect waste in the jungle, scan it, sort it into the right bin and don't get caught by the three tigers.
This is the Java port of the browser prototype *Drive Buy Tiger v2* (Testspiel v2 · Team 5 · IP12-HS26).
It runs as a normal desktop window (Java Swing / Java2D) and needs **no internet and no web server**.
The in-game texts are German, like in the original.

**New in 2.1: the database.** The texts, items, quiz questions, help texts and slider definitions are no longer written
into the program. They are stored in a SQLite database, together with the scoreboard and your slider settings.
A small script (`seed.bat` / `seed.sh`) fills the database with the correct start values (chapter 4).
The game looks and plays exactly like before.

## 1. What you need

**Java 17 or newer.** A JRE is enough to play, a JDK is needed to rebuild the game from the sources.
Check what you have:

```
java -version
```

The first line must say version 17 or higher (e.g. `openjdk version "21.0.4"`). If the command is not found or the
version is lower, install a JDK (one-time):

| System | Command (or download from <https://adoptium.net>) |
|---|---|
| Windows 10/11 | `winget install EclipseAdoptium.Temurin.21.JDK` (then open a **new** terminal) |
| macOS | `brew install --cask temurin` |
| Ubuntu / Debian | `sudo apt install openjdk-21-jdk` (or `openjdk-17-jdk`) |
| Fedora | `sudo dnf install java-21-openjdk-devel` |

Nothing else has to be installed: the SQLite driver is included in the folder `lib/`.

## 2. Start the game

Unzip the folder anywhere (keep the files together, the folders `lib` and `db` must stay next to the jar).
The game is already built: `drive-buy-tiger.jar`.

**Windows**
- Double-click `start.bat`, or open a terminal in the folder and run `java -jar drive-buy-tiger.jar`.

**macOS**
- Double-click `start.command`. The first time, macOS may refuse files from the internet: right-click it, choose
  *Open*, then *Open* again. If it says the file is not executable, run
  `chmod +x start.command start.sh seed.sh build.sh` once in a terminal.
- Or in a terminal: `./start.sh`

**Linux**
- In a terminal in the folder: `./start.sh` (if needed first `chmod +x *.sh`).
- Or: `java -jar drive-buy-tiger.jar`

On the **first start** the game creates its database (`~/.drive-buy-tiger/drive-buy-tiger.db`) and fills it by itself,
you do not have to run anything else. Then a window with the title screen opens. Press **Enter** (or click) to continue
to the intro, press **Enter** again to start. Further tips appear in the game itself, at the moment they are useful.

## 3. How to play

| Key | Action |
|---|---|
| Arrow keys or W A S D | walk |
| Shift (hold) | sneak: slow and quiet, tigers don't hear you |
| Space | trigger the scanner when the bar is in the green zone |
| P or Esc | pause |
| Enter / Space | confirm in menus, quiz and scoreboard |
| Up / Down / Left / Right | choose in menus, quiz answers and the initials |

- Walk onto a wood piece (**?**). The scan starts ("JETZT SCANNEN!"): hit **Space** when the bar is in the green zone
  (points and extra time). Every scan picks the item up, and the picture of it shows in the *Hand* field at the top.
  A scan outside the green is very loud: tigers within 380 px (adjustable) come slowly to look. Moving away cancels the scan.
- You can carry only one item. Take it into the matching corner bin (glass, metal, plastic, general waste); the bins glow while
  you carry something. A wrong bin costs points and shows a short sentence why.
  The bin corners are safe zones where no tiger can catch you. Items in the middle of the map are worth more (×1.5 / ×2).
- Bushes hide you. Power-ups: lightning = turbo, eye = invisible. Metal in the right bin gives a short speed boost.
- Each tiger hunts differently: the *Pirscher* flanks you, the *Streuner* roams and rushes you, the *Schläfer* sleeps and listens.
- When time or lives run out there is a bonus question (right = more points), then the summary and today's scoreboard.
  The summary starts with **Das nimmst du mit**, then one card per bin with up to three stars: with 2 and 3 stars you unlock
  the bonus facts of that bin (the locked ones show a padlock).

The menu bar has **Spiel** (new game, back to menu, scoreboard), **Einstellungen** (*Regler fürs Spielkonzept*: all 18 tuning
controls such as time, lives, tiger speed and the noise radius of a missed scan) and **Hilfe** (controls, rules, what is new in v2,
sources of the facts). The game pauses automatically when the window loses focus or a dialog is open.

### What is new in v2 (the game itself)

- Hand display: a picture above the ranger and a big field at the top (*Hand: leer*).
- Slimmer top bar: no difficulty bar, multiplier or extra-time text.
- The scan stays, with a clear hint; a missed scan is louder and the tigers come slowly to look.
- Intro: one screen with three pictures, the rest as short tips in the game.
- Bins as containers with a symbol and a fill level; they glow while you carry an item.
- Items get a picture after the scan (on the map they stay a **?**).
- Ranger with hat, backpack and walking steps.
- Summary: *Das nimmst du mit* first, bonus facts unlock with stars.

## 4. The database

### Where it is

`~/.drive-buy-tiger/drive-buy-tiger.db` (Windows: `C:\Users\<name>\.drive-buy-tiger\drive-buy-tiger.db`). It sits in your
home folder on purpose, so the scoreboard survives when you unzip a new version of the game somewhere else.
Use another place with `java -Ddbt.dir=/some/folder -jar drive-buy-tiger.jar` (folder) or
`java -Ddbt.db=/some/file.db -jar drive-buy-tiger.jar` (complete file name).

### What is inside

| Table | Content | Written by |
|---|---|---|
| `ui_text` | all in-game texts (131 rows), with `{placeholders}` such as `{pts}` or `{n}` | seed |
| `item` | the 18 pieces of waste: name, picture key, bin, weight, CO₂ factor, PET / tricky flag, the "why" sentence | seed |
| `material` | names of the four bins | seed |
| `fact` | the facts per bin (level 0 = fact shown with the result, levels 1 and 2 = bonus facts unlocked by stars) | seed |
| `quiz_question`, `quiz_answer` | the 9 bonus questions with 3 answers each (`correct_no` = the right one) | seed |
| `tiger` | name, colour and description of the three tigers | seed |
| `control`, `rule`, `release_note`, `source` | the Help dialog: controls, rules, "new in v2", sources of the facts | seed |
| `tuning` | the 18 sliders: label, unit, minimum, maximum, step, default | seed |
| **`highscore`** | **the scoreboard** (initials, score, time) | **the game, while you play** |
| **`setting`** | **slider values you changed** (only those that differ from the default) | **the game** |
| `meta` | `content_version`, `schema_version`, `seeded_at`, `legacy_import` | seed |

The game reads the texts and content **once at the start** into memory, so playing never waits for the database.
The scoreboard keeps the last 300 entries; the in-game scoreboard shows today's entries, like the web prototype.

### What stays in the program (on purpose)

- the **points and the game rules** (scoring, tiger AI, speeds, map): the numbers you can tune are the sliders in the `tuning` table,
- the **drawing**: colours, shapes, the pictures of the items (a new item gets a plain brown dot until a picture with its
  `icon` key is added in `Renderer.itemIcon`), the order and colours of the four bins,
- symbols (`?`, `!`, `×`, `★`, the padlock), the HTML layout of the help window and number/date formats,
- the error window "Drive Buy Tiger konnte die Datenbank nicht öffnen oder füllen" (it cannot come out of a database that does not open),
- technical messages for the console (English).

### Fill it: seed.bat / seed.sh

`db/schema.sql` creates the tables, `db/seed.sql` contains **all start values** as readable SQL (`INSERT` lines).
The script applies both in one step; if anything fails, nothing is changed.

```
Windows        seed.bat
macOS / Linux  ./seed.sh
```

| Call | Effect |
|---|---|
| `seed.bat` | creates the database if needed and replaces texts, items, quiz and slider defaults with `db/seed.sql`. **The scoreboard and your saved sliders are kept.** |
| `seed.bat --reset` | deletes the database file first: really everything starts from zero, the scoreboard is gone |
| `seed.bat --db FILE` | uses another database file (a test copy, for example) |
| `seed.bat --help` | short help |

Without the scripts: `java -jar drive-buy-tiger.jar --seed [--reset] [--db FILE]` does the same.
Close the game before you run it (it keeps the texts it loaded at its start).

### Change a text, a question or a value

1. Close the game.
2. Open `db/seed.sql` in a text editor (save as **UTF-8**) and edit the line, for example
   `INSERT INTO ui_text ... VALUES ('quiz.right', 'quiz', 'Richtig! Deine Punkte steigen.', NULL);`.
   An apostrophe inside a text is written twice (`''`). Keep the `{placeholders}` of a text; the last column `note` of
   `ui_text` lists what each one means.
3. Raise the number in `INSERT OR REPLACE INTO meta (key, value) VALUES ('content_version', '1');` by one.
4. Start the game: it sees the new `content_version` and refills the content tables by itself (or run `seed.bat`, which always refills).
   No rebuild is needed: the `db` folder next to the jar is used before the copy that is packed inside the jar.

Texts and values are replaced from `db/seed.sql` every time, so **change them there, not inside the database file**.
The scoreboard (`highscore`) and `setting` are never touched by a normal seed; you can look at them or clean them with any
SQLite tool while the game is closed, e.g. *DB Browser for SQLite* (<https://sqlitebrowser.org>) or in a terminal
`sqlite3 ~/.drive-buy-tiger/drive-buy-tiger.db "SELECT name, score FROM highscore ORDER BY score DESC LIMIT 10;"`.
A backup is simply a copy of the `.db` file (game closed).

### Scoreboard and settings from the old version

If the folder of the database (normally `~/.drive-buy-tiger/`) already contains the files `highscores.txt` and
`settings.properties` of version 2.0, their content is copied into the database once, at the first start
(the files themselves are left as they are).

## 5. Build it yourself

The sources are in `src/main/java/drivebuytiger/`, the fonts in `src/main/resources/fonts/`.

- **Without Maven (needs only a JDK 17+):** run `./build.sh` (macOS/Linux) or double-click `build.bat` (Windows).
  This compiles everything and recreates `drive-buy-tiger.jar`. The jar finds the two libraries through `lib/` next to it.
- **With Maven (optional):** `mvn package` creates `target/drive-buy-tiger.jar` and copies the libraries to `target/lib/`;
  run it with `java -jar target/drive-buy-tiger.jar`. The `pom.xml` mainly serves for importing the project into an IDE.
  *(Written carefully, but not run here: the environment this version was prepared in could not download Maven plugins.)*

**IDE:** open the folder (or `pom.xml`) in IntelliJ IDEA, Eclipse or VS Code (Extension Pack for Java), set the project
SDK to 17 or newer (without `pom.xml` also add `lib/sqlite-jdbc.jar` and `lib/slf4j-api.jar` as libraries) and run the class
`drivebuytiger.Main`. Run it with the project folder as working directory, then `db/seed.sql` is found. On Java 24 or newer
add the VM option `--enable-native-access=ALL-UNNAMED` (the jar sets this itself).

### Folder contents

| Path | Purpose |
|---|---|
| `drive-buy-tiger.jar` | the game, ready built |
| `lib/` | `sqlite-jdbc.jar` and `slf4j-api.jar` with their licences, see chapter 8. Must stay next to the jar |
| `db/schema.sql`, `db/seed.sql` | the tables and all start values (chapter 4) |
| `start.bat`, `start.sh`, `start.command` | start the game (Windows / Linux + macOS / macOS double-click) |
| `seed.bat`, `seed.sh` | create and fill the database |
| `build.bat`, `build.sh` | rebuild the jar |
| `src/` | the Java sources and the fonts |
| `pom.xml` | Maven project file (optional) |

### Project layout

| File | Purpose |
|---|---|
| `Main`, `GameWindow`, `GamePanel`, `Dialogs` | window, menu bar, game loop and input, dialogs |
| `Session` | menu → intro → play → bonus question → summary → scoreboard |
| `Game` | all rules: player, scanning, bins, tigers (AI), power-ups, time pressure |
| `GameMap`, `Entity`, `Material` | map, obstacles, navigation grid, shared types |
| `Renderer`, `Txt`, `Fonts`, `Palette` | all drawing (Java2D), text and fonts, colours |
| `Summary` | star rules and texts of the summary screen |
| `Db`, `SqlScript`, `Seeder`, `Legacy` | database access, reading the SQL scripts, the seed tool (`--seed`), import of the old files |
| `Content`, `Texts` | loads items, quiz, facts, help and slider definitions and all texts from the database at the start |
| `Settings`, `Tune`, `HighScores`, `Input` | slider values (table `setting`), scoreboard (table `highscore`), keyboard state |
| `org/slf4j/impl/StaticLoggerBinder` | switches off the logging of the SQLite driver (otherwise it prints a warning) |

## 6. Troubleshooting

- **`UnsupportedClassVersionError` or "class file version 61"**: your Java is older than 17. Install a newer JDK (see 1.).
- **`java` is not found (Windows)**: close and reopen the terminal after installing, or reboot once.
- **Nothing happens when double-clicking `start.bat`**: open a terminal in the folder and run `java -jar drive-buy-tiger.jar`
  to see the error message.
- **Window "Drive Buy Tiger konnte die Datenbank nicht öffnen oder füllen"**: the reason is written in the window.
  Usually the folder `lib` with `sqlite-jdbc.jar` and `slf4j-api.jar` is not next to `drive-buy-tiger.jar`,
  or `db/seed.sql` contains a mistake. `seed.bat` shows the failing statement; `seed.bat --reset` starts with a fresh database.
- **"database is locked"**: another program (a second game, an open database tool) is writing to the file. Close it.
- **The SQLite driver cannot load its native part**: it unpacks it into the temporary folder. If antivirus software or the system
  blocks that folder, use another one: `java -Djava.io.tmpdir=/some/folder -jar drive-buy-tiger.jar`.
- **A text shows as `[some.key]`**: the row is missing in `ui_text`. Run `seed.bat`.
- **The window does not react to keys**: click once into the game field so that it gets the keyboard focus.
- **Linux, flickering or garbled graphics**: try `java -Dsun.java2d.opengl=true -jar drive-buy-tiger.jar`
  (or `-Dsun.java2d.xrender=false`).
- **Window or text too small on a high-resolution screen**: Java scales automatically; if it does not,
  try `java -Dsun.java2d.uiScale=2 -jar drive-buy-tiger.jar`.

Tested with OpenJDK 21 on Linux (headless replay of recorded runs, window test on a virtual screen). The `.bat` and macOS scripts
follow the same steps but were not run on Windows or macOS.

## 7. Differences from the browser prototype

- Desktop keyboard and mouse only: the on-screen touch joystick and touch buttons of the web page are not part of this version.
- The tuning sliders, help and scoreboard list are in the menu bar and dialogs instead of a side panel.
- Highscores and slider values are stored in the SQLite database instead of the browser's local storage, and the bonus time shown
  after a scan is rounded cleanly (the prototype could print rounding noise).
- The summary screen is drawn like the web page at its usual size (1300 px wide stage). When a run has so many open bonus facts
  that the page would scroll, the Java version shrinks the screen slightly so that everything fits without scrolling.
- The star and padlock symbols of the summary are drawn as shapes, not as font characters, so they look the same on every system.
- In the web page the intro screen leaves a rounded line cap set for later drawing (it is not reset), which slightly rounds the ends
  of a few lines afterwards. The Java version always uses the line ends the drawing code intends.
- Fonts are bundled (Fredoka and Nunito Sans, SIL Open Font License, see `src/main/resources/fonts/OFL-*.txt`),
  so no internet connection is needed.

## 8. Libraries and licences

| File | What | Licence |
|---|---|---|
| `lib/sqlite-jdbc.jar` | SQLite driver for Java, version 3.45.3.0 (contains SQLite 3.45.3 for Windows, macOS and Linux) | Apache-2.0; SQLite itself is public domain |
| `lib/slf4j-api.jar` | logging interface the driver needs, version 1.7.36 | MIT |

The licence texts and checksums are in `lib/`. **Where the two jars come from:** they are the unmodified released jars of the
versions named above, but Maven Central could not be reached when this version was prepared, so the copies were taken from other
official distributions (the sqlite-jdbc jar bundled in the Liquibase 4.28.1 package on npm, slf4j-api from Apache Maven 3.9.11).
To be sure, download both files from Maven Central, compare the checksums given in `lib/README.txt` and replace the files if you like
(the file names must stay `sqlite-jdbc.jar` and `slf4j-api.jar`).
