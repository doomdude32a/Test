#!/usr/bin/env bash
# macOS: double-click this file in Finder to start Drive Buy Tiger.
cd "$(dirname "$0")" || exit 1
exec ./start.sh "$@"
