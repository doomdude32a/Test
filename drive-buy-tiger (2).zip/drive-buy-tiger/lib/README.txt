Libraries of Drive Buy Tiger (nothing else is needed at run time)
==================================================================

sqlite-jdbc.jar   SQLite database driver for Java (xerial sqlite-jdbc 3.45.3.0, contains SQLite 3.45.3 for
                  Windows / macOS / Linux). License: Apache-2.0, see LICENSE-sqlite-jdbc.txt
                  and LICENSE-sqlite-jdbc-zentus.txt. SQLite itself is public domain.
slf4j-api.jar     Logging interface that the SQLite driver needs (slf4j-api 1.7.36). License: MIT, see LICENSE-slf4j-api.txt.
                  (The game binds it to "no logging" with the small class org.slf4j.impl.StaticLoggerBinder.)

Check of the files in this folder:
  sqlite-jdbc.jar  SHA-256 cd55db695548e9b1ba38070109f809052e9ed377256f6218b9e4cd4ee603ab55
                   SHA-1   06ae68e5fbf0d184c2f8191818fbe66e4dd70e14
  slf4j-api.jar    SHA-256 d3ef575e3e4979678dc01bf1dcce51021493b4d11fb7f1be8ad982877c16a1c0
                   SHA-1   6c62681a2f655b49963a5983b8b0950a6120ae14

Where these two files come from: they are the released, unmodified jars of
  https://repo1.maven.org/maven2/org/xerial/sqlite-jdbc/3.45.3.0/sqlite-jdbc-3.45.3.0.jar
  https://repo1.maven.org/maven2/org/slf4j/slf4j-api/1.7.36/slf4j-api-1.7.36.jar
but Maven Central could not be reached when this project was prepared, so the copies were taken from other official
distributions (the sqlite-jdbc jar that is bundled in the Liquibase 4.28.1 package on npm, slf4j-api from Apache Maven 3.9.11).
If you want to be sure: download both files from the addresses above (each has a .sha1 file next to it), compare the
checksums, and replace the files in this folder. The names must stay sqlite-jdbc.jar and slf4j-api.jar (the jar of the game lists them).
Any newer sqlite-jdbc 3.x jar works as well.
