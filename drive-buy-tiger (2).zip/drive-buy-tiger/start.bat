@echo off
rem Starts Drive Buy Tiger on Windows. Needs Java 17 or newer.
setlocal
cd /d "%~dp0"

where javaw >nul 2>nul
if errorlevel 1 (
  echo Java was not found. Please install a JDK or JRE 17 or newer, see README.md
  pause
  exit /b 1
)

if not exist drive-buy-tiger.jar call build.bat

start "" javaw -jar drive-buy-tiger.jar %*
