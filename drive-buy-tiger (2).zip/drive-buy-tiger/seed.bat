@echo off
rem Creates the SQLite database of Drive Buy Tiger and fills it with the start data (Windows). Needs Java 17 or newer.
rem
rem   seed.bat             create / refill the database from db\schema.sql + db\seed.sql
rem                        (texts, items, quiz, slider defaults are replaced; the scoreboard and saved slider values are kept)
rem   seed.bat --reset     start from zero: the database file is deleted first (scoreboard and saved sliders are lost, too)
rem   seed.bat --db FILE   use another database file
rem   seed.bat --help
rem
rem The game does the same by itself on its first start, so running this is only needed after you edited db\seed.sql
rem without raising its content_version, or to start with a fresh database. Close the game before you run it.
setlocal
cd /d "%~dp0"

where java >nul 2>nul
if errorlevel 1 (
  echo Java was not found. Please install a JDK or JRE 17 or newer, see README.md
  pause
  exit /b 1
)

if not exist drive-buy-tiger.jar call build.bat
if not exist drive-buy-tiger.jar exit /b 1

java -jar drive-buy-tiger.jar --seed %*
set RESULT=%ERRORLEVEL%
echo.
pause
exit /b %RESULT%
