@echo off
rem Builds drive-buy-tiger.jar from the sources. Needs a JDK 17 or newer (javac + jar), nothing else:
rem the two libraries the game needs (SQLite driver, slf4j) are already in the folder lib\.
setlocal enabledelayedexpansion
cd /d "%~dp0"

where javac >nul 2>nul
if errorlevel 1 (
  echo javac was not found. Please install a JDK 17 or newer, see README.md
  pause
  exit /b 1
)

for %%f in (lib\sqlite-jdbc.jar lib\slf4j-api.jar db\schema.sql db\seed.sql) do (
  if not exist %%f (
    echo %%f is missing - the zip file seems to be incomplete, see README.md, chapter "Folder contents"
    pause
    exit /b 1
  )
)

if exist build rmdir /s /q build
mkdir build\classes\db

set SOURCES=
for %%f in (src\main\java\drivebuytiger\*.java) do set SOURCES=!SOURCES! "%%f"
for %%f in (src\main\java\org\slf4j\impl\*.java) do set SOURCES=!SOURCES! "%%f"

javac -encoding UTF-8 --release 17 -cp "lib\*" -d build\classes !SOURCES!
if errorlevel 1 goto fail
xcopy /E /I /Y /Q src\main\resources build\classes >nul
if errorlevel 1 goto fail
copy /Y db\schema.sql build\classes\db >nul
if errorlevel 1 goto fail
copy /Y db\seed.sql build\classes\db >nul
if errorlevel 1 goto fail

rem The libraries are found through the jar's Class-Path, so they must stay in lib\ next to the jar.
(
  echo Main-Class: drivebuytiger.Main
  echo Class-Path: lib/sqlite-jdbc.jar lib/slf4j-api.jar
  echo Enable-Native-Access: ALL-UNNAMED
) > build\manifest.mf
jar --create --file drive-buy-tiger.jar --manifest build\manifest.mf -C build\classes .
if errorlevel 1 goto fail
rmdir /s /q build

echo Built drive-buy-tiger.jar - start the game with start.bat (fill the database with seed.bat)
pause
exit /b 0

:fail
echo.
echo Build failed. Is your JDK version 17 or newer? Check with: javac -version
pause
exit /b 1
