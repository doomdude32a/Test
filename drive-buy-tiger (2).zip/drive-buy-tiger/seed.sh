#!/usr/bin/env bash
# Creates the SQLite database of Drive Buy Tiger and fills it with the start data (macOS and Linux). Needs Java 17 or newer.
#
#   ./seed.sh            create / refill the database from db/schema.sql + db/seed.sql
#                        (texts, items, quiz, slider defaults are replaced; the scoreboard and saved slider values are kept)
#   ./seed.sh --reset    start from zero: the database file is deleted first (scoreboard and saved sliders are lost, too)
#   ./seed.sh --db FILE  use another database file
#   ./seed.sh --help
#
# The game does the same by itself on its first start, so running this is only needed after you edited db/seed.sql
# without raising its content_version, or to start with a fresh database. Close the game before you run it.
cd "$(dirname "$0")" || exit 1

if ! command -v java >/dev/null 2>&1; then
  echo "Java was not found. Please install a JDK or JRE 17 or newer (see README.md)." >&2
  exit 1
fi

if [ ! -f drive-buy-tiger.jar ]; then
  echo "drive-buy-tiger.jar is missing, building it first ..."
  ./build.sh || exit 1
fi

exec java -jar drive-buy-tiger.jar --seed "$@"
