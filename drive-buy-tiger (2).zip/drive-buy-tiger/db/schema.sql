-- Drive Buy Tiger: database schema (SQLite)
--
-- Three groups of tables:
--   1. content tables  : texts, items, quiz, tuning defaults ... they are DROPPED and re-created by every seed run
--                        (db/seed.sql fills them), so they can never be out of date.
--   2. dynamic tables  : highscore, setting. Written while playing, NEVER dropped (only "seed.bat --reset" wipes them).
--   3. meta            : version numbers.
--
-- One statement after the other, separated by ";". Comments start with "--".

-- ---------------------------------------------------------------- 1. content tables (children first, parents last)

DROP TABLE IF EXISTS quiz_answer;
DROP TABLE IF EXISTS quiz_question;
DROP TABLE IF EXISTS fact;
DROP TABLE IF EXISTS item;
DROP TABLE IF EXISTS tiger;
DROP TABLE IF EXISTS control;
DROP TABLE IF EXISTS rule;
DROP TABLE IF EXISTS release_note;
DROP TABLE IF EXISTS source;
DROP TABLE IF EXISTS tuning;
DROP TABLE IF EXISTS ui_text;
DROP TABLE IF EXISTS material;

-- The four bins. id = name of the Java enum "Material" (the enum also decides the order of the bins and their colours).
CREATE TABLE material (
    id     TEXT PRIMARY KEY,
    label  TEXT NOT NULL                          -- name shown in the game
);

-- A piece of waste. The row order (id) matters: the random pick uses the position in this list.
CREATE TABLE item (
    id          INTEGER PRIMARY KEY,
    name        TEXT    NOT NULL UNIQUE,
    icon        TEXT    NOT NULL,                 -- key of the drawing routine (Renderer.itemIcon)
    material    TEXT    NOT NULL REFERENCES material (id),
    grams       INTEGER NOT NULL CHECK (grams > 0),          -- estimated weight
    co2_per_kg  REAL    NOT NULL CHECK (co2_per_kg >= 0),    -- kg CO2 saved per kg recycled, 0 = unknown
    is_pet      INTEGER NOT NULL CHECK (is_pet IN (0, 1)),
    is_tricky   INTEGER NOT NULL CHECK (is_tricky IN (0, 1)), -- tricky items appear more often when the time runs out
    why         TEXT    NOT NULL                  -- one sentence: why does it belong into this bin
);

-- Facts for the summary. level 0 is shown to everybody, level 1 unlocks with 2 stars, level 2 with 3 stars.
CREATE TABLE fact (
    material  TEXT    NOT NULL REFERENCES material (id),
    level     INTEGER NOT NULL CHECK (level BETWEEN 0 AND 2),
    text      TEXT    NOT NULL,
    PRIMARY KEY (material, level)
);

-- Bonus questions at the end of a run.
CREATE TABLE quiz_question (
    id          INTEGER PRIMARY KEY,
    question    TEXT    NOT NULL,
    correct_no  INTEGER NOT NULL CHECK (correct_no >= 1)      -- number of the right answer (1 = first)
);

CREATE TABLE quiz_answer (
    question_id  INTEGER NOT NULL REFERENCES quiz_question (id),
    answer_no    INTEGER NOT NULL CHECK (answer_no >= 1),
    text         TEXT    NOT NULL,
    PRIMARY KEY (question_id, answer_no)
);

-- The tigers. kind = name of the Java enum "Game.Kind".
CREATE TABLE tiger (
    kind         TEXT    PRIMARY KEY,
    sort_no      INTEGER NOT NULL UNIQUE,
    name         TEXT    NOT NULL,                -- also written below the tiger in the game
    color        TEXT    NOT NULL,                -- #RRGGBB
    description  TEXT    NOT NULL                 -- help dialog
);

-- Help dialog: keys, rules, "what is new", sources of the facts.
CREATE TABLE control (
    sort_no      INTEGER PRIMARY KEY,
    keys         TEXT NOT NULL,
    description  TEXT NOT NULL
);

CREATE TABLE rule (
    sort_no  INTEGER PRIMARY KEY,
    text     TEXT NOT NULL
);

CREATE TABLE release_note (
    sort_no  INTEGER PRIMARY KEY,
    text     TEXT NOT NULL
);

CREATE TABLE source (
    sort_no  INTEGER PRIMARY KEY,
    title    TEXT NOT NULL,
    url      TEXT NOT NULL
);

-- The adjustable game parameters ("Regler fürs Spielkonzept"): label, range, step and default.
-- key = Tune.key in the Java code. is_toggle 1 = checkbox (0/1), 0 = slider.
CREATE TABLE tuning (
    key            TEXT    PRIMARY KEY,
    sort_no        INTEGER NOT NULL UNIQUE,
    label          TEXT    NOT NULL,
    unit           TEXT    NOT NULL,              -- shown behind the value, e.g. ' s'
    min_value      REAL    NOT NULL,
    max_value      REAL    NOT NULL,
    step_value     REAL    NOT NULL CHECK (step_value > 0),
    default_value  REAL    NOT NULL,
    is_toggle      INTEGER NOT NULL CHECK (is_toggle IN (0, 1)),
    CHECK (min_value < max_value AND default_value BETWEEN min_value AND max_value)
);

-- Every other text of the game (HUD, menus, feedback, dialogs ...). {name} marks a value the program fills in.
-- Keys ending in _html may contain HTML (help dialog).
CREATE TABLE ui_text (
    key    TEXT PRIMARY KEY,
    scope  TEXT NOT NULL,                         -- where it is used: game, hud, scan, quiz, menu, intro, summary, board, dialog, window
    value  TEXT NOT NULL,
    note   TEXT                                   -- meaning of the {placeholders}
);

-- ---------------------------------------------------------------- 2. dynamic tables (kept between seed runs)

-- Scoreboard. played_at = milliseconds since 1970-01-01 (UTC).
CREATE TABLE IF NOT EXISTS highscore (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT    NOT NULL,                  -- three initials
    score      INTEGER NOT NULL,
    played_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_highscore_played ON highscore (played_at);

-- Values the player changed in the tuning dialog (only the ones that differ from tuning.default_value).
CREATE TABLE IF NOT EXISTS setting (
    key    TEXT PRIMARY KEY,
    value  REAL NOT NULL
);

-- ---------------------------------------------------------------- 3. meta

CREATE TABLE IF NOT EXISTS meta (
    key    TEXT PRIMARY KEY,
    value  TEXT NOT NULL
);

INSERT OR REPLACE INTO meta (key, value) VALUES ('schema_version', '1');
