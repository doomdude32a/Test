package drivebuytiger;

/** Anything with a position on the map (player, tigers, trash, power-ups). */
public class Entity {
    public double x;
    public double y;

    public Entity() {}

    public Entity(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double dist(Entity o) {
        return Math.hypot(x - o.x, y - o.y);
    }
}
