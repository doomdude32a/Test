package drivebuytiger;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Taskbar;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

/** Main window: the game canvas plus a small menu bar (new game, scoreboard, tuning sliders, help). */
@SuppressWarnings("serial")
public final class GameWindow extends JFrame {
    private final Session ses;
    private final GamePanel panel;

    public GameWindow(Settings settings, HighScores scores) {
        super(Texts.t("win.title"));
        ses = new Session(settings, scores);
        panel = new GamePanel(ses);

        // window size: 1560 x 1050 aspect, as large as comfortable for the screen
        Rectangle screen = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
        int h = Math.max(420, Math.min(840, screen.height - 160));
        int w = (int) Math.round(h * 1560.0 / 1050.0);
        if (w > screen.width - 40) {
            w = screen.width - 40;
            h = (int) Math.round(w * 1050.0 / 1560.0);
        }
        panel.setPreferredSize(new Dimension(w, h));
        setLayout(new BorderLayout());
        add(panel, BorderLayout.CENTER);
        setJMenuBar(buildMenuBar());
        List<Image> icons = icons();
        setIconImages(icons);
        dockIcon(icons.get(icons.size() - 1));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
        setMinimumSize(new Dimension(640, 480));
        setLocationRelativeTo(null);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                settings.save();
            }
        });
        // the keyboard always belongs to the game, also after a dialog was closed or the window was re-activated
        addWindowFocusListener(new WindowAdapter() {
            @Override
            public void windowGainedFocus(WindowEvent e) {
                focusGame();
            }
        });
        panel.start();
    }

    /** macOS shows the icon of the Java launcher in the Dock unless it is set explicitly. */
    private static void dockIcon(Image icon) {
        try {
            if (Taskbar.isTaskbarSupported() && Taskbar.getTaskbar().isSupported(Taskbar.Feature.ICON_IMAGE)) {
                Taskbar.getTaskbar().setIconImage(icon);
            }
        } catch (UnsupportedOperationException | SecurityException ignored) {
            // not available on this system: the window icon is enough
        }
    }

    /** Gives the keyboard focus to the game canvas. */
    public void focusGame() {
        panel.requestFocusInWindow();
    }

    private JMenuBar buildMenuBar() {
        int mask = Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx();
        JMenuBar bar = new JMenuBar();

        JMenu game = new JMenu(Texts.t("win.menu.game"));
        game.add(item(Texts.t("win.menu.game.new"), KeyStroke.getKeyStroke(KeyEvent.VK_N, mask), e -> {
            ses.startGame();
            focusGame();
        }));
        game.add(item(Texts.t("win.menu.game.to_menu"), null, e -> {
            ses.toMenu();
            focusGame();
        }));
        game.add(item(Texts.t("win.menu.game.board"), null, e -> {
            ses.pauseIfPlaying();
            Dialogs.showScoreboard(this, ses);
            focusGame();
        }));
        game.addSeparator();
        game.add(item(Texts.t("win.menu.game.quit"), KeyStroke.getKeyStroke(KeyEvent.VK_Q, mask), e -> {
            ses.settings.save();
            System.exit(0);
        }));
        bar.add(game);

        JMenu tune = new JMenu(Texts.t("win.menu.tune"));
        tune.add(item(Texts.t("win.menu.tune.sliders"), null, e -> {
            ses.pauseIfPlaying();
            Dialogs.showSettings(this, ses, () -> {
                ses.startGame();
                focusGame();
            });
            focusGame();
        }));
        bar.add(tune);

        JMenu help = new JMenu(Texts.t("win.menu.help"));
        help.add(item(Texts.t("win.menu.help.rules"), KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0), e -> {
            ses.pauseIfPlaying();
            Dialogs.showHelp(this);
            focusGame();
        }));
        bar.add(help);
        return bar;
    }

    private static JMenuItem item(String text, KeyStroke key, ActionListener action) {
        JMenuItem it = new JMenuItem(text);
        if (key != null) {
            it.setAccelerator(key);
        }
        it.addActionListener(action);
        return it;
    }

    // ---- simple tiger-face icon, drawn in code ----

    private static List<Image> icons() {
        List<Image> list = new ArrayList<>();
        for (int size : new int[] {16, 32, 64, 128}) {
            list.add(icon(size));
        }
        return list;
    }

    private static BufferedImage icon(int size) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.scale(size / 64.0, size / 64.0);
        g.setColor(new Color(0x143D22));
        g.fill(new RoundRectangle2D.Double(0, 0, 64, 64, 18, 18));
        g.setColor(Palette.TIGER);
        g.fill(new Ellipse2D.Double(14, 6, 16, 16));
        g.fill(new Ellipse2D.Double(34, 6, 16, 16));
        g.fill(new Ellipse2D.Double(9, 12, 46, 44));
        g.setColor(Palette.INK_DARK);
        g.setStroke(new java.awt.BasicStroke(3f, java.awt.BasicStroke.CAP_ROUND, java.awt.BasicStroke.JOIN_ROUND));
        g.draw(new Line2D.Double(32, 14, 32, 24));
        g.draw(new Line2D.Double(22, 16, 25, 24));
        g.draw(new Line2D.Double(42, 16, 39, 24));
        g.draw(new Line2D.Double(11, 32, 19, 34));
        g.draw(new Line2D.Double(53, 32, 45, 34));
        g.fill(new Ellipse2D.Double(20, 30, 6, 7));
        g.fill(new Ellipse2D.Double(38, 30, 6, 7));
        g.setColor(new Color(0xFFE7BF));
        g.fill(new Ellipse2D.Double(24, 40, 16, 11));
        g.setColor(Palette.INK_DARK);
        g.fill(new Ellipse2D.Double(29, 42, 6, 4));
        g.dispose();
        return img;
    }
}
