package drivebuytiger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Map geometry (obstacles, bushes, bins), collision, line of sight and the navigation grid used by the tigers. */
public final class GameMap {
    private GameMap() {}

    /** Height of the HUD strip, play field size and total logical canvas size. */
    public static final int HUD = 120, PW = 1560, PH = 930, W = PW, H = HUD + PH;
    /** Scale from the 1200x720 design grid of the prototype to the play field. */
    public static final double KX = PW / 1200.0, KY = PH / 720.0;
    /** Radius of player and tiger. */
    public static final double RP = 13, RT = 16;
    /** Size of a bin (safe) zone. */
    public static final double BW = 200, BH = 130;
    public static final double CAMP_X = PW / 2.0, CAMP_Y = PH - 62;

    public record Rect(double x, double y, double w, double h) {}

    public record Bush(double x, double y, double r) {}

    public record Bin(Material mat, Rect rect) {}

    public static final List<Rect> OBS;
    public static final List<Bush> BUSHES;
    public static final List<Bin> BINS;
    /** Obstacles plus bin zones: tigers cannot enter either. */
    public static final List<Rect> TOBS;

    // ---- navigation grid ----
    public static final int CS = 30, GC = PW / CS, GR = PH / CS;
    public static final int[][] DIRS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
    private static final boolean[] BLOCK = new boolean[GC * GR];

    static {
        double[][] o0 = {
            {240, 130, 220, 56}, {740, 130, 220, 56}, {120, 290, 60, 150}, {1020, 290, 60, 150},
            {300, 320, 160, 56}, {740, 320, 160, 56}, {560, 250, 80, 150}, {240, 520, 220, 56}, {740, 520, 220, 56}
        };
        List<Rect> obs = new ArrayList<>();
        for (double[] o : o0) {
            obs.add(new Rect(Math.round(o[0] * KX), Math.round(o[1] * KY), Math.round(o[2] * KX), Math.round(o[3] * KY)));
        }
        OBS = List.copyOf(obs);

        double[][] b0 = {{380, 250, 38}, {820, 250, 38}, {600, 470, 40}, {600, 70, 36}, {110, 560, 36}, {1090, 560, 36}};
        List<Bush> bushes = new ArrayList<>();
        for (double[] b : b0) {
            bushes.add(new Bush(Math.round(b[0] * KX), Math.round(b[1] * KY), Math.round(b[2] * 1.1)));
        }
        BUSHES = List.copyOf(bushes);

        BINS = List.of(
            new Bin(Material.GLAS, new Rect(0, 0, BW, BH)),
            new Bin(Material.METALL, new Rect(PW - BW, 0, BW, BH)),
            new Bin(Material.KUNSTSTOFF, new Rect(0, PH - BH, BW, BH)),
            new Bin(Material.REST, new Rect(PW - BW, PH - BH, BW, BH)));

        List<Rect> t = new ArrayList<>(OBS);
        for (Bin b : BINS) {
            t.add(b.rect());
        }
        TOBS = List.copyOf(t);

        for (int y = 0; y < GR; y++) {
            for (int x = 0; x < GC; x++) {
                double cx = x * CS + CS / 2.0, cy = y * CS + CS / 2.0;
                BLOCK[x + y * GC] = inObs(cx, cy, RT + 2) || inBin(cx, cy, RT + 2);
            }
        }
    }

    private static boolean inside(Rect o, double x, double y, double pad) {
        return x > o.x() - pad && x < o.x() + o.w() + pad && y > o.y() - pad && y < o.y() + o.h() + pad;
    }

    public static boolean inObs(double x, double y, double pad) {
        for (Rect o : OBS) {
            if (inside(o, x, y, pad)) {
                return true;
            }
        }
        return false;
    }

    public static boolean inBin(double x, double y, double pad) {
        for (Bin b : BINS) {
            if (inside(b.rect(), x, y, pad)) {
                return true;
            }
        }
        return false;
    }

    /** True if the straight line is free of obstacles (and of bin zones if {@code bins}). */
    public static boolean clear(double x1, double y1, double x2, double y2, double pad, boolean bins) {
        double d = Math.hypot(x2 - x1, y2 - y1);
        int n = (int) Math.ceil(d / 8);
        for (int i = 1; i < n; i++) {
            double t = (double) i / n, x = x1 + (x2 - x1) * t, y = y1 + (y2 - y1) * t;
            if (inObs(x, y, pad) || (bins && inBin(x, y, pad))) {
                return false;
            }
        }
        return true;
    }

    /** Pushes the circle {@code e} (radius r) out of the rectangles and keeps it inside the play field. */
    public static void collide(Entity e, double r, List<Rect> list) {
        for (Rect o : list) {
            double cx = Math.max(o.x(), Math.min(e.x, o.x() + o.w())), cy = Math.max(o.y(), Math.min(e.y, o.y() + o.h()));
            double dx = e.x - cx, dy = e.y - cy;
            double d = Math.hypot(dx, dy);
            if (d < r) {
                if (d == 0) {
                    double l = e.x - o.x(), ri = o.x() + o.w() - e.x, t = e.y - o.y(), b = o.y() + o.h() - e.y;
                    double m = Math.min(Math.min(l, ri), Math.min(t, b));
                    if (m == l) {
                        e.x = o.x() - r;
                    } else if (m == ri) {
                        e.x = o.x() + o.w() + r;
                    } else if (m == t) {
                        e.y = o.y() - r;
                    } else {
                        e.y = o.y() + o.h() + r;
                    }
                } else {
                    e.x = cx + dx / d * r;
                    e.y = cy + dy / d * r;
                }
            }
        }
        e.x = Math.max(r, Math.min(PW - r, e.x));
        e.y = Math.max(r, Math.min(PH - r, e.y));
    }

    public static int cellX(double x) {
        return Math.max(0, Math.min(GC - 1, (int) Math.floor(x / CS)));
    }

    public static int cellY(double y) {
        return Math.max(0, Math.min(GR - 1, (int) Math.floor(y / CS)));
    }

    /** Breadth-first distance field (in cells) from the target cell; -1 = unreachable. */
    public static short[] navField(double tx, double ty) {
        short[] dist = new short[GC * GR];
        Arrays.fill(dist, (short) -1);
        int[] q = new int[GC * GR];
        int head = 0, tail = 0;
        int start = cellX(tx) + cellY(ty) * GC;
        dist[start] = 0;
        q[tail++] = start;
        while (head < tail) {
            int c = q[head++];
            int x = c % GC, y = c / GC;
            for (int[] d : DIRS) {
                int dx = d[0], dy = d[1], nx = x + dx, ny = y + dy;
                if (nx < 0 || ny < 0 || nx >= GC || ny >= GR) {
                    continue;
                }
                int n = nx + ny * GC;
                if (BLOCK[n] || dist[n] >= 0) {
                    continue;
                }
                if (dx != 0 && dy != 0 && (BLOCK[x + dx + y * GC] || BLOCK[x + (y + dy) * GC])) {
                    continue;
                }
                dist[n] = (short) (dist[c] + 1);
                q[tail++] = n;
            }
        }
        return dist;
    }

    /** Value zone of a map position: 2 = centre, 1.5 = ring, 1 = outside. */
    public static double zoneOf(double x, double y) {
        double r = Math.hypot(x - PW / 2.0, y - PH / 2.0) / Math.hypot(PW / 2.0, PH / 2.0);
        return r < 0.28 ? 2 : (r < 0.55 ? 1.5 : 1);
    }
}
