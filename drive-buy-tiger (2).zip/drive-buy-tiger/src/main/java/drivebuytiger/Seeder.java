package drivebuytiger;

import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLException;
import java.time.Instant;
import java.util.List;

/**
 * Creates the tables of the database ({@code db/schema.sql}) and inserts the start data ({@code db/seed.sql}):
 * texts, items, quiz, tuning defaults. The scoreboard and the saved slider values are kept.
 *
 * <pre>
 *   seed.bat                  (Windows)      or   ./seed.sh   (macOS / Linux)      or   java -jar drive-buy-tiger.jar --seed
 *   seed.bat --reset          start from zero: the database file is deleted first (scoreboard and saved sliders are lost)
 *   seed.bat --db some.db     use another database file
 * </pre>
 *
 * The game itself calls {@link #ensureCurrent(Db)}, so it also seeds an empty database on its first start.
 */
public final class Seeder {
    private static final String[] CONTENT_TABLES = {"material", "item", "fact", "quiz_question", "quiz_answer", "tiger", "control", "rule", "release_note",
        "source", "tuning", "ui_text"};

    private Seeder() {}

    public static void main(String[] args) {
        System.exit(run(args, System.out, System.err));
    }

    /** The command line tool; returns the exit code. */
    static int run(String[] args, PrintStream out, PrintStream err) {
        Path file = Db.defaultFile();
        boolean reset = false;
        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "--reset" -> reset = true;
                case "--db" -> {
                    if (i + 1 >= args.length) {
                        err.println("--db needs a file name");
                        return 2;
                    }
                    file = Path.of(args[++i]);
                }
                case "--help", "-h", "/?" -> {
                    out.println("Fills the database of Drive Buy Tiger with the start data of db/seed.sql.");
                    out.println("  --reset      delete the database file first (the scoreboard and the saved slider values are lost, too)");
                    out.println("  --db <file>  use this database file instead of " + Db.defaultFile());
                    return 0;
                }
                default -> {
                    err.println("Unknown option: " + args[i] + " (try --help)");
                    return 2;
                }
            }
        }
        try {
            if (reset) {
                for (String suffix : new String[] {"", "-journal", "-wal", "-shm"}) {
                    Files.deleteIfExists(Path.of(file.toAbsolutePath() + suffix));
                }
                out.println("Database deleted: " + file.toAbsolutePath());
            }
            SqlScript.Source schema = SqlScript.load("schema.sql");
            SqlScript.Source seed = SqlScript.load("seed.sql");
            out.println("Database : " + file.toAbsolutePath());
            out.println("Schema   : " + schema.origin());
            out.println("Seed     : " + seed.origin());
            try (Db db = Db.open(file)) {
                apply(db, schema, seed);
                if (reset) {
                    db.update("INSERT OR REPLACE INTO meta (key, value) VALUES ('legacy_import', 'skipped (reset)')");
                } else {
                    String legacy = Legacy.importIfNeeded(db, file.toAbsolutePath().getParent());
                    if (legacy != null) {
                        out.println("Imported : " + legacy);
                    }
                }
                StringBuilder sb = new StringBuilder("Filled   :");
                for (String t : CONTENT_TABLES) {
                    sb.append(' ').append(t).append(' ').append(db.count(t)).append(';');
                }
                out.println(sb);
                out.println("Kept     : highscore " + db.count("highscore") + " rows, setting " + db.count("setting") + " rows");
                out.println("OK, content_version " + db.text("SELECT value FROM meta WHERE key = 'content_version'"));
            }
            return 0;
        } catch (IOException | SQLException | LinkageError e) {
            err.println("Seeding failed: " + e.getMessage());
            return 1;
        }
    }

    /**
     * Makes sure that the database holds the content of the seed script: if the stored content_version differs from the one in
     * db/seed.sql (or there is none yet), schema and seed are applied. Returns true if that happened.
     */
    public static boolean ensureCurrent(Db db) throws SQLException, IOException {
        SqlScript.Source seed = SqlScript.load("seed.sql");
        int want = SqlScript.contentVersion(seed.text());
        String have = null;
        try {
            have = db.text("SELECT value FROM meta WHERE key = 'content_version'");
        } catch (SQLException noTableYet) {
            // a new, empty database
        }
        if (have != null && have.equals(String.valueOf(want))) {
            return false;
        }
        apply(db, SqlScript.load("schema.sql"), seed);
        return true;
    }

    /** An in-memory database with schema and seed (for tests and for runs that must not touch the disk). */
    public static Db seededMemory() throws SQLException, IOException {
        Db db = Db.memory();
        apply(db, SqlScript.load("schema.sql"), SqlScript.load("seed.sql"));
        return db;
    }

    /** Runs schema and seed as one transaction. */
    static void apply(Db db, SqlScript.Source schema, SqlScript.Source seed) throws SQLException {
        db.transaction(d -> {
            for (List<String> script : List.of(SqlScript.split(schema.text()), SqlScript.split(seed.text()))) {
                for (String st : script) {
                    try {
                        d.exec(st);
                    } catch (SQLException e) {
                        String head = st.length() > 90 ? st.substring(0, 90) + " ..." : st;
                        throw new SQLException("Statement failed: " + head.replace('\n', ' ') + " -> " + e.getMessage(), e);
                    }
                }
            }
            d.update("INSERT OR REPLACE INTO meta (key, value) VALUES ('seeded_at', ?)", Instant.now().toString());
            return null;
        });
    }
}
