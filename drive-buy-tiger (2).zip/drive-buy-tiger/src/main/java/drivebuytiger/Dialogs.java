package drivebuytiger;

import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.event.HyperlinkEvent;

/** The Swing dialogs: tuning sliders, help, scoreboard. */
final class Dialogs {
    private Dialogs() {}

    // ------------------------------------------------------------------ tuning sliders

    /** "Regler fürs Spielkonzept": changes apply immediately and are saved; the next run uses them. */
    static void showSettings(Frame owner, Session ses, Runnable restart) {
        Settings s = ses.settings;
        JDialog d = new JDialog(owner, Texts.t("dlg.tune.title"), true);
        JPanel grid = new JPanel(new GridBagLayout());
        grid.setBorder(new EmptyBorder(12, 16, 4, 16));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(3, 6, 3, 6);
        c.fill = GridBagConstraints.HORIZONTAL;
        List<Runnable> refresh = new ArrayList<>();
        int row = 0;
        for (Tune t : Content.sliders()) {
            c.gridy = row++;
            c.gridx = 0;
            c.weightx = 0;
            grid.add(new JLabel(t.label()), c);
            if (t.bool()) {
                JCheckBox cb = new JCheckBox();
                cb.setSelected(s.b(t));
                cb.addActionListener(e -> s.set(t, cb.isSelected() ? 1 : 0));
                refresh.add(() -> cb.setSelected(s.b(t)));
                c.gridx = 1;
                c.gridwidth = 2;
                grid.add(cb, c);
                c.gridwidth = 1;
            } else {
                int n = (int) Math.round((t.max() - t.min()) / t.step());
                JSlider sl = new JSlider(0, n, (int) Math.round((s.d(t) - t.min()) / t.step()));
                sl.setPreferredSize(new Dimension(260, sl.getPreferredSize().height));
                JLabel val = new JLabel(t.format(s.d(t)), SwingConstants.RIGHT);
                val.setPreferredSize(new Dimension(72, 20));
                sl.addChangeListener(e -> {
                    s.set(t, Math.round((t.min() + sl.getValue() * t.step()) * 1000) / 1000.0);
                    val.setText(t.format(s.d(t)));
                });
                refresh.add(() -> {
                    sl.setValue((int) Math.round((s.d(t) - t.min()) / t.step()));
                    val.setText(t.format(s.d(t)));
                });
                c.gridx = 1;
                c.weightx = 1;
                grid.add(sl, c);
                c.gridx = 2;
                c.weightx = 0;
                grid.add(val, c);
            }
        }
        JButton apply = new JButton(Texts.t("dlg.tune.apply"));
        apply.addActionListener(e -> {
            s.save();
            d.dispose();
            restart.run();
        });
        JButton defaults = new JButton(Texts.t("dlg.tune.defaults"));
        defaults.addActionListener(e -> {
            s.reset();
            refresh.forEach(Runnable::run);
        });
        JButton close = new JButton(Texts.t("dlg.close"));
        close.addActionListener(e -> d.dispose());
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 8));
        buttons.add(apply);
        buttons.add(defaults);
        buttons.add(close);
        JLabel hint = new JLabel(Texts.t("dlg.tune.hint"));
        hint.setBorder(new EmptyBorder(0, 16, 0, 16));
        JPanel south = new JPanel(new BorderLayout());
        south.add(hint, BorderLayout.NORTH);
        south.add(buttons, BorderLayout.SOUTH);
        d.add(new JScrollPane(grid, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER), BorderLayout.CENTER);
        d.add(south, BorderLayout.SOUTH);
        d.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent e) {
                s.save();
            }
        });
        d.pack();
        d.setLocationRelativeTo(owner);
        d.setVisible(true);
    }

    // ------------------------------------------------------------------ help

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    /** The help page as HTML: the markup is here, every word comes from the database. */
    static String helpHtml() {
        StringBuilder h = new StringBuilder("<html><body style='font-family:sans-serif;font-size:12pt'>");
        h.append("<h2>").append(Texts.t("dlg.help.heading_html")).append("</h2><p>").append(esc(Texts.t("help.lead"))).append("</p>");
        h.append("<h3>").append(esc(Texts.t("dlg.help.controls"))).append("</h3><table cellpadding='3'>");
        for (Content.KeyHelp k : Content.controls()) {
            h.append("<tr><td><b>").append(esc(k.keys())).append("</b></td><td>").append(esc(k.text())).append("</td></tr>");
        }
        h.append("</table><p><i>").append(esc(Texts.t("dlg.help.keys_note"))).append("</i></p><h3>").append(esc(Texts.t("dlg.help.rules"))).append("</h3><ul>");
        for (String r : Content.rules()) {
            h.append("<li>").append(esc(r)).append("</li>");
        }
        h.append("</ul><h3>").append(esc(Texts.t("dlg.help.tigers"))).append("</h3><ul>");
        for (Content.TigerInfo t : Content.tigers()) {
            h.append("<li><b>").append(esc(t.name())).append("</b>: ").append(esc(t.text())).append("</li>");
        }
        h.append("</ul><h3>").append(esc(Texts.t("dlg.help.news"))).append("</h3><ul>");
        for (String n : Content.news()) {
            h.append("<li>").append(esc(n)).append("</li>");
        }
        h.append("</ul><h3>").append(esc(Texts.t("dlg.help.sources"))).append("</h3><ul>");
        for (Content.Source src : Content.sources()) {
            h.append("<li><a href='").append(src.url()).append("'>").append(esc(src.title())).append("</a></li>");
        }
        h.append("</ul><p><i>").append(esc(Texts.t("help.weight_hint"))).append("</i></p></body></html>");
        return h.toString();
    }

    static void showHelp(Frame owner) {
        JEditorPane pane = new JEditorPane("text/html", helpHtml());
        pane.setEditable(false);
        pane.setCaretPosition(0);
        pane.setBorder(new EmptyBorder(8, 12, 8, 12));
        pane.addHyperlinkListener(e -> {
            if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED && Desktop.isDesktopSupported()) {
                try {
                    Desktop.getDesktop().browse(URI.create(e.getURL().toString()));
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(owner, Texts.t("dlg.help.link_error") + "\n" + e.getURL());
                }
            }
        });
        JDialog d = new JDialog(owner, Texts.t("dlg.help.title"), true);
        JScrollPane sp = new JScrollPane(pane);
        sp.setPreferredSize(new Dimension(640, 560));
        d.add(sp, BorderLayout.CENTER);
        JButton ok = new JButton(Texts.t("dlg.close"));
        ok.addActionListener(e -> d.dispose());
        JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        south.add(ok);
        d.add(south, BorderLayout.SOUTH);
        d.pack();
        d.setLocationRelativeTo(owner);
        d.setVisible(true);
    }

    // ------------------------------------------------------------------ scoreboard

    static void showScoreboard(Frame owner, Session ses) {
        JDialog d = new JDialog(owner, Texts.t("dlg.board.title"), true);
        DefaultListModel<String> model = new DefaultListModel<>();
        fillScores(model, ses.scores);
        JList<String> list = new JList<>(model);
        list.setFont(list.getFont().deriveFont(15f));
        JScrollPane sp = new JScrollPane(list);
        sp.setPreferredSize(new Dimension(320, 320));
        d.add(sp, BorderLayout.CENTER);
        JButton clear = new JButton(Texts.t("dlg.board.clear"));
        clear.addActionListener(e -> {
            int r = JOptionPane.showConfirmDialog(d, Texts.t("dlg.board.confirm"), Texts.t("dlg.board.confirm_title"), JOptionPane.YES_NO_OPTION);
            if (r == JOptionPane.YES_OPTION) {
                ses.scores.clear();
                fillScores(model, ses.scores);
            }
        });
        JButton close = new JButton(Texts.t("dlg.close"));
        close.addActionListener(e -> d.dispose());
        JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        south.add(clear);
        south.add(close);
        d.add(south, BorderLayout.SOUTH);
        d.add(new JLabel("  " + Texts.t("dlg.board.note"), SwingConstants.LEFT), BorderLayout.NORTH);
        d.pack();
        d.setLocationRelativeTo(owner);
        d.setVisible(true);
    }

    private static void fillScores(DefaultListModel<String> model, HighScores scores) {
        model.clear();
        List<HighScores.Entry> today = scores.today();
        if (today.isEmpty()) {
            model.addElement(Texts.t("board.empty"));
        }
        for (int i = 0; i < Math.min(10, today.size()); i++) {
            HighScores.Entry e = today.get(i);
            model.addElement(String.format(Locale.ROOT, "%2d.   %s   %d", i + 1, e.name, e.score));
        }
    }
}
