package drivebuytiger;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The content of the game: items, facts, quiz questions, help texts, tiger descriptions, the tuning definitions and all other
 * texts. Nothing of it is written in the code any more: {@link #load(Db)} reads it once from the SQLite database
 * (filled from {@code db/seed.sql} by {@link Seeder}) into immutable lists, so the game never asks the database while it draws a frame.
 * The texts are German, exactly as in the original web prototype (facts from BAFU, Swiss Recycle, SRF, IAI).
 */
public final class Content {
    private Content() {}

    /** One piece of waste. {@code grams} is an estimated weight, {@code co2} = kg CO2 saved per kg recycled (0 = unknown), {@code icon} = drawing routine. */
    public record Item(String name, String icon, Material mat, int grams, double co2, boolean pet, boolean tricky, String why) {}

    /** A bonus question; {@code correct} is the index of the right answer (0 = first). */
    public record Question(String q, List<String> answers, int correct) {}

    public record Source(String title, String url) {}

    public record TigerInfo(String name, String colorHex, String text) {}

    public record KeyHelp(String keys, String text) {}

    /** Label, range, step and default of one slider ({@link Tune}). */
    public record TuneDef(String label, String unit, double min, double max, double step, double def, boolean bool) {}

    private record Data(
        List<Item> items, List<Item> easy, List<Item> hard,
        Map<Material, String> labels, Map<Material, List<String>> facts,
        List<Question> quiz, List<KeyHelp> controls, List<String> rules, List<String> news,
        Map<Game.Kind, TigerInfo> tigers, List<Source> sources, Map<Tune, TuneDef> tune, List<Tune> sliders) {}

    private static volatile Data data;

    // ------------------------------------------------------------------ loading

    /** Reads all content (and the table ui_text for {@link Texts}) from the database. Call once at the start. */
    public static void load(Db db) throws SQLException {
        Map<Material, String> labels = new EnumMap<>(Material.class);
        db.query("SELECT id, label FROM material", rs -> labels.put(material(rs.getString(1)), rs.getString(2)));
        require(labels.size() == Material.values().length, "table material needs a row for every bin");

        List<Item> items = db.query("SELECT name, icon, material, grams, co2_per_kg, is_pet, is_tricky, why FROM item ORDER BY id",
            rs -> new Item(rs.getString(1), rs.getString(2), material(rs.getString(3)), rs.getInt(4), rs.getDouble(5), rs.getInt(6) != 0, rs.getInt(7) != 0, rs.getString(8)));
        require(items.stream().anyMatch(i -> !i.tricky()) && items.stream().anyMatch(Item::tricky), "table item needs normal and tricky items");

        Map<Material, String[]> factRows = new EnumMap<>(Material.class);
        db.query("SELECT material, level, text FROM fact", rs -> {
            factRows.computeIfAbsent(material(rs.getString(1)), m -> new String[3])[rs.getInt(2)] = rs.getString(3);
            return Boolean.TRUE;
        });
        Map<Material, List<String>> facts = new EnumMap<>(Material.class);
        for (Material m : Material.values()) {
            String[] f = factRows.get(m);
            require(f != null && f[0] != null && f[1] != null && f[2] != null, "table fact needs the levels 0, 1 and 2 for " + m.name());
            facts.put(m, List.of(f));
        }

        Map<Integer, List<String>> answers = new LinkedHashMap<>();
        db.query("SELECT question_id, text FROM quiz_answer ORDER BY question_id, answer_no", rs -> {
            answers.computeIfAbsent(rs.getInt(1), k -> new ArrayList<>()).add(rs.getString(2));
            return Boolean.TRUE;
        });
        List<Question> quiz = db.query("SELECT id, question, correct_no FROM quiz_question ORDER BY id", rs -> {
            List<String> a = answers.getOrDefault(rs.getInt(1), List.of());
            int correct = rs.getInt(3) - 1;
            require(correct >= 0 && correct < a.size(), "quiz question " + rs.getInt(1) + ": correct_no does not point to an answer");
            return new Question(rs.getString(2), List.copyOf(a), correct);
        });

        List<KeyHelp> controls = db.query("SELECT keys, description FROM control ORDER BY sort_no", rs -> new KeyHelp(rs.getString(1), rs.getString(2)));
        List<String> rules = db.query("SELECT text FROM rule ORDER BY sort_no", rs -> rs.getString(1));
        List<String> news = db.query("SELECT text FROM release_note ORDER BY sort_no", rs -> rs.getString(1));
        List<Source> sources = db.query("SELECT title, url FROM source ORDER BY sort_no", rs -> new Source(rs.getString(1), rs.getString(2)));

        Map<Game.Kind, TigerInfo> tigers = new LinkedHashMap<>();
        db.query("SELECT kind, name, color, description FROM tiger ORDER BY sort_no", rs -> {
            Game.Kind k;
            try {
                k = Game.Kind.valueOf(rs.getString(1));
            } catch (IllegalArgumentException e) {
                throw new SQLException("table tiger: unknown kind '" + rs.getString(1) + "'");
            }
            tigers.put(k, new TigerInfo(rs.getString(2), rs.getString(3), rs.getString(4)));
            return Boolean.TRUE;
        });
        require(tigers.size() == Game.Kind.values().length, "table tiger needs a row for every kind of tiger");

        Map<String, TuneDef> byKey = new HashMap<>();
        List<String> keyOrder = new ArrayList<>();
        db.query("SELECT key, label, unit, min_value, max_value, step_value, default_value, is_toggle FROM tuning ORDER BY sort_no", rs -> {
            keyOrder.add(rs.getString(1));
            byKey.put(rs.getString(1), new TuneDef(rs.getString(2), rs.getString(3), rs.getDouble(4), rs.getDouble(5), rs.getDouble(6), rs.getDouble(7), rs.getInt(8) != 0));
            return Boolean.TRUE;
        });
        Map<Tune, TuneDef> tune = new EnumMap<>(Tune.class);
        for (Tune t : Tune.values()) {
            TuneDef def = byKey.get(t.key);
            require(def != null, "table tuning needs a row for the key '" + t.key + "'");
            tune.put(t, def);
        }
        List<Tune> sliders = new ArrayList<>();
        for (String k : keyOrder) {
            for (Tune t : Tune.values()) {
                if (t.key.equals(k)) {
                    sliders.add(t);
                }
            }
        }

        Map<String, String> texts = new HashMap<>();
        db.query("SELECT key, value FROM ui_text", rs -> texts.put(rs.getString(1), rs.getString(2)));

        List<Item> easy = items.stream().filter(i -> !i.tricky()).toList();
        List<Item> hard = items.stream().filter(Item::tricky).toList();
        Texts.install(texts);
        data = new Data(List.copyOf(items), easy, hard, labels, facts, quiz, controls, rules, news, tigers, sources, tune, List.copyOf(sliders));
    }

    private static Material material(String id) throws SQLException {
        try {
            return Material.valueOf(id);
        } catch (IllegalArgumentException e) {
            throw new SQLException("unknown material '" + id + "' (allowed: GLAS, METALL, KUNSTSTOFF, REST)");
        }
    }

    private static void require(boolean ok, String message) throws SQLException {
        if (!ok) {
            throw new SQLException("The database content is incomplete: " + message + ". Run seed.bat (or seed.sh) to fill it again.");
        }
    }

    private static Data d() {
        Data x = data;
        if (x == null) {
            throw new IllegalStateException("Content.load(db) has not been called");
        }
        return x;
    }

    // ------------------------------------------------------------------ access

    /** All items in database order (the order matters for the random pick). */
    public static List<Item> items() {
        return d().items;
    }

    public static List<Item> easy() {
        return d().easy;
    }

    public static List<Item> hard() {
        return d().hard;
    }

    /** Name of a bin. */
    public static String label(Material m) {
        return d().labels.get(m);
    }

    /**
     * Fact for the summary ("Bilanz"): level 0 is shown to everybody, level 1 unlocks with 2 stars, level 2 with 3 stars
     * (sources: BAFU, Swiss Recycle, SRF, IAI).
     */
    public static String fact(Material m, int level) {
        return d().facts.get(m).get(level);
    }

    /** Hard bonus questions asked at the end of a run. */
    public static List<Question> quiz() {
        return d().quiz;
    }

    public static List<KeyHelp> controls() {
        return d().controls;
    }

    public static List<String> rules() {
        return d().rules;
    }

    /** The "Neu in v2" list of the help. */
    public static List<String> news() {
        return d().news;
    }

    public static TigerInfo tiger(Game.Kind kind) {
        return d().tigers.get(kind);
    }

    /** The tiger descriptions in the order of the table. */
    public static List<TigerInfo> tigers() {
        return List.copyOf(d().tigers.values());
    }

    public static List<Source> sources() {
        return d().sources;
    }

    public static TuneDef tune(Tune t) {
        return d().tune.get(t);
    }

    /** The parameters in the order of the tuning dialog (column sort_no of the table tuning). */
    public static List<Tune> sliders() {
        return d().sliders;
    }
}
