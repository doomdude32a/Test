package drivebuytiger;

import java.awt.event.KeyEvent;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Keyboard state. Held keys are kept in a set; one-shot presses (Space, Enter, P, menu navigation)
 * are queued as flags that the game consumes once per frame.
 */
public final class Input {
    /** Movement vector (length 0..1) and the sneak flag. */
    public record Move(double x, double y, boolean sneak) {}

    /** One-shot presses of this frame. */
    public boolean actionQ, enterQ, pauseQ, navU, navD, navL, navR;

    private static final long RELEASE_DELAY_NANOS = 12_000_000L;

    private final Set<Integer> down = new HashSet<>();
    private final Map<Integer, Long> releasing = new HashMap<>();
    private final boolean debounce;

    public Input() {
        this(true);
    }

    /**
     * @param debounceReleases true (normal play): a key release is applied ~12 ms late, so the
     *     release/press burst that X11 sends for auto-repeat does not interrupt walking
     */
    public Input(boolean debounceReleases) {
        this.debounce = debounceReleases;
    }

    public synchronized void keyPressed(int code) {
        if (releasing.remove(code) != null) {
            return; // auto-repeat burst: the key never really went up
        }
        if (!down.add(code)) {
            return; // auto-repeat on Windows/macOS
        }
        switch (code) {
            case KeyEvent.VK_SPACE -> actionQ = true;
            case KeyEvent.VK_ENTER -> enterQ = true;
            case KeyEvent.VK_P, KeyEvent.VK_ESCAPE -> pauseQ = true;
            case KeyEvent.VK_UP, KeyEvent.VK_W -> navU = true;
            case KeyEvent.VK_DOWN, KeyEvent.VK_S -> navD = true;
            case KeyEvent.VK_LEFT, KeyEvent.VK_A -> navL = true;
            case KeyEvent.VK_RIGHT, KeyEvent.VK_D -> navR = true;
            default -> { }
        }
    }

    public synchronized void keyReleased(int code) {
        if (!down.contains(code)) {
            return;
        }
        if (debounce) {
            releasing.put(code, System.nanoTime());
        } else {
            down.remove(code);
        }
    }

    /** Call at the start of each frame (applies delayed releases). */
    public synchronized void beginFrame() {
        if (releasing.isEmpty()) {
            return;
        }
        long now = System.nanoTime();
        Iterator<Map.Entry<Integer, Long>> it = releasing.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Long> e = it.next();
            if (now - e.getValue() >= RELEASE_DELAY_NANOS) {
                down.remove(e.getKey());
                it.remove();
            }
        }
    }

    /** Call at the end of each frame (clears the one-shot presses). */
    public synchronized void endFrame() {
        actionQ = false;
        enterQ = false;
        pauseQ = false;
        navU = false;
        navD = false;
        navL = false;
        navR = false;
    }

    /** Forget all held keys (window lost focus). */
    public synchronized void clear() {
        down.clear();
        releasing.clear();
    }

    /** Queue an Enter press (mouse click on menu / intro). */
    public synchronized void pressEnter() {
        enterQ = true;
    }

    public synchronized Move readMove() {
        double x = 0, y = 0;
        for (int k : down) {
            switch (k) {
                case KeyEvent.VK_UP, KeyEvent.VK_W -> y -= 1;
                case KeyEvent.VK_DOWN, KeyEvent.VK_S -> y += 1;
                case KeyEvent.VK_LEFT, KeyEvent.VK_A -> x -= 1;
                case KeyEvent.VK_RIGHT, KeyEvent.VK_D -> x += 1;
                default -> { }
            }
        }
        x = Math.signum(x);
        y = Math.signum(y);
        double m = Math.hypot(x, y);
        if (m > 1) {
            x /= m;
            y /= m;
        }
        if (m < 0.2) {
            x = 0;
            y = 0;
        }
        return new Move(x, y, down.contains(KeyEvent.VK_SHIFT));
    }
}
