package drivebuytiger;

import java.awt.Color;

/**
 * The four waste streams / recycling bins. The order is the order of the bins in the HUD.
 * The name shown in the game comes from the table {@code material} of the database ({@link #label()}).
 */
public enum Material {
    GLAS(0x2FB05A, 0x0F2A1B),
    METALL(0x9AA8B3, 0x0F2A1B),
    KUNSTSTOFF(0xF6C623, 0x0F2A1B),
    REST(0x5A636A, 0xF4EFDC);

    /** Bin colour. */
    public final Color color;
    /** Readable text colour on top of the bin colour. */
    public final Color textColor;

    Material(int color, int textColor) {
        this.color = new Color(color);
        this.textColor = new Color(textColor);
    }

    /** Name shown in the game (from the database). */
    public String label() {
        return Content.label(this);
    }
}
