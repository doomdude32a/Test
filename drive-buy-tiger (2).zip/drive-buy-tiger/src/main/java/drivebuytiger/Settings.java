package drivebuytiger;

import java.sql.SQLException;

/**
 * Current values of all {@link Tune} parameters. The defaults come from the table {@code tuning}; what the player changed in
 * the tuning dialog is kept in the table {@code setting} (only values that differ from the default).
 */
public final class Settings {
    private final double[] v = new double[Tune.values().length];
    private final Db db;

    /** @param db where to load/save the values, or null to keep them in memory only */
    public Settings(Db db) {
        this.db = db;
        reset();
        load();
    }

    public static Settings inMemory() {
        return new Settings(null);
    }

    public double d(Tune t) {
        return v[t.ordinal()];
    }

    public int i(Tune t) {
        return (int) Math.round(v[t.ordinal()]);
    }

    public boolean b(Tune t) {
        return v[t.ordinal()] != 0;
    }

    public void set(Tune t, double value) {
        v[t.ordinal()] = Math.max(t.min(), Math.min(t.max(), value));
    }

    public void reset() {
        for (Tune t : Tune.values()) {
            v[t.ordinal()] = t.def();
        }
    }

    public void save() {
        if (db == null) {
            return;
        }
        try {
            db.transaction(tx -> {
                tx.update("DELETE FROM setting");
                for (Tune t : Tune.values()) {
                    if (Math.abs(d(t) - t.def()) > 1e-9) {
                        tx.update("INSERT INTO setting (key, value) VALUES (?, ?)", t.key, d(t));
                    }
                }
                return null;
            });
        } catch (SQLException e) {
            System.err.println("Could not save settings: " + e.getMessage());
        }
    }

    private void load() {
        if (db == null) {
            return;
        }
        try {
            db.query("SELECT key, value FROM setting", rs -> {
                for (Tune t : Tune.values()) {
                    if (t.key.equals(rs.getString(1))) {
                        set(t, rs.getDouble(2));
                    }
                }
                return Boolean.TRUE;
            });
        } catch (SQLException e) {
            System.err.println("Could not read settings, using defaults: " + e.getMessage());
        }
    }
}
