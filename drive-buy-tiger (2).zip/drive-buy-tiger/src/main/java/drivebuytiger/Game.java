package drivebuytiger;

import static drivebuytiger.GameMap.BINS;
import static drivebuytiger.GameMap.BUSHES;
import static drivebuytiger.GameMap.CAMP_X;
import static drivebuytiger.GameMap.CAMP_Y;
import static drivebuytiger.GameMap.CS;
import static drivebuytiger.GameMap.GC;
import static drivebuytiger.GameMap.GR;
import static drivebuytiger.GameMap.OBS;
import static drivebuytiger.GameMap.PH;
import static drivebuytiger.GameMap.PW;
import static drivebuytiger.GameMap.RP;
import static drivebuytiger.GameMap.RT;
import static drivebuytiger.GameMap.TOBS;
import static drivebuytiger.GameMap.clear;
import static drivebuytiger.GameMap.collide;
import static drivebuytiger.GameMap.inBin;
import static drivebuytiger.GameMap.inObs;
import static drivebuytiger.GameMap.zoneOf;
import static drivebuytiger.Palette.DANGER;
import static drivebuytiger.Palette.ICE;
import static drivebuytiger.Palette.LIME;
import static drivebuytiger.Palette.PAPER;
import static drivebuytiger.Palette.YELLOW;

import drivebuytiger.Content.Item;
import drivebuytiger.GameMap.Bin;
import drivebuytiger.GameMap.Bush;
import java.awt.Color;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.DoubleSupplier;

/** One run of the game: the world state and all game rules (port of the JavaScript prototype). */
public final class Game {
    public enum Kind { PIRSCH, STREUN, SCHLAF }

    public enum TState { SEARCH, ROAM, CHASE, LOOK, INVESTIGATE, RUSH, SLEEP }

    private enum Want { ANY, CENTER, OUTER }

    /** Half opening angle of the torch cone in radians. */
    public static final double HALF = 0.55;

    // ------------------------------------------------------------------ entities

    public static final class Player extends Entity {
        public double face = -Math.PI / 2;
        public double inv = 1.5;   // invulnerable (after respawn)
        public double invis;       // invisible power-up
        public double turbo;       // turbo power-up
        public double msg;         // cooldown of the "hands full" message
        public boolean sneak, moving, hidden, safe;
        public Trash skip;         // piece whose scan was cancelled: ignored until we walk away
        public Bin bin;            // bin zone we are standing in
    }

    public static final class Tiger extends Entity {
        public final Kind kind;
        public final String name;
        public final double homeX, homeY;
        public TState st;
        public double face = Math.PI / 2;
        public double r = 340;     // distance the Pirscher keeps
        public double rushT, rushLeft, phase, lookT, pause, lost, navT, navX, navY, wait;
        public Entity tgt, center, lp;
        public short[] nav;

        Tiger(Kind kind, String name, double hx, double hy, TState st) {
            super(hx, hy);
            this.kind = kind;
            this.name = name;
            this.homeX = hx;
            this.homeY = hy;
            this.st = st;
        }
    }

    public static final class Trash extends Entity {
        public final Item it;
        public final double zone, bob;

        Trash(double x, double y, Item it, double zone, double bob) {
            super(x, y);
            this.it = it;
            this.zone = zone;
            this.bob = bob;
        }
    }

    public static final class PowerUp extends Entity {
        public final boolean turbo;
        public double life = 16;

        PowerUp(double x, double y, boolean turbo) {
            super(x, y);
            this.turbo = turbo;
        }
    }

    public static final class Fx {
        public final String text;
        public final double x, y;
        public final Color color;
        public double t;

        Fx(String text, double x, double y, Color color) {
            this.text = text;
            this.x = x;
            this.y = y;
            this.color = color;
        }
    }

    public static final class Scan {
        public final Trash tr;
        public double u, age;
        public double dir = 1;

        Scan(Trash tr) {
            this.tr = tr;
        }
    }

    public static final class Bag {
        public final Item it;
        public final double zone;
        public int wrongs;

        Bag(Item it, double zone) {
            this.it = it;
            this.zone = zone;
        }
    }

    public static final class Pulse {
        public final double x, y, r;
        public double t;

        Pulse(double x, double y, double r) {
            this.x = x;
            this.y = y;
            this.r = r;
        }
    }

    /** What was thrown into one bin during the run. */
    public static final class Deposit {
        public int n, first, pet;
        public double g, co2;
        public double disp;                    // smoothed fill level shown in the HUD
        public final Map<String, Integer> mix = new LinkedHashMap<>(); // wrongly sorted items
    }

    public static final class Stats {
        public int green, scans, caught, first, wrong;
    }

    public static final class Feedback {
        public final String title, text;
        public final Color color;
        public final double dur;
        public double t;

        Feedback(String title, String text, Color color, double dur) {
            this.title = title;
            this.text = text;
            this.color = color;
            this.dur = dur;
        }
    }

    /** A short hint shown during play (every hint once per run; the newest one replaces the old one). */
    public static final class Tip {
        public final String key, title, text;
        public final double dur = 4.2;
        public double t;

        Tip(String key, String title, String text) {
            this.key = key;
            this.title = title;
            this.text = text;
        }
    }

    public record QuizResult(int ok, int n, double mult) {}

    /** "Das nimmst du mit": the headline of the summary (the most confused item, or a general fact). */
    public record MainFact(Material mat, String title, String text, String fact) {}

    // ------------------------------------------------------------------ state

    private final Settings s;
    private final DoubleSupplier rnd;

    public int score;
    public int lives;
    public double time;
    public double elapsed;
    public final List<Trash> trash = new ArrayList<>();
    public final List<PowerUp> powers = new ArrayList<>();
    public Bag bag;
    public Scan scan;
    public final List<Pulse> pulses = new ArrayList<>();
    public double powerT = 8;
    public int total;
    public final Map<Material, Deposit> dep = new EnumMap<>(Material.class);
    public String end = "";
    public QuizResult quizRes;
    public final Stats stats = new Stats();
    public final Player p = new Player();
    public List<Tiger> tigers = new ArrayList<>();
    public final List<Fx> fx = new ArrayList<>();
    public Feedback fb;
    /** Hints already shown in this run (each hint is shown only once). */
    public final Set<String> tips = new HashSet<>();
    /** The hint on screen right now, or null. */
    public Tip tip;
    /** Seconds the corner containers glow strongly (first piece found in this run). */
    public double glowT;
    /** True once the run is over (time up or no lives left); the session then moves on. */
    public boolean over;

    public Game(Settings settings, DoubleSupplier random) {
        this.s = settings;
        this.rnd = random;
        lives = settings.i(Tune.LIVES);
        time = settings.d(Tune.START_TIME);
        p.x = CAMP_X;
        p.y = CAMP_Y;
        for (Material m : Material.values()) {
            dep.put(m, new Deposit());
        }
        makeTigers();
        for (int i = 0; i < settings.i(Tune.TRASH); i++) {
            spawnTrash();
        }
    }

    // ------------------------------------------------------------------ small helpers

    private double rnd() {
        return rnd.getAsDouble();
    }

    private static double clamp(double v, double a, double b) {
        return Math.max(a, Math.min(b, v));
    }

    /** 0 at the start, 1 when the time is nearly gone: the less time, the harder (and the more points). */
    public double pressure() {
        return clamp(1 - time / s.d(Tune.START_TIME), 0, 1);
    }

    public double timeMul() {
        return 1 + pressure();
    }

    private double addTime(double sec) {
        double room = Math.max(0, s.d(Tune.MAX_TIME) - (elapsed + time));
        double a = Math.min(sec, room);
        time += a;
        return a;
    }

    /** At most one decimal, none for whole numbers ("5", "2.5"); hides the rounding noise the prototype printed. */
    private static String num(double a) {
        double r = Math.round(a * 10) / 10.0;
        return r == Math.rint(r) ? String.valueOf((long) r) : String.format(Locale.ROOT, "%.1f", r);
    }

    /**
     * "Richtig! +120" or, when bonus time was really added, "Richtig! +120  +3 s" (text keys {@code base} and {@code base_bonus}).
     * Nothing is added for (almost) zero seconds: the prototype printed rounding noise like "+2.05e-11 s" here.
     */
    private static String pointsText(String base, int pts, double bonusSec) {
        return bonusSec >= 0.05 ? Texts.t(base + "_bonus", "pts", pts, "sec", num(bonusSec)) : Texts.t(base, "pts", pts);
    }

    private void addFx(String text, double x, double y, Color color) {
        fx.add(new Fx(text, x, y, color));
    }

    private void feedback(String title, String text, Color color, double dur) {
        fb = new Feedback(title, text, color, dur);
    }

    /**
     * Short hint during play instead of a long text at the start; every hint only once per run.
     * The texts are {@code tip.<key>.title} and {@code tip.<key>.text} in the database; {@code values} fill their {placeholders}.
     */
    private void showTip(String key, Object... values) {
        if (!tips.add(key)) {
            return;
        }
        tip = new Tip(key, Texts.t("tip." + key + ".title"), Texts.t("tip." + key + ".text", values));
    }

    private void finish(String reason) {
        over = true;
        end = reason;
        scan = null;
        fb = null;
    }

    // ------------------------------------------------------------------ spawning

    private Entity freePoint(double minFromPlayer, Want want) {
        for (int k = 0; k < 400; k++) {
            double x = 40 + rnd() * (PW - 80), y = 40 + rnd() * (PH - 80);
            if (inObs(x, y, 30)) {
                continue;
            }
            if (inBin(x, y, 30)) {
                continue;
            }
            boolean nearBush = false;
            for (Bush b : BUSHES) {
                if (Math.hypot(x - b.x(), y - b.y()) < b.r() + 20) {
                    nearBush = true;
                    break;
                }
            }
            if (nearBush) {
                continue;
            }
            if (Math.hypot(x - CAMP_X, y - CAMP_Y) < 110) {
                continue;
            }
            if (want == Want.CENTER && zoneOf(x, y) < 1.5) {
                continue;
            }
            if (want == Want.OUTER && zoneOf(x, y) > 1) {
                continue;
            }
            if (Math.hypot(x - p.x, y - p.y) < minFromPlayer) {
                continue;
            }
            boolean near = false;
            for (Trash o : trash) {
                if (Math.hypot(o.x - x, o.y - y) < 90) {
                    near = true;
                }
            }
            for (PowerUp o : powers) {
                if (Math.hypot(o.x - x, o.y - y) < 90) {
                    near = true;
                }
            }
            if (near) {
                continue;
            }
            return new Entity(x, y);
        }
        return new Entity(PW / 2.0, PH * 0.6);
    }

    private Entity roamPoint() {
        for (int k = 0; k < 200; k++) {
            double x = 60 + rnd() * (PW - 120), y = 60 + rnd() * (PH - 120);
            if (!inObs(x, y, RT + 6) && !inBin(x, y, RT + 20)) {
                return new Entity(x, y);
            }
        }
        return new Entity(PW / 2.0, 200);
    }

    private Entity lookPoint(Entity c) {
        for (int k = 0; k < 60; k++) {
            double a = rnd() * 6.283, r = 40 + rnd() * 150;
            double x = c.x + Math.cos(a) * r, y = c.y + Math.sin(a) * r;
            if (x < 30 || y < 30 || x > PW - 30 || y > PH - 30 || inObs(x, y, RT + 6) || inBin(x, y, RT + 6)) {
                continue;
            }
            return new Entity(x, y);
        }
        return new Entity(c.x, c.y);
    }

    private void spawnTrash() {
        int inCenter = 0;
        for (Trash t : trash) {
            if (t.zone > 1) {
                inCenter++;
            }
        }
        Entity f = freePoint(220, inCenter < trash.size() / 2.0 ? Want.CENTER : Want.OUTER);
        boolean hard = rnd() < 0.15 + 0.45 * pressure();
        List<Item> list = hard ? Content.hard() : Content.easy();
        Item it = list.get((int) Math.floor(rnd() * list.size()));
        trash.add(new Trash(f.x, f.y, it, zoneOf(f.x, f.y), rnd() * 6));
    }

    private void spawnPower() {
        Entity f = freePoint(160, Want.ANY);
        powers.add(new PowerUp(f.x, f.y, rnd() < .5));
    }

    private void makeTigers() {
        List<Tiger> list = new ArrayList<>();
        if (s.b(Tune.PIRSCH)) {
            list.add(new Tiger(Kind.PIRSCH, Content.tiger(Kind.PIRSCH).name(), PW / 2.0, 40, TState.SEARCH));
        }
        if (s.b(Tune.STREUNER)) {
            Tiger t = new Tiger(Kind.STREUN, Content.tiger(Kind.STREUN).name(), PW - 60, PH * 0.62, TState.ROAM);
            t.rushT = 12;
            list.add(t);
        }
        if (s.b(Tune.SCHLAEFER)) {
            Tiger t = new Tiger(Kind.SCHLAF, Content.tiger(Kind.SCHLAF).name(), 60, PH * 0.45, TState.ROAM);
            t.phase = 9;
            list.add(t);
        }
        for (Tiger t : list) {
            t.wait = 1.5 + rnd(); // unused, but keeps the random sequence identical to the prototype
        }
        tigers = list;
    }

    // ------------------------------------------------------------------ tigers

    private static double angDiff(double a, double b) {
        double x = a - b;
        while (x > Math.PI) {
            x -= 2 * Math.PI;
        }
        while (x < -Math.PI) {
            x += 2 * Math.PI;
        }
        return Math.abs(x);
    }

    private static double turnTo(double cur, double target, double max) {
        double x = target - cur;
        while (x > Math.PI) {
            x -= 2 * Math.PI;
        }
        while (x < -Math.PI) {
            x += 2 * Math.PI;
        }
        return cur + Math.max(-max, Math.min(max, x));
    }

    /** Can this tiger see the player right now (torch cone, line of sight, bush / bin / invisibility)? */
    private boolean sees(Tiger t) {
        if (t.st == TState.SLEEP || p.invis > 0 || p.inv > 0 || p.safe) {
            return false;
        }
        double dd = t.dist(p);
        if (p.hidden) {
            return false;
        }
        if (dd < 45) {
            return true;
        }
        if (dd > s.d(Tune.SIGHT)) {
            return false;
        }
        if (angDiff(Math.atan2(p.y - t.y, p.x - t.x), t.face) > HALF) {
            return false;
        }
        return clear(t.x, t.y, p.x, p.y, 0, false);
    }

    /** Does a sleeping tiger hear the player (walking normally, inside the hearing circle)? */
    private boolean hears(Tiger t) {
        if (p.inv > 0 || p.safe) {
            return false;
        }
        return p.moving && !p.sneak && p.turbo <= 0 && t.dist(p) < s.d(Tune.HEAR);
    }

    /** Next waypoint towards (tx,ty): straight if the way is free, otherwise via the navigation grid. */
    private double[] steerPoint(Tiger t, double tx, double ty) {
        if (clear(t.x, t.y, tx, ty, RT - 2, true)) {
            return new double[] {tx, ty};
        }
        if (t.nav == null || t.navT <= 0 || Math.hypot(t.navX - tx, t.navY - ty) > 40) {
            t.nav = GameMap.navField(tx, ty);
            t.navX = tx;
            t.navY = ty;
            t.navT = 0.4;
        }
        int cx = GameMap.cellX(t.x), cy = GameMap.cellY(t.y);
        int bx = -1, by = -1;
        double bd = 1e9;
        for (int[] d : GameMap.DIRS) {
            int nx = cx + d[0], ny = cy + d[1];
            if (nx < 0 || ny < 0 || nx >= GC || ny >= GR) {
                continue;
            }
            int v = t.nav[nx + ny * GC];
            if (v >= 0 && v < bd) {
                bd = v;
                bx = nx;
                by = ny;
            }
        }
        return bx >= 0 ? new double[] {bx * CS + CS / 2.0, by * CS + CS / 2.0} : new double[] {tx, ty};
    }

    /** Moves the tiger towards the target; returns true when it has arrived. */
    private boolean moveTiger(Tiger t, double tx, double ty, double sp, double dt) {
        t.navT -= dt;
        double[] sp2 = steerPoint(t, tx, ty);
        double dx = sp2[0] - t.x, dy = sp2[1] - t.y, dist = Math.hypot(dx, dy);
        if (dist < 2) {
            return Math.hypot(tx - t.x, ty - t.y) < 14;
        }
        double step = Math.min(dist, sp * dt);
        t.x += dx / dist * step;
        t.y += dy / dist * step;
        t.face = turnTo(t.face, Math.atan2(dy, dx), dt * 5);
        collide(t, RT, TOBS);
        return Math.hypot(tx - t.x, ty - t.y) < 14;
    }

    private void backToNormal(Tiger t) {
        if (t.kind == Kind.PIRSCH) {
            t.st = TState.SEARCH;
            t.r = 340;
        } else if (t.kind == Kind.STREUN) {
            t.st = TState.ROAM;
            t.tgt = null;
            t.rushT = 8 + rnd() * 6;
        } else {
            t.st = TState.ROAM;
            t.tgt = null;
            t.phase = 8 + rnd() * 4;
        }
    }

    private void updateTiger(Tiger t, double dt) {
        double mul = s.d(Tune.TIGER) * (1 + 0.5 * pressure());
        boolean see = t.st != TState.SLEEP && sees(t);
        if (see) {
            if (t.st != TState.CHASE) {
                addFx("!", t.x, t.y - 30, DANGER);
                showTip("seen");
            }
            t.st = TState.CHASE;
            t.lost = 0;
            t.tgt = new Entity(p.x, p.y);
        }
        if (t.st == TState.CHASE) {
            if (!see) {
                t.lost += dt;
            }
            double fast = t.kind == Kind.PIRSCH ? 160 : (t.kind == Kind.STREUN ? 165 : 170);
            boolean arrived = moveTiger(t, t.tgt.x, t.tgt.y, fast * mul, dt);
            // not seen for a while: stop chasing and search the area
            if (t.lost > 3 || (arrived && t.lost > 0.4) || (p.safe && t.lost > 0.3)) {
                t.st = TState.LOOK;
                t.lookT = 7;
                t.center = new Entity(t.tgt.x, t.tgt.y);
                t.lp = null;
                addFx("?", t.x, t.y - 30, YELLOW);
            }
        } else if (t.st == TState.LOOK || t.st == TState.INVESTIGATE) {
            if (t.st == TState.INVESTIGATE) {
                if (moveTiger(t, t.tgt.x, t.tgt.y, 60 * mul, dt)) {
                    t.st = TState.LOOK;
                    t.lookT = 4;
                    t.center = new Entity(t.tgt.x, t.tgt.y);
                    t.lp = null;
                }
            } else {
                t.lookT -= dt;
                if (t.lp == null) {
                    t.lp = lookPoint(t.center);
                    t.pause = 0;
                }
                if (moveTiger(t, t.lp.x, t.lp.y, 80 * mul, dt)) {
                    t.pause += dt;
                    t.face += dt * 2.2;
                    if (t.pause > 0.9) {
                        t.lp = null;
                    }
                }
                if (t.lookT <= 0) {
                    backToNormal(t);
                }
            }
        } else if (t.kind == Kind.PIRSCH) {
            // flank: aim for a point beside the player; the distance shrinks slowly.
            // In a bush, invisible or in a safe zone he loses the trail.
            if (p.hidden || p.invis > 0 || p.safe) {
                t.r = Math.min(340, t.r + 25 * dt);
            } else {
                t.r = Math.max(0, t.r - (10 + 20 * pressure()) * dt);
            }
            double toT = Math.atan2(t.y - p.y, t.x - p.x);
            double side = p.face + (angDiff(p.face + Math.PI / 2, toT) < angDiff(p.face - Math.PI / 2, toT) ? Math.PI / 2 : -Math.PI / 2);
            double a = side * 0.65 + toT * 0.35;
            double rr = Math.max(t.r, p.safe ? 220 : 0);
            double tx = p.x + Math.cos(a) * rr, ty = p.y + Math.sin(a) * rr;
            tx = Math.max(30, Math.min(PW - 30, tx));
            ty = Math.max(30, Math.min(PH - 30, ty));
            boolean arrived = moveTiger(t, tx, ty, 72 * mul, dt);
            if (arrived || t.r < 120) {
                t.face = turnTo(t.face, Math.atan2(p.y - t.y, p.x - t.x), dt * 1.6);
            }
        } else if (t.kind == Kind.STREUN) {
            if (t.st == TState.RUSH) {
                t.rushLeft -= dt;
                moveTiger(t, p.x, p.y, 135 * mul, dt);
                if (t.rushLeft <= 0 || p.safe) {
                    t.st = TState.ROAM;
                    t.rushT = 9 + rnd() * 7;
                }
            } else {
                if (t.tgt == null) {
                    t.tgt = roamPoint();
                }
                if (moveTiger(t, t.tgt.x, t.tgt.y, 85 * mul, dt)) {
                    t.tgt = roamPoint();
                }
                t.rushT -= dt;
                if (t.rushT <= 0 && !p.safe) {
                    t.st = TState.RUSH;
                    t.rushLeft = 3;
                    addFx("!?", t.x, t.y - 30, YELLOW);
                }
            }
        } else {
            // Schläfer: awake = torch like the others, asleep = only a hearing circle
            if (t.st == TState.SLEEP) {
                if (hears(t)) {
                    t.st = TState.CHASE;
                    t.lost = 0;
                    t.tgt = new Entity(p.x, p.y);
                    addFx(Texts.t("fx.woke"), t.x, t.y - 34, DANGER);
                } else {
                    t.phase -= dt;
                    if (t.phase <= 0) {
                        t.st = TState.ROAM;
                        t.phase = 9 + rnd() * 5;
                    }
                }
            } else {
                if (t.tgt == null) {
                    t.tgt = roamPoint();
                }
                if (moveTiger(t, t.tgt.x, t.tgt.y, 70 * mul, dt)) {
                    t.tgt = roamPoint();
                }
                t.phase -= dt;
                if (t.phase <= 0) {
                    t.st = TState.SLEEP;
                    t.phase = 10 + rnd() * 5;
                }
            }
        }
        if (p.inv <= 0 && !p.safe && t.dist(p) < RP + RT - 4) {
            caught();
        }
    }

    /** A loud noise: every tiger that is not chasing walks over to have a look. */
    private void noise(double x, double y, double r) {
        pulses.add(new Pulse(x, y, r));
        for (Tiger t : tigers) {
            if (t.st != TState.CHASE && Math.hypot(t.x - x, t.y - y) <= r) {
                t.st = TState.INVESTIGATE;
                t.tgt = new Entity(x, y);
                addFx("?", t.x, t.y - 30, YELLOW);
            }
        }
    }

    // ------------------------------------------------------------------ rules

    private void sortInto(Bin bin) {
        Bag b = bag;
        Item it = b.it;
        if (it.mat() != bin.mat()) {
            // wrong bin: lose points, short explanation, the run goes on
            b.wrongs++;
            stats.wrong++;
            score = Math.max(0, score - s.i(Tune.PEN_WRONG));
            dep.get(it.mat()).mix.merge(it.name(), 1, Integer::sum);
            addFx(Texts.t("fx.wrong", "pen", s.i(Tune.PEN_WRONG)), p.x, p.y - 30, DANGER);
            feedback(Texts.t("fb.wrong.title", "bin", bin.mat().label()), it.why(), DANGER, 3.5);
            return;
        }
        Deposit q = dep.get(it.mat());
        q.n++;
        q.g += it.grams();
        if (it.co2() > 0) {
            q.co2 += it.grams() * it.co2();
        }
        if (it.pet()) {
            q.pet++;
        }
        if (b.wrongs == 0) {
            q.first++;
            stats.first++;
        }
        total++;
        int pts = (int) Math.round(100 * b.zone * timeMul());
        score += pts;
        double a = addTime(s.d(Tune.BONUS_BIN));
        addFx(pointsText("fx.right", pts, a), p.x, p.y - 30, LIME);
        if (it.mat() == Material.METALL) {
            p.turbo = Math.max(p.turbo, 3);
            feedback(Texts.t("fb.speed.title"), Texts.t("fb.speed.text"), YELLOW, 2.8);
        } else if (b.wrongs > 0) {
            feedback(Texts.t("fb.fixed.title"), it.why(), LIME, 2.6);
        }
        bag = null;
    }

    private void caught() {
        if (over) {
            return;
        }
        lives--;
        stats.caught++;
        addFx(Texts.t(bag != null ? "fx.caught_lost" : "fx.caught"), p.x, p.y - 30, DANGER);
        bag = null;
        scan = null;
        p.x = CAMP_X;
        p.y = CAMP_Y;
        p.inv = 2.2;
        p.skip = null;
        p.bin = null;
        makeTigers();
        if (lives <= 0) {
            finish(Texts.t("end.lives"));
        }
    }

    // ------------------------------------------------------------------ frame update

    /** Advances the run by {@code dt} seconds. */
    public void update(double dt, Input in) {
        double tm = timeMul();
        time -= dt;
        elapsed += dt;
        p.inv = Math.max(0, p.inv - dt);
        p.invis = Math.max(0, p.invis - dt);
        p.turbo = Math.max(0, p.turbo - dt);
        p.msg = Math.max(0, p.msg - dt);
        Input.Move mv = in.readMove();
        boolean moveKey = mv.x() != 0 || mv.y() != 0;
        if (scan != null) {
            Scan sc = scan;
            sc.age += dt;
            sc.u += sc.dir * s.d(Tune.BAR) * dt;
            if (sc.u > 1) {
                sc.u = 1;
                sc.dir = -1;
            }
            if (sc.u < 0) {
                sc.u = 0;
                sc.dir = 1;
            }
            p.moving = false;
            if (moveKey && sc.age > 0.35) {
                scan = null;
                p.skip = sc.tr;
                addFx(Texts.t("fx.cancel"), p.x, p.y - 30, PAPER);
            } else if (in.actionQ && sc.age > 0.08) {
                boolean inGreen = Math.abs(sc.u - 0.5) <= s.d(Tune.GREEN) / 200;
                Trash tr = sc.tr;
                trash.remove(tr);
                stats.scans++;
                bag = new Bag(tr.it, tr.zone);
                if (inGreen) {
                    int pts = (int) Math.round(50 * tm);
                    score += pts;
                    stats.green++;
                    double a = addTime(s.d(Tune.BONUS_SCAN));
                    addFx(pointsText("fx.perfect", pts, a), p.x, p.y - 30, LIME);
                } else {
                    noise(p.x, p.y, s.d(Tune.NOISE_R));
                    addFx(Texts.t("fx.miss"), p.x, p.y - 30, DANGER);
                }
                feedback(Texts.t("fb.found.title", "item", tr.it.name()), Texts.t("fb.found.text"), PAPER, 2.2);
                glowT = tips.contains("hand") ? 0 : 4;
                showTip("hand");
                scan = null;
                spawnTrash();
            }
        } else {
            p.sneak = mv.sneak() && p.turbo <= 0;
            double sp = p.turbo > 0 ? 300 : (p.sneak ? 90 : 190);
            p.moving = moveKey;
            if (p.moving) {
                p.x += mv.x() * sp * dt;
                p.y += mv.y() * sp * dt;
                p.face = Math.atan2(mv.y(), mv.x());
            }
            collide(p, RP, OBS);
            if (p.skip != null && p.dist(p.skip) > 40) {
                p.skip = null;
            }
            if (bag == null) {
                for (Trash o : trash) {
                    if (o.dist(p) < 170) {
                        showTip("near");
                        break;
                    }
                }
            }
            for (Tiger t : tigers) {
                if (t.st == TState.SLEEP && t.dist(p) < s.d(Tune.HEAR) + 80) {
                    showTip("sneak");
                    break;
                }
            }
            Trash hit = null;
            for (Trash o : trash) {
                if (o.dist(p) < 26 && o != p.skip) {
                    hit = o;
                    break;
                }
            }
            if (hit != null) {
                if (bag != null) {
                    if (p.msg <= 0) {
                        addFx(Texts.t("fx.hands_full"), p.x, p.y - 30, YELLOW);
                        p.msg = 1.6;
                    }
                } else {
                    scan = new Scan(hit);
                    p.x = hit.x;
                    p.y = hit.y;
                }
            }
            PowerUp pw = null;
            for (PowerUp o : powers) {
                if (o.dist(p) < 26) {
                    pw = o;
                    break;
                }
            }
            if (pw != null) {
                powers.remove(pw);
                if (pw.turbo) {
                    p.turbo = s.d(Tune.POWER);
                    addFx(Texts.t("fx.turbo"), p.x, p.y - 30, YELLOW);
                    showTip("turbo", "sec", num(s.d(Tune.POWER)));
                } else {
                    p.invis = s.d(Tune.POWER);
                    addFx(Texts.t("fx.invis"), p.x, p.y - 30, ICE);
                    showTip("invis", "sec", num(s.d(Tune.POWER)));
                }
            }
            Bin inBinNow = null;
            for (Bin b : BINS) {
                GameMap.Rect r = b.rect();
                if (p.x > r.x() && p.x < r.x() + r.w() && p.y > r.y() && p.y < r.y() + r.h()) {
                    inBinNow = b;
                    break;
                }
            }
            boolean entered = inBinNow != null && inBinNow != p.bin;
            p.bin = inBinNow;
            if (entered && bag != null) {
                sortInto(inBinNow);
            }
        }
        p.hidden = false;
        for (Bush b : BUSHES) {
            if (Math.hypot(p.x - b.x(), p.y - b.y()) < b.r() - 4) {
                p.hidden = true;
                break;
            }
        }
        p.safe = p.bin != null;
        powerT -= dt;
        if (powerT <= 0) {
            if (powers.size() < 2) {
                spawnPower();
            }
            powerT = 12 + rnd() * 8;
        }
        for (PowerUp o : powers) {
            o.life -= dt;
        }
        powers.removeIf(o -> o.life <= 0);
        List<Tiger> list = tigers; // caught() may replace the list while we iterate
        for (Tiger t : list) {
            if (!over) {
                updateTiger(t, dt);
            }
        }
        for (Pulse q : pulses) {
            q.t += dt;
        }
        pulses.removeIf(q -> q.t >= 0.9);
        for (Deposit q : dep.values()) {
            q.disp += (q.n - q.disp) * Math.min(1, dt * 4);
        }
        for (Fx f : fx) {
            f.t += dt;
        }
        fx.removeIf(f -> f.t > 1.5);
        if (fb != null) {
            fb.t += dt;
            if (fb.t > fb.dur) {
                fb = null;
            }
        }
        if (tip != null) {
            tip.t += dt;
            if (tip.t > tip.dur) {
                tip = null;
            }
        }
        if (glowT > 0) {
            glowT = Math.max(0, glowT - dt);
        }
        if (!over && time <= 0) {
            time = 0;
            finish(Texts.t("end.time"));
        }
    }

    // ------------------------------------------------------------------ summary

    /**
     * Headline of the summary: the item that was mixed up most often (first one wins a tie), otherwise a general fact
     * about the material with the most pieces (or a random material when nothing was thrown away: one random number).
     */
    public MainFact mainFact() {
        Material bestMat = null;
        String bestItem = null;
        int bc = 0;
        for (Material m : Material.values()) {
            for (Map.Entry<String, Integer> e : dep.get(m).mix.entrySet()) {
                if (e.getValue() > bc) {
                    bc = e.getValue();
                    bestMat = m;
                    bestItem = e.getKey();
                }
            }
        }
        if (bestMat != null) {
            String why = "";
            for (Item it : Content.items()) {
                if (it.name().equals(bestItem)) {
                    why = it.why();
                    break;
                }
            }
            return new MainFact(bestMat, Texts.t("mainfact.confused", "item", bestItem, "bin", bestMat.label()), why, Content.fact(bestMat, 0));
        }
        Material k = Material.values()[0];
        for (Material m : Material.values()) {
            if (dep.get(m).n > dep.get(k).n) {
                k = m;
            }
        }
        if (dep.get(k).n == 0) {
            k = Material.values()[(int) Math.floor(rnd() * Material.values().length)];
        }
        return new MainFact(k, Texts.t("mainfact.general"), "", Content.fact(k, 0));
    }
}
