package drivebuytiger;

import java.awt.Color;

/** Colours of the game (same palette as the web prototype). */
public final class Palette {
    private Palette() {}

    public static final Color JUNGLE = new Color(0x0F2A1B);
    public static final Color LEAF = new Color(0x1A4A2C);
    public static final Color MOSS = new Color(0x2B7A47);
    public static final Color PAPER = new Color(0xF4EFDC);
    public static final Color PAPER_DIM = new Color(0xCFE3C0);
    public static final Color TIGER = new Color(0xF28C1B);
    public static final Color LIME = new Color(0x8FE05A);
    public static final Color DANGER = new Color(0xE4472B);
    public static final Color INK = new Color(0x16301F);
    public static final Color INK_SOFT = new Color(0x3C5A46);
    public static final Color INK_DARK = new Color(0x1B1408);
    public static final Color SKY = new Color(0x9ED0F0);
    public static final Color YELLOW = new Color(0xFFE27A);
    public static final Color ICE = new Color(0xB9DDF0);
    /** Green of the scan bar and of correct answers. */
    public static final Color GOOD = new Color(0x2FB05A);

    /** Colour with alpha as fraction 0..1 (like CSS rgba). */
    public static Color rgba(int r, int g, int b, double a) {
        return new Color(r, g, b, (int) Math.round(Math.max(0, Math.min(1, a)) * 255));
    }

    public static Color alpha(Color c, double a) {
        return rgba(c.getRed(), c.getGreen(), c.getBlue(), a);
    }
}
