package drivebuytiger;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * One-time import of the files that earlier versions of the game wrote ({@code highscores.txt} and
 * {@code settings.properties} in the data folder), so that nobody loses the scoreboard when the game moves to the database.
 * The files are only read, never changed or deleted. It runs once per database (see meta.legacy_import).
 */
final class Legacy {
    private Legacy() {}

    /** Imports the old files if that did not happen yet; returns a short report, or null when there was nothing to import. */
    static String importIfNeeded(Db db, Path dir) throws SQLException {
        if (db.text("SELECT value FROM meta WHERE key = 'legacy_import'") != null) {
            return null;
        }
        Path scoreFile = dir.resolve("highscores.txt");
        Path settingFile = dir.resolve("settings.properties");
        int[] n = db.transaction(d -> {
            int scores = 0;
            int settings = 0;
            if (Files.isRegularFile(scoreFile) && d.count("highscore") == 0) {
                scores = importScores(d, scoreFile);
            }
            if (Files.isRegularFile(settingFile)) {
                settings = importSettings(d, settingFile);
            }
            d.update("INSERT OR REPLACE INTO meta (key, value) VALUES ('legacy_import', ?)", "scores " + scores + ", settings " + settings);
            return new int[] {scores, settings};
        });
        return n[0] + n[1] == 0 ? null : n[0] + " scores and " + n[1] + " slider values from " + dir;
    }

    private record Row(String name, int score, long time) {}

    private static int importScores(Db db, Path file) throws SQLException {
        List<Row> rows = new ArrayList<>();
        try {
            for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
                String[] p = line.split(";");
                if (p.length != 3) {
                    continue;
                }
                try {
                    rows.add(new Row(p[0], Integer.parseInt(p[1].trim()), Long.parseLong(p[2].trim())));
                } catch (NumberFormatException ignored) {
                    // skip a broken line
                }
            }
        } catch (IOException e) {
            System.err.println("Could not read " + file + ": " + e.getMessage());
            return 0;
        }
        rows.sort((a, b) -> Long.compare(a.time(), b.time())); // oldest first: the ids then grow with the age
        for (Row r : rows) {
            db.update("INSERT INTO highscore (name, score, played_at) VALUES (?, ?, ?)", r.name(), r.score(), r.time());
        }
        return rows.size();
    }

    private static int importSettings(Db db, Path file) throws SQLException {
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            p.load(r);
        } catch (IOException | IllegalArgumentException e) {
            System.err.println("Could not read " + file + ": " + e.getMessage());
            return 0;
        }
        Map<String, double[]> range = new HashMap<>(); // key -> {min, max, default}
        db.query("SELECT key, min_value, max_value, default_value FROM tuning", rs -> {
            range.put(rs.getString(1), new double[] {rs.getDouble(2), rs.getDouble(3), rs.getDouble(4)});
            return Boolean.TRUE;
        });
        int n = 0;
        for (Map.Entry<String, double[]> e : range.entrySet()) {
            String s = p.getProperty(e.getKey());
            if (s == null) {
                continue;
            }
            try {
                double[] r = e.getValue();
                double v = Math.max(r[0], Math.min(r[1], Double.parseDouble(s.trim())));
                if (Math.abs(v - r[2]) > 1e-9) {
                    db.update("INSERT OR REPLACE INTO setting (key, value) VALUES (?, ?)", e.getKey(), v);
                    n++;
                }
            } catch (NumberFormatException ignored) {
                // keep the default
            }
        }
        return n;
    }
}
