package drivebuytiger;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

/**
 * Highscore list in the table {@code highscore} of the database (name = three initials, score, time in milliseconds).
 * The in-game scoreboard shows only the entries of today, like the web prototype. At most {@value #MAX_ENTRIES} entries
 * are kept (the oldest ones are deleted).
 */
public final class HighScores {
    /** One saved score. Two entries are the same when they have the same row id. */
    public static final class Entry {
        public final long id;
        public final String name;
        public final int score;
        public final long time;

        Entry(long id, String name, int score, long time) {
            this.id = id;
            this.name = name;
            this.score = score;
            this.time = time;
        }

        @Override
        public boolean equals(Object o) {
            return o instanceof Entry e && e.id == id;
        }

        @Override
        public int hashCode() {
            return Long.hashCode(id);
        }
    }

    private static final int MAX_ENTRIES = 300;

    private final Db db;

    public HighScores(Db db) {
        this.db = db;
    }

    /** A list that lives in a private in-memory database (nothing is stored on disk). */
    public static HighScores inMemory() {
        try {
            return new HighScores(Seeder.seededMemory());
        } catch (SQLException | IOException e) {
            throw new IllegalStateException("Could not create the in-memory database: " + e.getMessage(), e);
        }
    }

    /** Entries of today, best score first (newest first among equal scores). */
    public List<Entry> today() {
        ZoneId zone = ZoneId.systemDefault();
        LocalDate today = LocalDate.now(zone);
        long from = today.atStartOfDay(zone).toInstant().toEpochMilli();
        long to = today.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli();
        try {
            return db.query("SELECT id, name, score, played_at FROM highscore WHERE played_at >= ? AND played_at < ? ORDER BY score DESC, id DESC",
                rs -> new Entry(rs.getLong(1), rs.getString(2), rs.getInt(3), rs.getLong(4)), from, to);
        } catch (SQLException e) {
            System.err.println("Could not read highscores: " + e.getMessage());
            return List.of();
        }
    }

    public Entry add(String name, int score) {
        long now = System.currentTimeMillis();
        try {
            return db.transaction(d -> {
                d.update("INSERT INTO highscore (name, score, played_at) VALUES (?, ?, ?)", name, score, now);
                Long id = d.queryOne("SELECT last_insert_rowid()", rs -> rs.getLong(1));
                d.update("DELETE FROM highscore WHERE id NOT IN (SELECT id FROM highscore ORDER BY played_at DESC, id DESC LIMIT " + MAX_ENTRIES + ")");
                return new Entry(id == null ? -1 : id, name, score, now);
            });
        } catch (SQLException e) {
            System.err.println("Could not save highscores: " + e.getMessage());
            return new Entry(-1, name, score, now);
        }
    }

    public void clear() {
        try {
            db.update("DELETE FROM highscore");
        } catch (SQLException e) {
            System.err.println("Could not clear highscores: " + e.getMessage());
        }
    }
}
