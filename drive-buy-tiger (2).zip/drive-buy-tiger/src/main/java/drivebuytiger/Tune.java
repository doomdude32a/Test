package drivebuytiger;

import java.util.Locale;

/**
 * All adjustable game parameters ("Regler fürs Spielkonzept"). The enum only names them; label, unit, range, step and
 * default come from the table {@code tuning} of the database (see {@link Content}).
 */
public enum Tune {
    PIRSCH("tPirsch"),
    STREUNER("tStreun"),
    SCHLAEFER("tSchlaf"),
    START_TIME("startTime"),
    MAX_TIME("maxTime"),
    BONUS_SCAN("bonusScan"),
    BONUS_BIN("bonusBin"),
    PEN_WRONG("penWrong"),
    QUIZ("quiz"),
    TIGER("tiger"),
    SIGHT("sight"),
    HEAR("hear"),
    LIVES("lives"),
    TRASH("trash"),
    GREEN("green"),
    BAR("bar"),
    POWER("power"),
    NOISE_R("noiseR");

    /** Key in the database (tuning.key and setting.key). */
    public final String key;

    Tune(String key) {
        this.key = key;
    }

    public String label() {
        return Content.tune(this).label();
    }

    /** Text behind the value, e.g. " s". */
    public String unit() {
        return Content.tune(this).unit();
    }

    public double min() {
        return Content.tune(this).min();
    }

    public double max() {
        return Content.tune(this).max();
    }

    public double step() {
        return Content.tune(this).step();
    }

    public double def() {
        return Content.tune(this).def();
    }

    /** true = checkbox (on/off), false = slider. */
    public boolean bool() {
        return Content.tune(this).bool();
    }

    /** Value text as shown next to a slider: one decimal if the step is below 1. */
    public String format(double v) {
        double step = step();
        String num = step < 1 ? String.format(Locale.ROOT, "%.1f", v) : (v == Math.rint(v) ? String.valueOf((long) v) : String.valueOf(v));
        return num + unit();
    }
}
