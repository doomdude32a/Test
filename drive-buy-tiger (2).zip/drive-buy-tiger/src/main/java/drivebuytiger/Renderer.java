package drivebuytiger;

import static drivebuytiger.GameMap.BINS;
import static drivebuytiger.GameMap.BUSHES;
import static drivebuytiger.GameMap.CAMP_X;
import static drivebuytiger.GameMap.CAMP_Y;
import static drivebuytiger.GameMap.H;
import static drivebuytiger.GameMap.HUD;
import static drivebuytiger.GameMap.KX;
import static drivebuytiger.GameMap.KY;
import static drivebuytiger.GameMap.OBS;
import static drivebuytiger.GameMap.PH;
import static drivebuytiger.GameMap.PW;
import static drivebuytiger.GameMap.W;
import static drivebuytiger.GameMap.inObs;
import static drivebuytiger.Palette.DANGER;
import static drivebuytiger.Palette.GOOD;
import static drivebuytiger.Palette.ICE;
import static drivebuytiger.Palette.INK;
import static drivebuytiger.Palette.INK_DARK;
import static drivebuytiger.Palette.INK_SOFT;
import static drivebuytiger.Palette.JUNGLE;
import static drivebuytiger.Palette.LEAF;
import static drivebuytiger.Palette.LIME;
import static drivebuytiger.Palette.MOSS;
import static drivebuytiger.Palette.PAPER;
import static drivebuytiger.Palette.PAPER_DIM;
import static drivebuytiger.Palette.SKY;
import static drivebuytiger.Palette.TIGER;
import static drivebuytiger.Palette.YELLOW;
import static drivebuytiger.Palette.rgba;
import static drivebuytiger.Txt.Align.CENTER;
import static drivebuytiger.Txt.Align.LEFT;
import static drivebuytiger.Txt.Align.RIGHT;

import drivebuytiger.Content.Question;
import drivebuytiger.Game.Bag;
import drivebuytiger.Game.Deposit;
import drivebuytiger.Game.Fx;
import drivebuytiger.Game.Kind;
import drivebuytiger.Game.Player;
import drivebuytiger.Game.PowerUp;
import drivebuytiger.Game.Pulse;
import drivebuytiger.Game.TState;
import drivebuytiger.Game.Tiger;
import drivebuytiger.Game.Trash;
import drivebuytiger.GameMap.Bin;
import drivebuytiger.GameMap.Bush;
import drivebuytiger.GameMap.Rect;
import drivebuytiger.Txt.Align;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.NoninvertibleTransformException;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Draws everything with Java2D. A port of the canvas drawing code of the web prototype:
 * the logical canvas is 1560 x 1050 units and is scaled (letterboxed) into the window.
 */
public final class Renderer {
    /** Clickable area on the current screen (answer buttons, summary and scoreboard buttons). */
    public record Hotspot(Shape area, Runnable action) {}

    private static final Color ORANGE_DARK = new Color(0xC46A00);

    private final Session ses;
    private static final long RESIZE_SETTLE_NANOS = 200_000_000L;

    private BufferedImage bg;
    private int bgW, bgH;
    private int lastIw, lastIh;
    private long sizeChangedAt;
    private double viewOx, viewOy, viewScale = 1, devScale = 1;
    private AffineTransform logicalInv = new AffineTransform();
    private final List<Hotspot> hotspots = new ArrayList<>();
    private double now;

    private final DateTimeFormatter day = DateTimeFormatter.ofPattern(Texts.t("format.date"));

    public Renderer(Session session) {
        this.ses = session;
    }

    // ================================================================== entry points

    /**
     * Paints one frame.
     *
     * @param g the graphics of a component of size compW x compH (HiDPI scaling in its transform is respected)
     * @param nowSec time in seconds, only used for animations
     */
    public void paint(Graphics2D g, int compW, int compH, double nowSec) {
        now = nowSec;
        hotspots.clear();
        hints(g);
        AffineTransform base = g.getTransform();
        double d = Math.hypot(base.getScaleX(), base.getShearY());
        if (d <= 0) {
            d = 1;
        }
        int devW = (int) Math.round(compW * d), devH = (int) Math.round(compH * d);
        if (devW < 16 || devH < 16) {
            return;
        }
        double sc = Math.min(devW / (double) W, devH / (double) H);
        int iw = Math.max(1, (int) Math.round(W * sc)), ih = Math.max(1, (int) Math.round(H * sc));
        int ox = (devW - iw) / 2, oy = (devH - ih) / 2;
        devScale = d;
        viewOx = ox;
        viewOy = oy;
        viewScale = iw / (double) W;

        g.scale(1 / d, 1 / d); // now 1 unit = 1 device pixel
        g.setColor(JUNGLE);
        g.fillRect(0, 0, devW, devH);
        // The jungle is pre-rendered for the current size. While the window is being dragged larger or smaller the
        // old picture is simply stretched, and the sharp one is built as soon as the size has been stable for a moment.
        long tNow = System.nanoTime();
        if (iw != lastIw || ih != lastIh) {
            lastIw = iw;
            lastIh = ih;
            sizeChangedAt = tNow;
        }
        boolean sizeDiffers = bg == null || bgW != iw || bgH != ih;
        if (sizeDiffers && (bg == null || tNow - sizeChangedAt > RESIZE_SETTLE_NANOS)) {
            bg = buildBg(iw, ih);
            bgW = iw;
            bgH = ih;
        }
        g.drawImage(bg, ox, oy, iw, ih, null);
        g.translate(ox, oy);
        g.scale(iw / (double) W, ih / (double) H); // now 1 unit = 1 logical canvas unit
        g.clipRect(0, 0, W, H);
        try {
            logicalInv = g.getTransform().createInverse();
        } catch (NoninvertibleTransformException e) {
            logicalInv = new AffineTransform();
        }
        drawScene(g);
    }

    /** Converts component pixel coordinates (mouse) to logical canvas coordinates. */
    public Point2D toLogical(double mx, double my) {
        return new Point2D.Double((mx * devScale - viewOx) / viewScale, (my * devScale - viewOy) / viewScale);
    }

    /** Runs the action of the topmost hotspot at the logical position; returns whether one was hit. */
    public boolean click(double lx, double ly) {
        for (int i = hotspots.size() - 1; i >= 0; i--) {
            Hotspot h = hotspots.get(i);
            if (h.area().contains(lx, ly)) {
                h.action().run();
                return true;
            }
        }
        return false;
    }

    private void hotspot(Graphics2D g, Shape area, Runnable action) {
        AffineTransform rel = new AffineTransform(logicalInv);
        rel.concatenate(g.getTransform());
        hotspots.add(new Hotspot(rel.createTransformedShape(area), action));
    }

    private static void hints(Graphics2D g) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
    }

    // ================================================================== small drawing helpers

    private static RoundRectangle2D rr(double x, double y, double w, double h, double r) {
        return new RoundRectangle2D.Double(x, y, w, h, 2 * r, 2 * r);
    }

    private static Ellipse2D circle(double cx, double cy, double r) {
        return new Ellipse2D.Double(cx - r, cy - r, 2 * r, 2 * r);
    }

    private static Ellipse2D ellipse(double cx, double cy, double rx, double ry) {
        return new Ellipse2D.Double(cx - rx, cy - ry, 2 * rx, 2 * ry);
    }

    /** Canvas-style arc (angles in radians, clockwise on screen). */
    private static Arc2D arc(double cx, double cy, double r, double a0, double a1) {
        return new Arc2D.Double(cx - r, cy - r, 2 * r, 2 * r, -Math.toDegrees(a0), -Math.toDegrees(a1 - a0), Arc2D.OPEN);
    }

    private static void fill(Graphics2D g, Color c, Shape s) {
        g.setColor(c);
        g.fill(s);
    }

    private static void line(Graphics2D g, Color c, double w, Shape s) {
        line(g, c, w, BasicStroke.CAP_BUTT, s);
    }

    private static void line(Graphics2D g, Color c, double w, int cap, Shape s) {
        g.setColor(c);
        g.setStroke(new BasicStroke((float) w, cap, BasicStroke.JOIN_MITER, 10f));
        g.draw(s);
    }

    private static void dashed(Graphics2D g, Color c, double w, float on, float off, Shape s) {
        g.setColor(c);
        g.setStroke(new BasicStroke((float) w, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10f, new float[] {on, off}, 0f));
        g.draw(s);
    }

    private static void t(Graphics2D g, Font f, Color c, String s, double x, double y, Align a) {
        Txt.draw(g, f, c, s, x, y, a, false);
    }

    /** Text with the vertical middle at y (canvas textBaseline = middle). */
    private static void tm(Graphics2D g, Font f, Color c, String s, double x, double y, Align a) {
        Txt.draw(g, f, c, s, x, y, a, true);
    }

    private static void alpha(Graphics2D g, double a) {
        g.setComposite(AlphaComposite.SrcOver.derive((float) Math.max(0, Math.min(1, a))));
    }

    private static void opaque(Graphics2D g) {
        g.setComposite(AlphaComposite.SrcOver);
    }

    private static String num(double v) {
        return v == Math.rint(v) ? String.valueOf((long) v) : String.valueOf(v);
    }

    // ================================================================== background (pre-rendered)

    /** Seeded generator of the prototype (so that the jungle looks exactly the same). */
    private static final class Lehmer {
        private long s;

        Lehmer(long seed) {
            s = seed;
        }

        double next() {
            s = (s * 16807L) % 2147483647L;
            return (s - 1) / 2147483646.0;
        }
    }

    private BufferedImage buildBg(int iw, int ih) {
        BufferedImage img = new BufferedImage(iw, ih, BufferedImage.TYPE_INT_RGB);
        Graphics2D b = img.createGraphics();
        hints(b);
        b.scale(iw / (double) W, ih / (double) H);
        Lehmer r = new Lehmer(11);

        fill(b, new Color(0x0C2616), new Rectangle2D.Double(0, 0, W, HUD));
        b.translate(0, HUD);
        fill(b, new Color(0x2E6A3F), new Rectangle2D.Double(0, 0, PW, PH));

        // sandy tracks (drawn in the 1200 x 720 design grid, like the prototype)
        AffineTransform keep = b.getTransform();
        b.scale(KX, KY);
        Path2D.Double path = new Path2D.Double();
        path.moveTo(600, 720);
        path.lineTo(600, 600);
        path.curveTo(600, 480, 520, 460, 500, 460);
        path.lineTo(200, 460);
        path.moveTo(600, 600);
        path.curveTo(600, 480, 680, 460, 700, 460);
        path.lineTo(1000, 460);
        path.moveTo(200, 460);
        path.lineTo(200, 230);
        path.lineTo(500, 230);
        path.moveTo(1000, 460);
        path.lineTo(1000, 230);
        path.lineTo(700, 230);
        path.moveTo(500, 230);
        path.lineTo(700, 230);
        path.moveTo(200, 230);
        path.lineTo(90, 90);
        path.moveTo(1000, 230);
        path.lineTo(1110, 90);
        path.moveTo(200, 460);
        path.lineTo(90, 650);
        path.moveTo(1000, 460);
        path.lineTo(1110, 650);
        b.setColor(rgba(196, 160, 96, .22));
        b.setStroke(new BasicStroke(40f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        b.draw(path);
        b.setTransform(keep);

        // leaf texture
        for (int i = 0; i < 1100; i++) {
            double x = r.next() * PW, y = r.next() * PH, s = 5 + r.next() * 12;
            AffineTransform t0 = b.getTransform();
            b.translate(x, y);
            b.rotate(r.next() * 6.28);
            b.setColor(r.next() < .5 ? rgba(20, 64, 34, .38) : rgba(90, 160, 95, .18));
            b.fill(new Ellipse2D.Double(-s, -s * .42, 2 * s, 2 * s * .42));
            b.setTransform(t0);
        }

        // obstacles: thicket
        for (Rect o : OBS) {
            fill(b, rgba(0, 0, 0, .25), rr(o.x() + 5, o.y() + 7, o.w(), o.h(), 18));
            fill(b, new Color(0x123F22), rr(o.x(), o.y(), o.w(), o.h(), 18));
            int n = Math.max(3, (int) Math.round((o.w() + o.h()) / 30));
            for (int k = 0; k < n * 2; k++) {
                double x = o.x() + 10 + r.next() * (o.w() - 20), y = o.y() + 10 + r.next() * (o.h() - 20);
                Color c = k % 3 != 0 ? new Color(0x1A5530) : new Color(0x20653A);
                fill(b, c, circle(x, y, 10 + r.next() * 10));
            }
            for (int k = 0; k < n; k++) {
                double x = o.x() + 10 + r.next() * (o.w() - 20), y = o.y() + 8 + r.next() * (o.h() - 16);
                fill(b, rgba(143, 224, 90, .14), circle(x, y, 4 + r.next() * 4));
            }
        }

        // jungle edge
        for (int i = 0; i < 100; i++) {
            double x, y;
            int side = i % 4;
            if (side == 0) {
                x = r.next() * PW;
                y = -6 + r.next() * 10;
            } else if (side == 1) {
                x = r.next() * PW;
                y = PH + 6 - r.next() * 10;
            } else if (side == 2) {
                x = -6 + r.next() * 10;
                y = r.next() * PH;
            } else {
                x = PW + 6 - r.next() * 10;
                y = r.next() * PH;
            }
            boolean inBin = false;
            for (Bin bn : BINS) {
                Rect q = bn.rect();
                if (x > q.x() - 20 && x < q.x() + q.w() + 20 && y > q.y() - 20 && y < q.y() + q.h() + 20) {
                    inBin = true;
                }
            }
            if (inBin) {
                continue;
            }
            fill(b, new Color(0x143D22), circle(x, y, 16 + r.next() * 16));
        }

        // corners (safe zones): tinted floor with a dashed border; the container itself is drawn live in drawStations
        for (Bin bn : BINS) {
            Material m = bn.mat();
            Rect q = bn.rect();
            RoundRectangle2D zone = rr(q.x() + 6, q.y() + 6, q.w() - 12, q.h() - 12, 18);
            fill(b, Palette.alpha(m.color, .22), zone);
            dashed(b, m.color, 3, 10, 8, zone);
        }

        // camp
        fill(b, rgba(244, 239, 220, .16), circle(CAMP_X, CAMP_Y, 30));
        t(b, Fonts.fredoka(600, 14), rgba(244, 239, 220, .6), Texts.t("world.camp"), CAMP_X, CAMP_Y + 46, CENTER);
        b.dispose();
        return img;
    }

    // ================================================================== scene

    private void drawScene(Graphics2D g) {
        Session.Phase ph = ses.phase;
        Game gm = ses.game;
        boolean inGame = gm != null && ph != Session.Phase.MENU && ph != Session.Phase.INTRO;
        AffineTransform t0 = g.getTransform();
        g.translate(0, HUD);
        if (inGame) {
            drawStations(g, gm);
            drawCones(g, gm);
            drawPulses(g, gm);
            for (Trash o : gm.trash) {
                drawTrash(g, o);
            }
            for (PowerUp o : gm.powers) {
                drawPower(g, o);
            }
            drawBushes(g);
            drawPlayer(g, gm);
            for (Tiger t : gm.tigers) {
                drawTiger(g, t);
            }
            drawHandBubble(g, gm);
            drawFx(g, gm);
            if (ph == Session.Phase.PLAY) {
                drawTip(g, gm);
            }
        } else {
            drawBushes(g);
        }
        g.setTransform(t0);
        if (inGame) {
            drawHud(g, gm);
            if (gm.scan != null) {
                drawScan(g, gm);
            }
            if (gm.fb != null) {
                drawFeedback(g, gm);
            }
        }
        if (ph == Session.Phase.QUIZ) {
            drawQuiz(g);
        }
        if (ph == Session.Phase.MENU) {
            drawMenu(g);
        }
        if (ph == Session.Phase.INTRO) {
            drawIntro(g);
        }
        if (ph == Session.Phase.PLAY && ses.paused) {
            drawPause(g);
        }
        if (ph == Session.Phase.SUM) {
            drawSummary(g);
        }
        if (ph == Session.Phase.BOARD) {
            drawBoard(g);
        }
    }

    private void drawBushes(Graphics2D g) {
        double[][] parts = {{0, 0, 1}, {-.5, -.2, .6}, {.5, -.15, .6}, {-.3, .4, .55}, {.35, .38, .55}};
        for (Bush bu : BUSHES) {
            fill(g, rgba(0, 0, 0, .2), ellipse(bu.x() + 4, bu.y() + 8, bu.r(), bu.r() * .8));
            for (int i = 0; i < parts.length; i++) {
                double[] q = parts[i];
                fill(g, i % 2 == 1 ? new Color(0x3B8C4C) : new Color(0x2F7A40), circle(bu.x() + q[0] * bu.r(), bu.y() + q[1] * bu.r(), bu.r() * q[2]));
            }
            fill(g, rgba(143, 224, 90, .3), circle(bu.x() - bu.r() * .3, bu.y() - bu.r() * .35, bu.r() * .25));
        }
    }

    private void drawCones(Graphics2D g, Game gm) {
        double sight = ses.settings.d(Tune.SIGHT), hear = ses.settings.d(Tune.HEAR);
        for (Tiger t : gm.tigers) {
            if (t.st == TState.SLEEP) {
                fill(g, rgba(158, 208, 240, .13), circle(t.x, t.y, hear));
                dashed(g, rgba(158, 208, 240, .75), 3, 10, 8, circle(t.x, t.y, hear));
                continue;
            }
            boolean chase = t.st == TState.CHASE;
            int rays = 44;
            Path2D.Double cone = new Path2D.Double();
            cone.moveTo(t.x, t.y);
            for (int i = 0; i <= rays; i++) {
                double a = t.face - Game.HALF + 2 * Game.HALF * i / rays;
                double r = 0;
                while (r < sight) {
                    r += 8;
                    if (inObs(t.x + Math.cos(a) * r, t.y + Math.sin(a) * r, 0)) {
                        break;
                    }
                }
                cone.lineTo(t.x + Math.cos(a) * r, t.y + Math.sin(a) * r);
            }
            cone.closePath();
            int cr = chase ? 228 : 255, cg = chase ? 71 : 232, cb = chase ? 43 : 140;
            float f0 = (float) (8 / sight), f1 = (float) ((8 + 0.7 * (sight - 8)) / sight);
            RadialGradientPaint gp = new RadialGradientPaint(new Point2D.Double(t.x, t.y), (float) sight,
                new float[] {0f, f0, f1, 1f},
                new Color[] {rgba(cr, cg, cb, .5), rgba(cr, cg, cb, .5), rgba(cr, cg, cb, .22), rgba(cr, cg, cb, .04)});
            g.setPaint(gp);
            g.fill(cone);
        }
    }

    private void drawPulses(Graphics2D g, Game gm) {
        for (Pulse q : gm.pulses) {
            line(g, rgba(228, 71, 43, 1 - q.t / 0.9), 4, circle(q.x, q.y, q.r * Math.min(1, q.t * 2)));
        }
    }

    private void drawTrash(Graphics2D g, Trash o) {
        double y = o.y + Math.sin(now * 2.5 + o.bob) * 2;
        fill(g, rgba(0, 0, 0, .25), ellipse(o.x, o.y + 14, 14, 5));
        if (o.zone > 1) {
            Color ring = o.zone >= 2 ? new Color(0xFFD34D) : new Color(0xDDE6EC);
            line(g, ring, 3, circle(o.x, y, 21));
            t(g, Fonts.fredoka(700, 13), ring, "×" + num(o.zone), o.x, y - 26, CENTER);
        }
        fill(g, new Color(0xB07A44), circle(o.x, y, 15));
        line(g, new Color(0x7A4E25), 3, circle(o.x, y, 15));
        tm(g, Fonts.fredoka(700, 20), PAPER, "?", o.x, y + 1, CENTER);
    }

    private void drawPower(Graphics2D g, PowerUp o) {
        if (o.life < 3 && Math.floor(now * 8) % 2 != 0) {
            return;
        }
        double s = 1 + Math.sin(now * 6) * .12;
        AffineTransform t0 = g.getTransform();
        g.translate(o.x, o.y);
        g.scale(s, s);
        if (o.turbo) {
            fill(g, YELLOW, circle(0, 0, 16));
            Path2D.Double bolt = new Path2D.Double();
            bolt.moveTo(3, -11);
            bolt.lineTo(-7, 2);
            bolt.lineTo(0, 2);
            bolt.lineTo(-3, 11);
            bolt.lineTo(7, -2);
            bolt.lineTo(0, -2);
            bolt.closePath();
            fill(g, INK_DARK, bolt);
        } else {
            fill(g, ICE, circle(0, 0, 16));
            fill(g, INK, ellipse(0, 0, 10, 6.5));
            fill(g, ICE, circle(0, 0, 3.2));
        }
        g.setTransform(t0);
    }

    private void drawPlayer(Graphics2D g, Game gm) {
        Player p = gm.p;
        if (p.inv > 0 && Math.floor(now * 10) % 2 == 0) {
            return;
        }
        AffineTransform t0 = g.getTransform();
        g.translate(p.x, p.y);
        if (p.moving && !p.sneak && p.turbo <= 0) {
            dashed(g, rgba(244, 239, 220, .35), 2, 6, 6, circle(0, 0, 26 + Math.sin(now * 12) * 3));
        }
        alpha(g, p.invis > 0 ? 0.35 : (p.hidden ? 0.55 : 1));
        if (p.turbo > 0) {
            line(g, rgba(255, 226, 122, .85), 3, circle(0, 0, 22 + Math.sin(now * 20) * 2));
        }
        fill(g, rgba(0, 0, 0, .25), ellipse(2, 5, 16, 11));
        // the ranger seen from above: "forward" is -y after the rotation
        g.rotate(p.face + Math.PI / 2);
        double crouch = p.sneak ? 0.86 : 1;
        g.scale(crouch, crouch);
        double speed = p.turbo > 0 ? 20 : (p.sneak ? 7 : 13), sw = p.moving ? Math.sin(now * speed) : 0;
        // legs
        Color legs = new Color(0x4A3A22);
        fill(g, legs, ellipse(-6, sw * 8, 4.5, 6.5));
        fill(g, legs, ellipse(6, -sw * 8, 4.5, 6.5));
        // backpack
        fill(g, new Color(0x7A5A2E), rr(-9, 5, 18, 11, 4));
        fill(g, new Color(0x5E4422), rr(-9, 12, 18, 4, 2));
        // body and arms
        fill(g, new Color(0x6E8B3D), ellipse(0, 0, 13, 9));
        Color skin = new Color(0xE0B48A);
        fill(g, skin, circle(-14, -sw * 7, 4));
        fill(g, skin, circle(14, sw * 7, 4));
        // head with ranger hat
        fill(g, new Color(0xB08A4E), circle(0, -3, 11.5));
        line(g, new Color(0x8A6A36), 1.5, circle(0, -3, 11.5));
        fill(g, new Color(0xC9A060), circle(0, -3, 7));
        Path2D.Double band = new Path2D.Double();
        band.append(arc(0, -3, 7, Math.PI * 0.85, Math.PI * 1.15), false);
        band.lineTo(0, -3);
        band.closePath();
        fill(g, new Color(0x6E8B3D), band);
        fill(g, skin, ellipse(0, -13, 3.2, 2.2)); // nose / face at the front
        g.setTransform(t0);
        opaque(g);
        if (p.sneak && p.moving) {
            t(g, Fonts.fredoka(700, 13), SKY, Texts.t("world.sneak"), p.x, p.y + 34, CENTER);
        }
    }

    private void drawTiger(Graphics2D g, Tiger t) {
        boolean sleeping = t.st == TState.SLEEP;
        AffineTransform t0 = g.getTransform();
        g.translate(t.x, t.y);
        fill(g, rgba(0, 0, 0, .25), ellipse(3, 6, 24, 13));
        g.rotate(t.face);
        Color body = t.kind == Kind.STREUN ? new Color(0xE8B04A) : TIGER;
        if (sleeping) {
            fill(g, body, circle(0, 0, 17));
            for (double a : new double[] {-.8, 0, .8, 1.6, 2.4}) {
                line(g, INK_DARK, 3, arc(0, 0, 13, a, a + .35));
            }
            line(g, body, 5, BasicStroke.CAP_ROUND, arc(0, 0, 21, 1.2, 3.4));
            fill(g, body, circle(10, 4, 8));
            Path2D.Double eyes = new Path2D.Double();
            eyes.moveTo(10, 0);
            eyes.lineTo(14, 1);
            eyes.moveTo(9, 6);
            eyes.lineTo(13, 7);
            line(g, INK_DARK, 1.8, BasicStroke.CAP_ROUND, eyes);
            g.setTransform(t0);
            double z = Math.sin(now * 2);
            t(g, Fonts.fredoka(700, 14 + z * 2), SKY, Texts.t("world.sleep"), t.x + 16, t.y - 18 - z * 3, LEFT);
            return;
        }
        double sw = Math.sin(now * 9 + (t.x % 7)) * 0.35;
        Path2D.Double tail = new Path2D.Double();
        tail.moveTo(-15, 0);
        tail.quadTo(-26, sw * 14, -30, sw * 10 + 3);
        line(g, body, 5, BasicStroke.CAP_ROUND, tail);
        fill(g, body, ellipse(-3, 0, 17, 11));
        for (double x : new double[] {-12, -5, 2}) {
            Path2D.Double stripe = new Path2D.Double();
            stripe.moveTo(x, -10);
            stripe.lineTo(x + 3, -4);
            stripe.moveTo(x, 10);
            stripe.lineTo(x + 3, 4);
            line(g, INK_DARK, 2.6, BasicStroke.CAP_ROUND, stripe);
        }
        fill(g, body, circle(14, 0, 9));
        fill(g, body, circle(11, -7, 3.6));
        fill(g, body, circle(11, 7, 3.6));
        fill(g, new Color(0xFFE7BF), ellipse(20, 0, 4, 5));
        fill(g, INK_DARK, circle(16, -3.6, 1.8));
        fill(g, INK_DARK, circle(16, 3.6, 1.8));
        g.setTransform(t0);
        // name tag
        Font tagFont = Fonts.nunito(700, 11);
        double w = Txt.width(tagFont, t.name) + 10;
        fill(g, rgba(15, 42, 27, .75), rr(t.x - w / 2, t.y + 18, w, 16, 8));
        t(g, tagFont, PAPER, t.name, t.x, t.y + 30, CENTER);
        String mark = "";
        Color c = PAPER;
        if (t.st == TState.CHASE) {
            mark = "!";
            c = DANGER;
        } else if (t.st == TState.INVESTIGATE || t.st == TState.RUSH || t.st == TState.LOOK) {
            mark = "?";
            c = YELLOW;
        }
        if (!mark.isEmpty()) {
            fill(g, c, circle(t.x, t.y - 26, 9));
            t(g, Fonts.fredoka(700, 14), INK_DARK, mark, t.x, t.y - 21, CENTER);
        }
    }

    private void drawFx(Graphics2D g, Game gm) {
        Font f = Fonts.fredoka(700, 19);
        for (Fx e : gm.fx) {
            alpha(g, Math.max(0, 1 - e.t / 1.5));
            double x = Math.min(PW - 120, Math.max(120, e.x)), y = e.y - e.t * 24;
            Txt.drawOutlined(g, f, e.text, x, y, CENTER, rgba(15, 42, 27, .95), 5, e.color);
        }
        opaque(g);
    }

    // ================================================================== item pictures, containers, hand bubble, tip

    private static Color rgb(int v) {
        return new Color(v);
    }

    private static final Color OUTLINE = rgba(0, 0, 0, .35);

    /** A closed polygon from x/y pairs. */
    private static Path2D.Double poly(double... xy) {
        Path2D.Double p = new Path2D.Double();
        p.moveTo(xy[0], xy[1]);
        for (int i = 2; i + 1 < xy.length; i += 2) {
            p.lineTo(xy[i], xy[i + 1]);
        }
        p.closePath();
        return p;
    }

    /**
     * Like the canvas path that stays after fill(): remembers the last shape, so that {@link #o} can outline it.
     * Strokes have round joins and caps, like the pictures of the prototype.
     */
    private static final class Pen {
        private final Graphics2D g;
        private Shape last;

        Pen(Graphics2D g) {
            this.g = g;
        }

        void r(double x, double y, double w, double h, double rad, Color f) {
            shape(rr(x, y, w, h, rad), f);
        }

        void e(double x, double y, double rx, double ry, Color f) {
            shape(ellipse(x, y, rx, ry), f);
        }

        void shape(Shape sh, Color f) {
            last = sh;
            fill(g, f, sh);
        }

        /** Outline of the last shape. */
        void o(double w, Color col) {
            stroke(last, w, col == null ? OUTLINE : col);
        }

        void stroke(Shape sh, double w, Color col) {
            g.setColor(col);
            g.setStroke(new BasicStroke((float) w, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.draw(sh);
        }
    }

    /** The small picture of an item (neutral colours, so it does not give away the bin by its colour). */
    private static void itemIcon(Graphics2D g, String icon, double x, double y, double s) {
        AffineTransform t0 = g.getTransform();
        g.translate(x, y);
        g.scale(s, s);
        Pen c = new Pen(g);
        switch (icon) {
            case "glasflasche" -> {
                c.r(-8, -4, 16, 24, 5, rgb(0x7A4A1E));
                c.o(1.5, null);
                c.r(-3.5, -18, 7, 15, 2, rgb(0x7A4A1E));
                c.r(-4.5, -21, 9, 4, 1, rgb(0xC9A227));
                c.r(-5, 0, 3, 15, 1.5, rgba(255, 255, 255, .35));
            }
            case "konfiglas" -> {
                c.r(-11, -8, 22, 26, 5, rgba(215, 236, 245, .95));
                c.o(1.5, null);
                c.r(-9, 0, 18, 16, 4, rgb(0xC2334A));
                c.r(-12, -15, 24, 8, 3, rgb(0xD9A520));
                c.o(1.2, null);
            }
            case "parfumflakon" -> {
                c.r(-11, -4, 22, 22, 5, rgb(0xE7B6E0));
                c.o(1.5, null);
                c.r(-3, -11, 6, 8, 1, rgb(0xE7B6E0));
                c.e(0, -15, 6, 5, rgb(0xC9A227));
                c.r(-7, 0, 3, 13, 1.5, rgba(255, 255, 255, .5));
            }
            case "getraenkedose" -> {
                c.r(-9, -16, 18, 32, 4, rgb(0xD23B3B));
                c.o(1.5, null);
                c.e(0, -15, 9, 3, rgb(0xD7DCE0));
                c.r(-9, -3, 18, 6, 0, PAPER);
            }
            case "alufolie" -> {
                c.shape(poly(-13, -4, -8, -12, 0, -14, 9, -10, 14, -2, 11, 8, 3, 13, -7, 12, -13, 5), rgb(0xC9D1D6));
                c.o(1.5, null);
                Path2D.Double w = new Path2D.Double();
                w.moveTo(-6, -6);
                w.lineTo(2, 0);
                w.lineTo(8, -5);
                w.moveTo(-4, 6);
                w.lineTo(3, 2);
                c.stroke(w, 1.2, rgba(90, 100, 110, .5));
            }
            case "konservendose" -> {
                c.r(-12, -13, 24, 27, 3, rgb(0xB8C0C6));
                c.o(1.5, null);
                c.r(-12, -5, 24, 12, 0, rgb(0xE59A3A));
                for (double yy : new double[] {-10, 10}) {
                    c.stroke(new java.awt.geom.Line2D.Double(-12, yy, 12, yy), 1, rgba(0, 0, 0, .25));
                }
            }
            case "pet-flasche" -> {
                c.r(-8, -7, 16, 27, 6, rgba(150, 205, 240, .9));
                c.o(1.5, null);
                c.r(-3.5, -16, 7, 10, 2, rgba(150, 205, 240, .9));
                c.r(-4.5, -20, 9, 5, 1.5, rgb(0x2E7DD7));
                c.r(-8, 2, 16, 7, 0, PAPER);
            }
            case "shampooflasche" -> {
                c.r(-9, -9, 18, 29, 7, rgb(0x5DB8A8));
                c.o(1.5, null);
                c.r(-4, -16, 8, 8, 2, PAPER);
                c.r(-1, -21, 9, 4, 1, PAPER);
                c.r(-6, 0, 12, 9, 2, rgba(255, 255, 255, .7));
            }
            case "joghurtbecher" -> {
                c.shape(poly(-12, -12, 12, -12, 8, 16, -8, 16), rgb(0xF5F1E6));
                c.o(1.5, null);
                c.r(-11, -4, 22, 6, 0, rgb(0xE46F9A));
                c.e(0, -12, 12, 3, rgb(0xD7DCE0));
            }
            case "taschentuch" -> {
                double[][] q = {{-14, -6}, {-6, -13}, {5, -12}, {13, -5}, {12, 7}, {3, 13}, {-9, 11}, {-14, 3}};
                Path2D.Double p = new Path2D.Double();
                p.moveTo(q[0][0], q[0][1]);
                for (int i = 1; i < q.length; i++) {
                    p.quadTo(q[i][0] * .6, q[i][1] * .6, q[i][0], q[i][1]);
                }
                p.closePath();
                c.shape(p, rgb(0xFBFBF6));
                c.o(1.5, null);
                Path2D.Double w = new Path2D.Double();
                w.moveTo(-6, -3);
                w.quadTo(0, 2, 6, -4);
                w.moveTo(-3, 5);
                w.lineTo(4, 6);
                c.stroke(w, 1.2, rgba(120, 120, 120, .4));
            }
            case "kaugummi" -> {
                c.e(0, 2, 11, 8, rgb(0xF07BB0));
                c.stroke(ellipse(0, 2, 11, 8), 1.5, OUTLINE);
                c.e(-4, -1, 3, 2, rgba(255, 255, 255, .6));
            }
            case "trinkglas" -> {
                c.shape(poly(-11, -14, 11, -14, 8, 16, -8, 16), rgba(205, 232, 242, .85));
                c.o(1.5, null);
                c.shape(poly(-10, -2, 10, -2, 8, 16, -8, 16), rgba(120, 185, 225, .6));
            }
            case "spiegel" -> {
                c.e(0, 0, 12, 16, rgb(0x8A6A3E));
                c.e(0, 0, 9, 13, rgb(0xBFE3F2));
                Path2D.Double w = new Path2D.Double();
                w.moveTo(-4, -6);
                w.lineTo(3, -10);
                w.moveTo(-5, 1);
                w.lineTo(5, -5);
                c.stroke(w, 2, rgba(255, 255, 255, .8));
            }
            case "keramiktasse" -> {
                c.stroke(arc(12, 2, 6, -1.3, 1.3), 4, rgb(0xE9E2D2));
                c.r(-12, -10, 22, 24, 4, rgb(0xE9E2D2));
                c.o(1.5, null);
                for (double[] q : new double[][] {{-6, -2}, {0, 4}, {5, -3}}) {
                    c.e(q[0], q[1], 2, 2, rgb(0x3C78C8));
                }
                c.e(-1, -10, 11, 2.5, rgb(0xC8BFA8));
            }
            case "chipstuete" -> {
                Path2D.Double p = new Path2D.Double();
                p.moveTo(-11, -14);
                for (int i = 0; i <= 6; i++) {
                    p.lineTo(-11 + i * 22.0 / 6, i % 2 != 0 ? -17 : -14);
                }
                p.lineTo(12, 14);
                for (int i = 0; i <= 6; i++) {
                    p.lineTo(12 - i * 24.0 / 6, i % 2 != 0 ? 17 : 14);
                }
                p.closePath();
                c.shape(p, rgb(0xE8B323));
                c.o(1.5, null);
                c.e(0, 0, 7, 6, rgb(0xD2433B));
            }
            case "pizzakarton" -> {
                c.r(-14, -12, 28, 24, 2, rgb(0xC99A5B));
                c.o(1.5, null);
                c.e(-5, -2, 5, 4, rgba(110, 70, 30, .55));
                c.e(6, 5, 4, 3, rgba(110, 70, 30, .5));
                c.stroke(new java.awt.geom.Line2D.Double(-14, -7, 14, -7), 1, rgba(0, 0, 0, .25));
            }
            case "kronkorken" -> {
                Path2D.Double p = new Path2D.Double();
                for (int i = 0; i <= 24; i++) {
                    double a = i / 24.0 * Math.PI * 2, r = i % 2 != 0 ? 10 : 13;
                    if (i == 0) {
                        p.moveTo(r, 0);
                    } else {
                        p.lineTo(Math.cos(a) * r, Math.sin(a) * r);
                    }
                }
                p.closePath();
                c.shape(p, rgb(0xD9A520));
                c.o(1.5, null);
                c.e(0, 0, 6, 6, rgb(0xE9C44A));
            }
            case "alu-deckel" -> {
                c.e(0, 2, 13, 13, rgb(0xD7DCE0));
                c.stroke(circle(0, 2, 13), 1.5, OUTLINE);
                c.r(8, -12, 8, 7, 3, rgb(0xD7DCE0));
                c.e(0, 2, 6, 6, rgb(0xE46F9A));
            }
            default -> c.e(0, 0, 12, 12, rgb(0xB07A44));
        }
        g.setTransform(t0);
    }

    /** The symbol of a container (also used in the HUD and in the intro). */
    private static void binSymbol(Graphics2D g, Material m, double x, double y, double s) {
        AffineTransform t0 = g.getTransform();
        g.translate(x, y);
        g.scale(s, s);
        switch (m) {
            case GLAS -> {
                fill(g, INK, rr(-7, -2, 14, 20, 5));
                fill(g, INK, rr(-3, -15, 6, 14, 2));
                fill(g, INK, rr(-4, -18, 8, 4, 1));
            }
            case METALL -> {
                fill(g, INK, rr(-9, -14, 18, 28, 4));
                fill(g, PAPER, ellipse(0, -13, 9, 3));
                fill(g, INK, rr(-2, -15, 4, 2, 1));
            }
            case KUNSTSTOFF -> {
                fill(g, INK, poly(-11, -12, 11, -12, 7, 15, -7, 15));
                fill(g, PAPER, rr(-9, -4, 18, 5, 0));
            }
            default -> {
                Path2D.Double p = new Path2D.Double();
                p.moveTo(-3, -12);
                p.lineTo(-8, -17);
                p.lineTo(0, -14);
                p.lineTo(8, -17);
                p.lineTo(3, -12);
                p.quadTo(15, -4, 12, 10);
                p.quadTo(10, 17, 0, 17);
                p.quadTo(-10, 17, -12, 10);
                p.quadTo(-15, -4, -3, -12);
                p.closePath();
                fill(g, INK, p);
            }
        }
        g.setTransform(t0);
    }

    /** The four containers in the corners: colour, symbol and fill level; they glow while the ranger carries something. */
    private void drawStations(Graphics2D g, Game gm) {
        double glow = gm.bag != null ? 0.45 + 0.35 * Math.sin(now * 5) : 0;
        boolean strong = gm.glowT > 0;
        for (Bin bn : BINS) {
            Material m = bn.mat();
            Rect q = bn.rect();
            Deposit dp = gm.dep.get(m);
            if (glow > 0 || strong) {
                alpha(g, strong ? 0.6 + 0.4 * Math.sin(now * 10) : glow);
                line(g, m.color, strong ? 8 : 5, rr(q.x() + 4, q.y() + 4, q.w() - 8, q.h() - 8, 20));
                opaque(g);
            }
            double cw = 124, ch = 74, cx = q.x() + q.w() / 2, top = q.y() + 14, x = cx - cw / 2;
            fill(g, rgba(0, 0, 0, .28), rr(x + 5, top + 8, cw, ch, 14));
            fill(g, m.color, rr(x, top, cw, ch, 14));
            fill(g, rgba(0, 0, 0, .22), rr(x + 10, top + 7, cw - 20, 9, 4)); // slot
            fill(g, rgba(255, 255, 255, .18), rr(x + 6, top + 20, 8, ch - 28, 4));
            // fill level at the right side of the container
            double gx = x + cw - 16, gy = top + 20, gh = ch - 28, f = Math.min(1, dp.disp / 10);
            fill(g, rgba(0, 0, 0, .3), rr(gx, gy, 8, gh, 4));
            if (f > 0) {
                fill(g, PAPER, rr(gx, gy + gh * (1 - f), 8, gh * f, 4));
            }
            // symbol in a light circle
            fill(g, PAPER, circle(cx - 4, top + ch / 2 + 6, 25));
            binSymbol(g, m, cx - 4, top + ch / 2 + 6, 1.05);
            // wheels
            for (double wx : new double[] {x + 22, x + cw - 22}) {
                fill(g, INK, circle(wx, top + ch + 2, 6));
            }
            t(g, Fonts.nunito(700, 15), PAPER, m.label(), cx, q.y() + q.h() - 16, CENTER);
        }
    }

    /** Speech bubble above the ranger with the picture of the carried item (hidden while scanning). */
    private void drawHandBubble(Graphics2D g, Game gm) {
        Player p = gm.p;
        Bag b = gm.bag;
        if (b == null || gm.scan != null) {
            return;
        }
        double x = p.x + 30, y = p.y - 40;
        fill(g, rgba(0, 0, 0, .25), circle(x + 2, y + 3, 21));
        fill(g, PAPER, circle(x, y, 21));
        fill(g, PAPER, poly(x - 16, y + 12, x - 26, y + 26, x - 6, y + 19));
        line(g, TIGER, 2.5, circle(x, y, 21));
        itemIcon(g, b.it.icon(), x, y, 0.78);
    }

    /** A short hint during play (each hint once per run). */
    private void drawTip(Graphics2D g, Game gm) {
        Game.Tip tip = gm.tip;
        if (tip == null || gm.scan != null) {
            return;
        }
        alpha(g, Math.max(0, Math.min(1, Math.min(tip.t * 5, (tip.dur - tip.t) * 3))));
        double w = 620, h = 86, x = W / 2.0 - w / 2, y = H - HUD - h - 22;
        fill(g, rgba(15, 42, 27, .95), rr(x, y, w, h, 20));
        line(g, YELLOW, 3, rr(x, y, w, h, 20));
        fill(g, YELLOW, circle(x + 44, y + h / 2, 22));
        t(g, Fonts.fredoka(700, 28), INK_DARK, "!", x + 44, y + h / 2 + 10, CENTER);
        t(g, Fonts.fredoka(700, 24), YELLOW, tip.title, x + 82, y + 36, LEFT);
        t(g, Fonts.nunito(600, 18), PAPER, tip.text, x + 82, y + 64, LEFT);
        opaque(g);
    }

    // ================================================================== HUD

    private static void heart(Graphics2D g, double x, double y, double s, Color c) {
        Path2D.Double p = new Path2D.Double();
        p.moveTo(x, y + s * .9);
        p.curveTo(x - s * 1.4, y, x - s * .9, y - s * .9, x, y - s * .3);
        p.curveTo(x + s * .9, y - s * .9, x + s * 1.4, y, x, y + s * .9);
        fill(g, c, p);
    }

    private void drawHud(Graphics2D g, Game gm) {
        Player p = gm.p;
        Settings S = ses.settings;
        // left: counters of the four containers
        double bw = 104, gap = 10, bx = 16, by = 14, bh = 92;
        int i = 0;
        for (Material m : Material.values()) {
            Deposit q = gm.dep.get(m);
            double x = bx + i * (bw + gap), fillF = Math.min(1, q.disp / 10);
            fill(g, INK, rr(x, by, bw, bh, 14));
            Area clip = new Area(rr(x, by, bw, bh, 14));
            Area level = new Area(new Rectangle2D.Double(x, by + bh * (1 - fillF), bw, bh * fillF));
            level.intersect(clip);
            fill(g, m.color, level);
            line(g, m.color, 2.5, rr(x, by, bw, bh, 14));
            fill(g, PAPER, circle(x + bw / 2, by + 28, 18));
            binSymbol(g, m, x + bw / 2, by + 28, 0.72);
            tm(g, Fonts.fredoka(700, 30), fillF > 0.4 ? m.textColor : PAPER, String.valueOf(q.n), x + bw / 2, by + 70, CENTER);
            i++;
        }
        // time
        double cx = bx + 4 * (bw + gap) + 28;
        boolean low = gm.time < 20;
        int sec = Math.max(0, (int) Math.ceil(gm.time));
        tm(g, Fonts.nunito(700, 12), PAPER_DIM, Texts.t("hud.time"), cx, 30, LEFT);
        tm(g, Fonts.fredoka(700, 46), low ? new Color(0xFF9B85) : PAPER, (sec / 60) + ":" + String.format(Locale.ROOT, "%02d", sec % 60), cx, 72, LEFT);
        // hand: big, with a picture
        double hx = cx + 170, hw = 520, hy = 14, hh = 92;
        Bag b = gm.bag;
        Color dim = new Color(0x5E9C70);
        fill(g, b != null ? PAPER : INK, rr(hx, hy, hw, hh, 16));
        if (b == null) {
            dashed(g, dim, 2, 8, 6, rr(hx, hy, hw, hh, 16));
            line(g, dim, 2, circle(hx + 50, hy + hh / 2, 28));
            tm(g, Fonts.fredoka(700, 26), dim, "?", hx + 50, hy + hh / 2 + 2, CENTER);
            tm(g, Fonts.fredoka(700, 26), PAPER, Texts.t("hud.hand_empty"), hx + 96, hy + 36, LEFT);
            tm(g, Fonts.nunito(600, 16), PAPER_DIM, Texts.t("hud.hand_empty_hint"), hx + 96, hy + 66, LEFT);
        } else {
            line(g, TIGER, 3, rr(hx, hy, hw, hh, 16));
            fill(g, Color.WHITE, circle(hx + 50, hy + hh / 2, 33));
            itemIcon(g, b.it.icon(), hx + 50, hy + hh / 2, 1.35);
            tm(g, Fonts.nunito(700, 12), INK_SOFT, Texts.t("hud.in_hand"), hx + 96, hy + 22, LEFT);
            tm(g, Fonts.fredoka(700, 28), INK, b.it.name(), hx + 96, hy + 52, LEFT);
            tm(g, Fonts.nunito(600, 15), INK_SOFT, b.zone > 1 ? Texts.t("hud.which_bin_zone", "zone", num(b.zone)) : Texts.t("hud.which_bin"), hx + 96, hy + 78, LEFT);
        }
        // right: score, lives, power
        tm(g, Fonts.nunito(700, 12), PAPER_DIM, Texts.t("hud.score"), W - 18, 26, RIGHT);
        tm(g, Fonts.fredoka(700, 30), LIME, String.valueOf(gm.score), W - 18, 54, RIGHT);
        int maxLives = S.i(Tune.LIVES);
        for (int k = 0; k < maxLives; k++) {
            heart(g, W - 28 - k * 30, 90, 10, k < gm.lives ? DANGER : rgba(244, 239, 220, .18));
        }
        String pw = "";
        if (p.turbo > 0) {
            pw = Texts.t("hud.turbo", "sec", (int) Math.ceil(p.turbo));
        }
        if (p.invis > 0) {
            pw = Texts.t("hud.invis", "sec", (int) Math.ceil(p.invis));
        }
        if (!pw.isEmpty()) {
            tm(g, Fonts.fredoka(700, 14), YELLOW, pw, W - 18 - maxLives * 30 - 10, 90, RIGHT);
        }
    }

    private void drawScan(Graphics2D g, Game gm) {
        Game.Scan sc = gm.scan;
        double w = 660, h = 168, x = W / 2.0 - w / 2, y = H - h - 20;
        fill(g, rgba(15, 42, 27, .96), rr(x, y, w, h, 22));
        line(g, TIGER, 3, rr(x, y, w, h, 22));
        t(g, Fonts.fredoka(700, Math.round(30 + Math.sin(now * 8) * 2)), TIGER, Texts.t("scan.now"), W / 2.0, y + 38, CENTER);
        double bx = x + 40, bw = w - 80, by = y + 62, bh = 30;
        fill(g, INK, rr(bx, by, bw, bh, 15));
        double gw = bw * ses.settings.d(Tune.GREEN) / 100;
        fill(g, GOOD, rr(bx + bw / 2 - gw / 2, by, gw, bh, 15));
        t(g, Fonts.nunito(700, 14), JUNGLE, Texts.t("scan.bonus"), W / 2.0, by + 20, CENTER);
        double px = bx + sc.u * bw;
        fill(g, TIGER, rr(px - 6, by - 10, 12, bh + 20, 6));
        line(g, PAPER, 2, rr(px - 6, by - 10, 12, bh + 20, 6));
        // the key as a picture
        double kx = x + 40, ky = y + 112, kw = 170, kh = 40, press = Math.floor(now * 3) % 2 != 0 ? 3 : 0;
        fill(g, new Color(0x8A5A10), rr(kx, ky + 4, kw, kh, 10));
        fill(g, TIGER, rr(kx, ky + press, kw, kh, 10));
        t(g, Fonts.fredoka(700, 17), INK_DARK, Texts.t("scan.key"), kx + kw / 2, ky + 26 + press, CENTER);
        t(g, Fonts.nunito(700, 17), PAPER, Texts.t("scan.how"), kx + kw + 18, ky + 18, LEFT);
        t(g, Fonts.nunito(600, 15), new Color(0xFF9B85), Texts.t("scan.warn"), kx + kw + 18, ky + 40, LEFT);
    }

    private void drawFeedback(Graphics2D g, Game gm) {
        Game.Feedback f = gm.fb;
        double a = Math.max(0, Math.min(1, Math.min(f.t * 6, (f.dur - f.t) * 3)));
        alpha(g, a);
        double w = 700, x = W / 2.0 - w / 2, y = HUD + 14;
        Font body = Fonts.nunito(600, 18);
        List<String> lines = Txt.wrap(body, f.text, w - 48);
        double h = 56 + lines.size() * 24;
        fill(g, rgba(15, 42, 27, .94), rr(x, y, w, h, 18));
        line(g, f.color, 3, rr(x, y, w, h, 18));
        t(g, Fonts.fredoka(700, 22), f.color, f.title, x + 24, y + 34, LEFT);
        for (int i = 0; i < lines.size(); i++) {
            t(g, body, PAPER, lines.get(i), x + 24, y + 60 + i * 24, LEFT);
        }
        opaque(g);
    }

    // ================================================================== quiz / menu / intro / pause

    private Rectangle2D.Double panel(Graphics2D g, double h) {
        fill(g, rgba(12, 38, 22, .82), new Rectangle2D.Double(0, 0, W, H));
        double w = 680, x = W / 2.0 - w / 2, y = H / 2.0 - h / 2;
        fill(g, PAPER, rr(x, y, w, h, 26));
        return new Rectangle2D.Double(x, y, w, h);
    }

    private void drawQuiz(Graphics2D g) {
        Session.QuizRun z = ses.quiz;
        if (z == null || z.i >= z.qs.size()) {
            return;
        }
        Question q = z.qs.get(z.i);
        Rectangle2D.Double p = panel(g, 560);
        t(g, Fonts.nunito(700, 15), ORANGE_DARK, Texts.t("quiz.head", "n", z.i + 1, "total", z.qs.size()), W / 2.0, p.y + 50, CENTER);
        Font qf = Fonts.fredoka(700, 28);
        List<String> lines = Txt.wrap(qf, q.q(), p.width - 80);
        for (int i = 0; i < lines.size(); i++) {
            t(g, qf, INK, lines.get(i), W / 2.0, p.y + 100 + i * 36, CENTER);
        }
        for (int i = 0; i < q.answers().size(); i++) {
            double bx = p.x + 60, by = p.y + 190 + i * 82, bw = p.width - 120, bh = 64;
            Color bgc = new Color(0xE4DCC0), fg = INK;
            if (z.res == null && i == z.sel) {
                bgc = TIGER;
                fg = INK_DARK;
            }
            if (z.res != null) {
                if (i == q.correct()) {
                    bgc = GOOD;
                    fg = JUNGLE;
                } else if (i == z.sel) {
                    bgc = DANGER;
                    fg = Color.WHITE;
                }
            }
            fill(g, bgc, rr(bx, by, bw, bh, 16));
            t(g, Fonts.fredoka(700, 24), fg, q.answers().get(i), W / 2.0, by + 41, CENTER);
            final int idx = i;
            hotspot(g, new Rectangle2D.Double(bx, by, bw, bh), () -> {
                if (z.res == null) {
                    z.pick = idx;
                }
            });
        }
        String msg = z.res == null
            ? Texts.t("quiz.hint", "sec", Math.max(0, (int) Math.ceil(15 - z.t)))
            : Texts.t(z.res ? "quiz.right" : "quiz.wrong");
        t(g, Fonts.nunito(600, 16), INK_SOFT, msg, W / 2.0, p.y + p.height - 28, CENTER);
    }

    private void drawMenu(Graphics2D g) {
        fill(g, rgba(12, 38, 22, .86), new Rectangle2D.Double(0, 0, W, H));
        t(g, Fonts.nunito(700, 20), LIME, Texts.t("menu.kicker"), W / 2.0, H / 2.0 - 230, CENTER);
        Font big = Fonts.fredoka(700, 84);
        t(g, big, PAPER, Texts.t("menu.line1"), W / 2.0, H / 2.0 - 130, CENTER);
        t(g, big, TIGER, Texts.t("menu.line2"), W / 2.0, H / 2.0 - 36, CENTER);
        double s = 1 + Math.sin(now * 3) * 0.03, bw = 380, bh = 84;
        AffineTransform t0 = g.getTransform();
        g.translate(W / 2.0, H / 2.0 + 90);
        g.scale(s, s);
        fill(g, TIGER, rr(-bw / 2, -bh / 2, bw, bh, 42));
        t(g, Fonts.fredoka(700, 36), INK_DARK, Texts.t("menu.start"), 0, 13, CENTER);
        g.setTransform(t0);
        t(g, Fonts.nunito(600, 18), PAPER_DIM, Texts.t("menu.hint"), W / 2.0, H / 2.0 + 170, CENTER);
        List<HighScores.Entry> today = ses.scores.today();
        if (!today.isEmpty()) {
            HighScores.Entry best = today.get(0);
            t(g, Fonts.nunito(700, 18), PAPER, Texts.t("menu.best", "name", best.name, "score", best.score), W / 2.0, H / 2.0 + 220, CENTER);
        }
    }

    private void drawPause(Graphics2D g) {
        Rectangle2D.Double p = panel(g, 200);
        t(g, Fonts.fredoka(700, 52), INK, Texts.t("pause.title"), W / 2.0, p.y + 92, CENTER);
        t(g, Fonts.nunito(600, 20), INK_SOFT, Texts.t("pause.hint"), W / 2.0, p.y + 146, CENTER);
    }

    // ---- intro: one screen with three pictures ----

    private void drawIntro(Graphics2D g) {
        fill(g, rgba(12, 38, 22, .92), new Rectangle2D.Double(0, 0, W, H));
        t(g, Fonts.fredoka(700, 56), PAPER, Texts.t("intro.title"), W / 2.0, 140, CENTER);
        t(g, Fonts.nunito(600, 22), PAPER_DIM, Texts.t("intro.sub"), W / 2.0, 186, CENTER);
        double cw = 400, gap = 50, x0 = W / 2.0 - (cw * 3 + gap * 2) / 2, y0 = 250, ch = 440;
        String[][] cards = {
            {"1", Texts.t("intro.card1.title"), Texts.t("intro.card1.text")},
            {"2", Texts.t("intro.card2.title"), Texts.t("intro.card2.text")},
            {"3", Texts.t("intro.card3.title"), Texts.t("intro.card3.text")}};
        for (int i = 0; i < 3; i++) {
            String[] c = cards[i];
            double x = x0 + i * (cw + gap);
            fill(g, PAPER, rr(x, y0, cw, ch, 26));
            fill(g, TIGER, circle(x + 44, y0 + 44, 24));
            t(g, Fonts.fredoka(700, 28), INK_DARK, c[0], x + 44, y0 + 54, CENTER);
            t(g, Fonts.fredoka(700, 34), INK, c[1], x + cw / 2, y0 + ch - 86, CENTER);
            t(g, Fonts.nunito(600, 20), INK_SOFT, c[2], x + cw / 2, y0 + ch - 46, CENTER);
            double mx = x + cw / 2, my = y0 + 170;
            if (i == 0) { // joystick
                fill(g, new Color(0x2B3A30), rr(mx - 90, my + 40, 180, 46, 16));
                double tilt = Math.sin(now * 2) * 24;
                line(g, new Color(0x2B3A30), 14, BasicStroke.CAP_ROUND, new java.awt.geom.Line2D.Double(mx, my + 50, mx + tilt, my - 30));
                fill(g, DANGER, circle(mx + tilt, my - 40, 30));
                fill(g, rgba(255, 255, 255, .35), circle(mx + tilt - 9, my - 50, 9));
            } else if (i == 1) { // wood piece and scan bar
                fill(g, new Color(0xB07A44), circle(mx, my - 40, 40));
                line(g, new Color(0x7A4E25), 5, circle(mx, my - 40, 40));
                t(g, Fonts.fredoka(700, 46), PAPER, "?", mx, my - 24, CENTER);
                double bw = 260, bx = mx - bw / 2, by = my + 40;
                fill(g, INK, rr(bx, by, bw, 26, 13));
                fill(g, GOOD, rr(mx - 30, by, 60, 26, 13));
                double u = (Math.sin(now * 2.4) + 1) / 2;
                fill(g, TIGER, rr(bx + u * bw - 6, by - 8, 12, 42, 6));
            } else { // container and arrow
                fill(g, GOOD, rr(mx - 70, my - 70, 140, 96, 16));
                fill(g, rgba(0, 0, 0, .2), rr(mx - 56, my - 62, 112, 10, 5));
                fill(g, PAPER, circle(mx, my - 16, 30));
                binSymbol(g, Material.GLAS, mx, my - 16, 1.3);
                double ax = Math.sin(now * 3) * 8;
                fill(g, TIGER, poly(mx - 120 + ax, my + 64, mx - 40 + ax, my + 64, mx - 40 + ax, my + 50, mx - 14 + ax, my + 74,
                    mx - 40 + ax, my + 98, mx - 40 + ax, my + 84, mx - 120 + ax, my + 84));
                itemIcon(g, "glasflasche", mx + 40, my + 74, 1.3);
            }
        }
        double s = 1 + Math.sin(now * 3) * 0.03;
        AffineTransform t0 = g.getTransform();
        g.translate(W / 2.0, y0 + ch + 80);
        g.scale(s, s);
        fill(g, TIGER, rr(-190, -38, 380, 76, 38));
        t(g, Fonts.fredoka(700, 32), INK_DARK, Texts.t("intro.go"), 0, 11, CENTER);
        g.setTransform(t0);
        t(g, Fonts.nunito(600, 16), PAPER_DIM, Texts.t("intro.hint"), W / 2.0, y0 + ch + 146, CENTER);
    }

    // ================================================================== summary ("Dein Ranger-Einsatz") and scoreboard

    private static Path2D star(double cx, double cy, double r) {
        Path2D.Double p = new Path2D.Double();
        for (int i = 0; i < 10; i++) {
            double rad = i % 2 == 0 ? r : r * 0.42, a = -Math.PI / 2 + i * Math.PI / 5;
            double px = cx + Math.cos(a) * rad, py = cy + Math.sin(a) * rad;
            if (i == 0) {
                p.moveTo(px, py);
            } else {
                p.lineTo(px, py);
            }
        }
        p.closePath();
        return p;
    }

    private void drawSummary(Graphics2D g) {
        fill(g, rgba(15, 42, 27, .97), new Rectangle2D.Double(0, 0, W, H));
        // measure on a scratch graphics; if the content is taller than the screen, scale it down
        BufferedImage scratch = new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
        Graphics2D sg = scratch.createGraphics();
        hints(sg);
        double need = summaryContent(sg, W, true);
        sg.dispose();
        double k = need > H ? H / need : 1;
        AffineTransform t0 = g.getTransform();
        g.scale(k, k);
        summaryContent(g, W / k, false);
        g.setTransform(t0);
    }

    // ---- summary and scoreboard: the CSS pixel values of the web page (stage 1300 px wide) times 1.2 ----
    private static final double PAD = 26.4;       // padding of the page (22 px)
    private static final double GAP = 16.8;       // gap between the blocks of the page (14 px)
    private static final double LINE = 26.1;      // line of the card text: 15 px * 1.45
    private static final double LAB_H = 20.9;     // label above a bonus fact: 12 px * 1.45
    private static final double BOX = 7.2;        // padding of a locked row (6 px)
    private static final double GAP6 = 7.2;       // gap between the parts of a card (6 px)
    private static final double BTN_H = 57.6;     // buttons are 48 px high
    private static final Color LOCKED_BG = new Color(0xE4DCC0), LOCKED_FG = new Color(0x5A6B5F);
    private static final String LOCK = "🔒";

    /** One paragraph of a material card: plain text, a bonus fact with its label, or a locked row. */
    private record Para(String label, List<String> lines, boolean locked) {}

    private static double paraHeight(Para p) {
        double h = p.lines().size() * LINE;
        if (p.locked()) {
            h += 2 * BOX;
        } else if (p.label() != null) {
            h += LAB_H;
        }
        return h;
    }

    /** Small line above the headline (summary: why the run ended, scoreboard: the date) and the headline; returns the y below them. */
    private static double pageHead(Graphics2D g, String kick, Color kickColor, String title) {
        t(g, Fonts.nunito(700, 15.6, .14), kickColor, kick.toUpperCase(Locale.GERMAN), PAD, PAD + 16.8, LEFT);
        double y = PAD + 23.4 + GAP;
        t(g, Fonts.fredoka(700, 48), PAPER, title, PAD, y + 42.9, LEFT);
        return y + 50.4 + GAP;
    }

    /**
     * The coloured left border of a card like CSS draws it: the rounded card minus its padding box, whose left corners are
     * elliptical ({@code r - b} wide, {@code r} high), so that the colour runs out in a point at the top and the bottom.
     */
    private static Area leftBorder(double x, double y, double w, double h, double r, double b) {
        Area band = new Area(rr(x, y, w, h, r));
        double rx = Math.max(0.01, r - b), ix = x + b, ir = x + w;
        Path2D.Double in = new Path2D.Double();
        in.moveTo(ix + rx, y);
        in.lineTo(ir - r, y);
        in.append(new Arc2D.Double(ir - 2 * r, y, 2 * r, 2 * r, 90, -90, Arc2D.OPEN), true);
        in.lineTo(ir, y + h - r);
        in.append(new Arc2D.Double(ir - 2 * r, y + h - 2 * r, 2 * r, 2 * r, 0, -90, Arc2D.OPEN), true);
        in.lineTo(ix + rx, y + h);
        in.append(new Arc2D.Double(ix, y + h - 2 * r, 2 * rx, 2 * r, 270, -90, Arc2D.OPEN), true);
        in.lineTo(ix, y + r);
        in.append(new Arc2D.Double(ix, y, 2 * rx, 2 * r, 180, -90, Arc2D.OPEN), true);
        in.closePath();
        band.subtract(new Area(in));
        return band;
    }

    /** A star of the card header (the ★ / ☆ glyphs of the web page, 20 px font): filled, or as an outline with a small hollow. */
    private static void headerStar(Graphics2D g, double cx, double base, boolean filled) {
        double u = 24, cy = base - 0.355 * u, ro = 0.44 * u, ri = ro * 0.40;
        Path2D.Double p = Txt.starPath(cx, cy, ro, ri);
        if (!filled) {
            p.append(Txt.starPath(cx, cy + 0.02 * u, ro * 0.48, ri * 0.48), false);
            p.setWindingRule(Path2D.WIND_EVEN_ODD);
        }
        fill(g, ORANGE_DARK, p);
    }

    /** The headline card "Das nimmst du mit"; returns its height. */
    private double mainCard(Graphics2D g, double x, double y, double w, Game.MainFact mf) {
        Font lab = Fonts.nunito(700, 14.4, .1), h3 = Fonts.fredoka(700, 38.4), pf = Fonts.nunito(400, 19.2), big = Fonts.nunito(700, 22.8);
        double bw = 16.8, padX = 26.4, padY = 21.6, gap = 7.2, labH = 21.6, h3H = 42.24, pH = 28.8, bigH = 34.2;
        double tx = x + bw + padX, tw = w - bw - 2 * padX;
        List<String> hl = Txt.wrap(h3, mf.title(), tw);
        List<String> pl = mf.text().isEmpty() ? List.of() : Txt.wrap(pf, mf.text(), tw);
        List<String> bl = Txt.wrap(big, mf.fact(), tw);
        double h = padY + labH + gap + hl.size() * h3H + (pl.isEmpty() ? 0 : gap + pl.size() * pH) + gap + bl.size() * bigH + padY;
        fill(g, PAPER, rr(x, y, w, h, 21.6));
        fill(g, mf.mat().color, leftBorder(x, y, w, h, 21.6, bw));
        double ty = y + padY;
        t(g, lab, INK_SOFT, Texts.t("summary.main_label").toUpperCase(Locale.GERMAN), tx, ty + 15.5, LEFT);
        ty += labH + gap;
        for (String ln : hl) {
            t(g, h3, INK, ln, tx, ty + 35.3, LEFT);
            ty += h3H;
        }
        if (!pl.isEmpty()) {
            ty += gap;
            for (String ln : pl) {
                t(g, pf, INK, ln, tx, ty + 20.7, LEFT);
                ty += pH;
            }
        }
        ty += gap;
        for (String ln : bl) {
            t(g, big, INK, ln, tx, ty + 24.6, LEFT);
            ty += bigH;
        }
        return h;
    }

    /** Lays out (and, unless {@code dry}, registers the buttons of) the summary; returns its height. */
    private double summaryContent(Graphics2D g, double width, boolean dry) {
        Game gm = ses.game;
        Game.MainFact mf = ses.mainFact != null ? ses.mainFact
            : new Game.MainFact(Material.GLAS, Texts.t("mainfact.general"), "", Content.fact(Material.GLAS, 0));
        double cw = width - 2 * PAD;
        double y = pageHead(g, gm.end, DANGER, Texts.t("summary.title"));

        // "Das nimmst du mit": the thing to remember comes first
        y += mainCard(g, PAD, y, cw, mf) + GAP;

        // one card per container: stars, what was thrown in, and two bonus facts (unlocked with 2 and 3 stars)
        double cgap = 14.4, cardW = (cw - 3 * cgap) / 4, bw = 14.4, padX = 19.2, padY = 16.8, headH = 43.2;
        double tx0 = bw + padX, textW = cardW - tx0 - padX;
        Font lab = Fonts.nunito(700, 14.4, .1), body = Fonts.nunito(400, 18), lockF = Fonts.nunito(700, 18);
        List<Summary.Card> cards = Summary.cards(gm);
        List<List<Para>> all = new ArrayList<>();
        double cardH = 0;
        for (Summary.Card c : cards) {
            List<Para> ps = new ArrayList<>();
            ps.add(new Para(null, Txt.wrap(body, c.line(), textW), false));
            for (Summary.Fact f : c.facts()) {
                if (f.open()) {
                    ps.add(new Para(Summary.factLabel(f), Txt.wrap(body, f.text(), textW), false));
                } else {
                    ps.add(new Para(null, Txt.wrap(lockF, LOCK + " " + Summary.lockedText(c.mat(), f), textW - 24), true));
                }
            }
            double h = padY + headH + padY;
            for (Para p : ps) {
                h += GAP6 + paraHeight(p);
            }
            cardH = Math.max(cardH, h);
            all.add(ps);
        }
        int ci = 0;
        for (Summary.Card c : cards) {
            Material m = c.mat();
            double x = PAD + ci * (cardW + cgap);
            fill(g, PAPER, rr(x, y, cardW, cardH, 19.2));
            fill(g, m.color, leftBorder(x, y, cardW, cardH, 19.2, bw));
            double tx = x + tx0, ty = y + padY;
            t(g, Fonts.fredoka(700, 28.8), INK, m.label(), tx, ty + 32.2, LEFT);
            // 3 stars: 25.1 wide glyph + 2.4 letter spacing each, the last one ends at the right padding
            double pitch = 1.046 * 24 + 2.4, right = x + cardW - padX;
            for (int s = 0; s < 3; s++) {
                headerStar(g, right - 3 * pitch + s * pitch + 0.523 * 24, ty + 32.2, s < c.stars());
            }
            ty += headH;
            for (Para p : all.get(ci)) {
                ty += GAP6;
                double yy = ty;
                if (p.locked()) {
                    fill(g, LOCKED_BG, rr(tx, ty, textW, paraHeight(p), 12));
                    yy += BOX;
                    for (String ln : p.lines()) {
                        t(g, lockF, LOCKED_FG, ln, tx + 12, yy + 19, LEFT);
                        yy += LINE;
                    }
                } else {
                    if (p.label() != null) {
                        t(g, lab, INK_SOFT, p.label().toUpperCase(Locale.GERMAN), tx, yy + 15.2, LEFT);
                        yy += LAB_H;
                    }
                    for (String ln : p.lines()) {
                        t(g, body, INK, ln, tx, yy + 19, LEFT);
                        yy += LINE;
                    }
                }
                ty += paraHeight(p);
            }
            ci++;
        }
        y += cardH + GAP;

        // chips
        Font cf = Fonts.nunito(700, 16.8);
        double cx = PAD, chipH = 34.8;
        for (String chip : Summary.chips(gm)) {
            double w = Txt.width(cf, chip) + 28.8;
            if (cx + w > PAD + cw && cx > PAD) {
                cx = PAD;
                y += chipH + 9.6;
            }
            fill(g, LEAF, rr(cx, y, w, chipH, chipH / 2));
            t(g, cf, PAPER, chip, cx + 14.4, y + 22.9, LEFT);
            cx += w + 9.6;
        }
        y += chipH + GAP;

        // initials: headline, three letters with arrows, hint; the buttons follow below
        Session.InitialsEntry en = ses.entry;
        t(g, Fonts.nunito(700, 19.2), PAPER, Texts.t("summary.initials_title"), PAD, y + 20.7, LEFT);
        y += 28.8 + 9.6;
        double colW = 62.4, btnW = 52.8, btnH = 33.6, boxH = 67.2, colGap = 12, vgap = 2.4;
        for (int i = 0; i < 3; i++) {
            double lx = PAD + i * (colW + colGap), bxm = lx + (colW - btnW) / 2;
            boolean on = i == en.index && !en.saved;
            final int idx = i;
            RoundRectangle2D up = rr(bxm, y, btnW, btnH, 9.6), down = rr(bxm, y + btnH + vgap + boxH + vgap, btnW, btnH, 9.6);
            fill(g, LEAF, up);
            fill(g, PAPER, triangle(bxm + btnW / 2, y + btnH / 2 + 1.5, true));
            fill(g, LEAF, down);
            fill(g, PAPER, triangle(bxm + btnW / 2, y + btnH + vgap + boxH + vgap + btnH / 2 + 0.5, false));
            fill(g, on ? TIGER : PAPER, rr(lx, y + btnH + vgap, colW, boxH, 14.4));
            t(g, Fonts.fredoka(700, 45.6), INK, String.valueOf("ABCDEFGHIJKLMNOPQRSTUVWXYZ".charAt(en.letters[i])),
                lx + colW / 2, y + btnH + vgap + 50.4, CENTER);
            if (!dry) {
                hotspot(g, up.getBounds2D(), () -> {
                    en.index = idx;
                    en.letters[idx] = (en.letters[idx] + 1) % 26;
                });
                hotspot(g, down.getBounds2D(), () -> {
                    en.index = idx;
                    en.letters[idx] = (en.letters[idx] + 25) % 26;
                });
                hotspot(g, new Rectangle2D.Double(lx, y + btnH + vgap, colW, boxH), () -> en.index = idx);
            }
        }
        y += btnH + vgap + boxH + vgap + btnH + 9.6;
        t(g, Fonts.nunito(400, 16.8), PAPER_DIM, Texts.t("summary.initials_hint"), PAD, y + 18.1, LEFT);
        y += 25.2 + GAP + 7.2;
        double w1 = button(g, PAD, y, Texts.t("summary.save"), true, false, dry ? null : ses::saveScore);
        button(g, PAD + w1 + 12, y, Texts.t("summary.skip"), false, false, dry ? null : ses::skipInitials);
        return y + BTN_H + 33.6;
    }

    /** Arrow of the letter buttons (the ▲ / ▼ glyphs of the web page: 11 wide, 9.4 high). */
    private static Path2D triangle(double cx, double cy, boolean up) {
        double hw = 5.5, h = 9.4, s = up ? -1 : 1;
        Path2D.Double p = new Path2D.Double();
        p.moveTo(cx, cy + s * h / 2);
        p.lineTo(cx - hw, cy - s * h / 2);
        p.lineTo(cx + hw, cy - s * h / 2);
        p.closePath();
        return p;
    }

    /** Draws a button (big = orange, otherwise outlined); both kinds are 48 px high like in the web page; returns its width. */
    private double button(Graphics2D g, double x, double y, String label, boolean big, boolean selected, Runnable action) {
        Font f = big ? Fonts.fredoka(700, 24) : Fonts.nunito(700, 18);
        double w = Txt.width(f, label) + (big ? 52.8 : 33.6);
        RoundRectangle2D r = rr(x, y, w, BTN_H, 14.4);
        if (big) {
            fill(g, TIGER, r);
        } else {
            line(g, MOSS, 2.4, rr(x + 1.2, y + 1.2, w - 2.4, BTN_H - 2.4, 13.2));
        }
        if (selected) {
            line(g, LIME, 4.8, rr(x - 6, y - 6, w + 12, BTN_H + 12, 20.4));
        }
        t(g, f, big ? INK_DARK : PAPER, label, x + w / 2, y + (big ? 37.2 : 34.8), CENTER);
        if (action != null) {
            hotspot(g, r.getBounds2D(), action);
        }
        return w;
    }

    private void drawBoard(Graphics2D g) {
        fill(g, rgba(15, 42, 27, .97), new Rectangle2D.Double(0, 0, W, H));
        String today = LocalDate.now().format(day);
        String title = ses.boardPos >= 0 ? Texts.t("board.title_me", "rank", ses.boardPos + 1) : Texts.t("board.title");
        double y = pageHead(g, Texts.t("board.kicker", "date", today), LIME, title);
        double rowW = 768, rowH = 67.2;
        Font numF = Fonts.nunito(400, 24), nameF = Fonts.fredoka(700, 28.8, .14), scoreF = Fonts.nunito(700, 24);
        List<HighScores.Entry> list = ses.boardList;
        if (list.isEmpty()) {
            fill(g, LEAF, rr(PAD, y, rowW, rowH, 14.4));
            t(g, nameF, PAPER, Texts.t("board.empty"), PAD + 105.6, y + 44.2, LEFT);
            y += rowH + 7.2;
        }
        for (int i = 0; i < Math.min(10, list.size()); i++) {
            y = boardRow(g, PAD, y, rowW, rowH, i + 1, list.get(i), i == ses.boardPos, numF, nameF, scoreF);
        }
        if (ses.boardPos >= 10) {
            y = boardRow(g, PAD, y, rowW, rowH, ses.boardPos + 1, list.get(ses.boardPos), true, numF, nameF, scoreF);
        }
        y += GAP;   // boardRow() already added the 6 px gap after the last row; with this the buttons sit 14 + 6 px below the list
        double w1 = button(g, PAD, y, Texts.t("board.again"), true, ses.boardSel == 0, ses::startGame);
        button(g, PAD + w1 + 12, y, Texts.t("board.menu"), false, ses.boardSel == 1, ses::toMenu);
        y += BTN_H + GAP + 9.6;
        t(g, Fonts.nunito(400, 16.8), PAPER_DIM, Texts.t("board.hint"), PAD, y + 18.1, LEFT);
    }

    private double boardRow(Graphics2D g, double x, double y, double w, double h, int rank, HighScores.Entry e, boolean me,
                            Font numF, Font nameF, Font scoreF) {
        fill(g, me ? TIGER : LEAF, rr(x, y, w, h, 14.4));
        Color fg = me ? INK_DARK : PAPER;
        t(g, numF, fg, rank + ".", x + 19.2, y + 41.5, LEFT);
        t(g, nameF, fg, e.name, x + 105.6, y + 44.2, LEFT);
        t(g, scoreF, me ? INK_DARK : LIME, String.valueOf(e.score), x + w - 19.2, y + 41.5, RIGHT);
        return y + h + 7.2;
    }
}
