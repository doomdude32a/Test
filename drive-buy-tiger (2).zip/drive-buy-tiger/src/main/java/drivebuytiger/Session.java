package drivebuytiger;

import drivebuytiger.Content.Question;
import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleSupplier;

/**
 * The flow around a run: menu, intro, play, bonus question, summary (with initials), scoreboard.
 * Owns the current {@link Game}. All methods are called from the Swing event thread.
 */
public final class Session {
    public enum Phase { MENU, INTRO, PLAY, QUIZ, SUM, BOARD }

    /** The bonus questions of one run. */
    public static final class QuizRun {
        public final List<Question> qs;
        public int i, sel, ok;
        public double t, resT;
        /** null = not answered yet, otherwise whether the answer was right. */
        public Boolean res;
        /** Answer clicked with the mouse, applied in the next update. */
        public Integer pick;

        QuizRun(List<Question> qs) {
            this.qs = qs;
        }
    }

    /** The three initials being typed on the summary screen. */
    public static final class InitialsEntry {
        public final int[] letters = new int[3];
        public int index;
        public boolean saved;
    }

    public final Settings settings;
    public final HighScores scores;
    private final DoubleSupplier rnd;

    public Phase phase = Phase.MENU;
    public boolean paused;
    public double introT;
    public Game game;
    public QuizRun quiz;
    public InitialsEntry entry = new InitialsEntry();
    /** Headline of the summary ("Das nimmst du mit"), picked once when the summary opens. */
    public Game.MainFact mainFact;
    /** Scoreboard screen: 0 = "Erneut spielen", 1 = "Menü". */
    public int boardSel;
    public List<HighScores.Entry> boardList = List.of();
    public int boardPos = -1;

    public Session(Settings settings, HighScores scores) {
        this(settings, scores, Math::random);
    }

    public Session(Settings settings, HighScores scores, DoubleSupplier random) {
        this.settings = settings;
        this.scores = scores;
        this.rnd = random;
    }

    // ------------------------------------------------------------------ transitions

    public void startGame() {
        game = new Game(settings, rnd);
        mainFact = null;
        quiz = null;
        paused = false;
        phase = Phase.PLAY;
    }

    public void toMenu() {
        game = null;
        quiz = null;
        phase = Phase.MENU;
    }

    /** Pauses a running game (window lost focus, dialog opened). */
    public void pauseIfPlaying() {
        if (phase == Phase.PLAY) {
            paused = true;
        }
    }

    private void endRun() {
        int n = (int) Math.round(settings.d(Tune.QUIZ));
        if (n > 0) {
            List<Question> pool = new ArrayList<>(Content.quiz());
            List<Question> qs = new ArrayList<>();
            while (qs.size() < n && !pool.isEmpty()) {
                qs.add(pool.remove((int) Math.floor(rnd.getAsDouble() * pool.size())));
            }
            quiz = new QuizRun(qs);
            phase = Phase.QUIZ;
        } else {
            finishRun();
        }
    }

    private void finishRun() {
        entry = new InitialsEntry();
        mainFact = game.mainFact();
        phase = Phase.SUM;
    }

    public void saveScore() {
        if (entry.saved) {
            return;
        }
        StringBuilder name = new StringBuilder();
        for (int l : entry.letters) {
            name.append("ABCDEFGHIJKLMNOPQRSTUVWXYZ".charAt(l));
        }
        HighScores.Entry rec = scores.add(name.toString(), game.score);
        entry.saved = true;
        showBoard(rec);
    }

    public void skipInitials() {
        entry.saved = true;
        showBoard(null);
    }

    private void showBoard(HighScores.Entry rec) {
        phase = Phase.BOARD;
        boardSel = 0;
        boardList = scores.today();
        boardPos = rec == null ? -1 : boardList.indexOf(rec);
    }

    // ------------------------------------------------------------------ per-frame update

    public void update(double dt, Input in) {
        switch (phase) {
            case MENU -> {
                if (in.enterQ || in.actionQ) {
                    phase = Phase.INTRO;
                    introT = 0;
                }
            }
            case INTRO -> {
                introT += dt;
                if ((in.enterQ || in.actionQ) && introT > 0.3) {
                    startGame();
                }
            }
            case BOARD -> updateBoard(in);
            case QUIZ -> updateQuiz(dt, in);
            case SUM -> updateInitials(in);
            case PLAY -> {
                if (in.pauseQ) {
                    paused = !paused;
                }
                if (paused) {
                    return;
                }
                game.update(dt, in);
                if (game.over) {
                    endRun();
                }
            }
        }
    }

    private void updateQuiz(double dt, Input in) {
        QuizRun z = quiz;
        Question q = z.qs.get(z.i);
        if (z.res != null) {
            z.resT += dt;
            if (z.resT > 1.8 || (z.resT > 0.5 && (in.actionQ || in.enterQ))) {
                z.i++;
                z.res = null;
                z.resT = 0;
                z.sel = 0;
                z.t = 0;
                if (z.i >= z.qs.size()) {
                    double mult = 1 + 0.5 * z.ok / z.qs.size();
                    game.quizRes = new Game.QuizResult(z.ok, z.qs.size(), mult);
                    game.score = (int) Math.round(game.score * mult);
                    finishRun();
                }
            }
            return;
        }
        z.t += dt;
        int n = q.answers().size();
        if (in.navU) {
            z.sel = (z.sel + n - 1) % n;
        }
        if (in.navD) {
            z.sel = (z.sel + 1) % n;
        }
        if (in.actionQ || in.enterQ || z.pick != null) {
            if (z.pick != null) {
                z.sel = z.pick;
                z.pick = null;
            }
            z.res = z.sel == q.correct();
            if (z.res) {
                z.ok++;
            }
        } else if (z.t > 15) {
            z.res = false;
        }
    }

    private void updateInitials(Input in) {
        if (entry.saved) {
            return;
        }
        int[] l = entry.letters;
        if (in.navU) {
            l[entry.index] = (l[entry.index] + 1) % 26;
        }
        if (in.navD) {
            l[entry.index] = (l[entry.index] + 25) % 26;
        }
        if (in.navR) {
            entry.index = Math.min(2, entry.index + 1);
        }
        if (in.navL) {
            entry.index = Math.max(0, entry.index - 1);
        }
        if (in.enterQ) {
            saveScore();
        }
    }

    private void updateBoard(Input in) {
        if (in.navL || in.navU) {
            boardSel = 0;
        }
        if (in.navR || in.navD) {
            boardSel = 1;
        }
        if (in.enterQ || in.actionQ) {
            if (boardSel == 0) {
                startGame();
            } else {
                toMenu();
            }
        }
    }
}
