package drivebuytiger;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The SQL scripts {@code db/schema.sql} and {@code db/seed.sql}: where to find them and how to cut them into statements.
 *
 * <p>Looked up in this order: the folder {@code db} next to the jar, the folder {@code db} of the working directory,
 * and finally the copy that is bundled in the jar. So a text can be changed by editing {@code db/seed.sql}, no rebuild needed.
 */
final class SqlScript {
    private static final Pattern CONTENT_VERSION = Pattern.compile("'content_version'\\s*,\\s*'(\\d+)'");

    private SqlScript() {}

    /** The text of a script and a short description of where it was found. */
    record Source(String text, String origin) {}

    static Source load(String name) throws IOException {
        Path dir = jarFolder();
        if (dir != null) {
            Path f = dir.resolve("db").resolve(name);
            if (Files.isRegularFile(f)) {
                return new Source(read(f), f.toString());
            }
        }
        Path local = Path.of("db", name);
        if (Files.isRegularFile(local)) {
            return new Source(read(local), local.toAbsolutePath().toString());
        }
        try (InputStream in = SqlScript.class.getResourceAsStream("/db/" + name)) {
            if (in != null) {
                return new Source(clean(new String(in.readAllBytes(), StandardCharsets.UTF_8)), "bundled in the jar (db/" + name + ")");
            }
        }
        throw new IOException("db/" + name + " was not found (neither next to the jar nor inside it)");
    }

    /** The folder that contains drive-buy-tiger.jar, or null when the classes are not run from a jar. */
    private static Path jarFolder() {
        try {
            Path p = Path.of(SqlScript.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            return Files.isRegularFile(p) ? p.toAbsolutePath().getParent() : null;
        } catch (Exception e) {
            return null;
        }
    }

    private static String read(Path file) throws IOException {
        return clean(Files.readString(file, StandardCharsets.UTF_8));
    }

    /** Drops a byte order mark, which some editors put in front of UTF-8 files. */
    private static String clean(String s) {
        return s.startsWith("﻿") ? s.substring(1) : s;
    }

    /** The number behind {@code 'content_version'} in the seed script, or -1. */
    static int contentVersion(String seed) {
        for (String st : split(seed)) {
            Matcher m = CONTENT_VERSION.matcher(st);
            if (m.find()) {
                return Integer.parseInt(m.group(1));
            }
        }
        return -1;
    }

    /** Cuts a script into statements at {@code ;} (not inside 'quotes'); comments ({@code --} and block comments) are dropped. */
    static List<String> split(String script) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        int n = script.length();
        boolean inText = false;
        for (int i = 0; i < n; i++) {
            char c = script.charAt(i);
            if (inText) {
                cur.append(c);
                if (c == '\'') {
                    if (i + 1 < n && script.charAt(i + 1) == '\'') {
                        cur.append('\'');
                        i++;
                    } else {
                        inText = false;
                    }
                }
            } else if (c == '\'') {
                inText = true;
                cur.append(c);
            } else if (c == '-' && i + 1 < n && script.charAt(i + 1) == '-') {
                while (i + 1 < n && script.charAt(i + 1) != '\n') {
                    i++;
                }
            } else if (c == '/' && i + 1 < n && script.charAt(i + 1) == '*') {
                int end = script.indexOf("*/", i + 2);
                i = end < 0 ? n : end + 1;
            } else if (c == ';') {
                flush(out, cur);
            } else {
                cur.append(c);
            }
        }
        flush(out, cur);
        return out;
    }

    private static void flush(List<String> out, StringBuilder cur) {
        String s = cur.toString().strip();
        if (!s.isEmpty()) {
            out.add(s);
        }
        cur.setLength(0);
    }
}
