package drivebuytiger;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.font.LineMetrics;
import java.awt.geom.Path2D;
import java.util.ArrayList;
import java.util.List;

/**
 * Text drawing like the HTML canvas: alignment, "middle" baseline, outlined text and word wrap.
 * Characters that the bundled fonts lack are drawn with a system font; the subscript two in "CO₂" is
 * drawn as a small lowered "2", and the star (★) and the padlock (🔒) are drawn as shapes, so that they look
 * the same on every system.
 */
public final class Txt {
    private Txt() {}

    public enum Align { LEFT, CENTER, RIGHT }

    public static final FontRenderContext FRC = new FontRenderContext(null, true, true);
    private static final Font FALLBACK = new Font(Font.SANS_SERIF, Font.PLAIN, 12);

    private static final int GLYPH_NONE = 0, GLYPH_STAR = 1, GLYPH_LOCK = 2;

    /** A piece of text in one font, or (glyph != 0) a symbol that is drawn as a vector shape. */
    private record Run(Font font, String text, double dy, double width, int glyph) {}

    private static List<Run> runs(Font f, String s) {
        List<Run> out = new ArrayList<>();
        if (s.isEmpty()) {
            return out;
        }
        float size = f.getSize2D();
        StringBuilder sb = new StringBuilder();
        Font cur = null;
        double curDy = 0;
        for (int i = 0; i < s.length(); ) {
            int cp = s.codePointAt(i);
            i += Character.charCount(cp);
            if (cp == 0x2605 || cp == 0x1F512) { // black star, padlock: drawn as shapes, so they look the same on every system
                flush(out, cur, sb, curDy);
                cur = null;
                curDy = 0;
                boolean star = cp == 0x2605;
                out.add(new Run(f, "", 0, size * (star ? 1.046 : 1.248), star ? GLYPH_STAR : GLYPH_LOCK)); // advance widths of the browser glyphs
                continue;
            }
            Font use = f;
            double dy = 0;
            String piece = new String(Character.toChars(cp));
            if (cp == 0x2082) { // subscript two
                use = f.deriveFont(size * 0.65f);
                dy = size * 0.2;
                piece = "2";
            } else if (!f.canDisplay(cp)) {
                use = FALLBACK.deriveFont(f.getStyle(), size);
            }
            if (cur != null && use.equals(cur) && dy == curDy) {
                sb.append(piece);
            } else {
                flush(out, cur, sb, curDy);
                cur = use;
                curDy = dy;
                sb.append(piece);
            }
        }
        flush(out, cur, sb, curDy);
        return out;
    }

    private static void flush(List<Run> out, Font font, StringBuilder sb, double dy) {
        if (font != null && sb.length() > 0) {
            String t = sb.toString();
            out.add(new Run(font, t, dy, font.getStringBounds(t, FRC).getWidth(), GLYPH_NONE));
        }
        sb.setLength(0);
    }

    public static double width(Font f, String s) {
        double w = 0;
        for (Run r : runs(f, s)) {
            w += r.width;
        }
        return w;
    }

    /** Distance from the "middle" line to the alphabetic baseline (canvas textBaseline = middle). */
    private static double middleShift(Font f) {
        LineMetrics lm = f.getLineMetrics("Hg", FRC);
        return (lm.getAscent() - lm.getDescent()) / 2.0;
    }

    private static double startX(double x, double w, Align a) {
        return a == Align.CENTER ? x - w / 2 : (a == Align.RIGHT ? x - w : x);
    }

    /**
     * Draws text. {@code y} is the alphabetic baseline, or the vertical middle if {@code middle} is true.
     */
    public static void draw(Graphics2D g, Font f, Color c, String s, double x, double y, Align a, boolean middle) {
        List<Run> rs = runs(f, s);
        double w = 0;
        for (Run r : rs) {
            w += r.width;
        }
        double bx = startX(x, w, a);
        double by = middle ? y + middleShift(f) : y;
        for (Run r : rs) {
            if (r.glyph != GLYPH_NONE) {
                glyph(g, r, bx, by, c);
            } else {
                g.setColor(c);
                g.setFont(r.font);
                g.drawString(r.text, (float) bx, (float) (by + r.dy));
            }
            bx += r.width;
        }
    }

    /** A five-pointed star with its tip pointing up. */
    static Path2D.Double starPath(double cx, double cy, double ro, double ri) {
        Path2D.Double p = new Path2D.Double();
        for (int i = 0; i < 10; i++) {
            double rad = i % 2 == 0 ? ro : ri, a = -Math.PI / 2 + i * Math.PI / 5;
            double px = cx + Math.cos(a) * rad, py = cy + Math.sin(a) * rad;
            if (i == 0) {
                p.moveTo(px, py);
            } else {
                p.lineTo(px, py);
            }
        }
        p.closePath();
        return p;
    }

    /**
     * ★ and the padlock inside a line of text: drawn as vectors with the size and position of the glyphs of the web page
     * (all values are fractions of the font size {@code u}), so that they look the same on every system.
     */
    private static void glyph(Graphics2D g, Run r, double x, double base, Color c) {
        double u = r.font.getSize2D();
        double cx = x + r.width / 2;
        if (r.glyph == GLYPH_STAR) {
            g.setColor(c);
            g.fill(starPath(cx, base - 0.44 * u, 0.51 * u, 0.51 * u * 0.43));
            return;
        }
        double lx = cx - 0.04 * u, bodyW = 0.75 * u, bodyTop = base - 0.44 * u, bodyBot = base + 0.14 * u;
        double hw = 0.22 * u, archY = base - 0.595 * u;
        Path2D.Double shackle = new Path2D.Double();
        shackle.moveTo(lx - hw, bodyTop + 0.05 * u);
        shackle.lineTo(lx - hw, archY);
        shackle.append(new java.awt.geom.Arc2D.Double(lx - hw, archY - hw, 2 * hw, 2 * hw, 180, -180, java.awt.geom.Arc2D.OPEN), true);
        shackle.lineTo(lx + hw, bodyTop + 0.05 * u);
        g.setColor(new Color(0x8DB4C2));
        g.setStroke(new BasicStroke((float) (0.15 * u), BasicStroke.CAP_BUTT, BasicStroke.JOIN_ROUND));
        g.draw(shackle);
        g.setColor(new Color(0xE2A610));
        g.fill(new java.awt.geom.RoundRectangle2D.Double(lx - bodyW / 2, bodyTop, bodyW, bodyBot - bodyTop, 0.16 * u, 0.16 * u));
        g.setColor(new Color(0x55392C));
        g.fill(new java.awt.geom.RoundRectangle2D.Double(lx - 0.085 * u, bodyTop + 0.22 * u, 0.17 * u, 0.28 * u, 0.1 * u, 0.1 * u));
    }

    /** Text with an outline (canvas strokeText + fillText), used for the floating messages. */
    public static void drawOutlined(Graphics2D g, Font f, String s, double x, double y, Align a, Color stroke, double lineWidth, Color fill) {
        List<Run> rs = runs(f, s);
        double w = 0;
        for (Run r : rs) {
            w += r.width;
        }
        double bx = startX(x, w, a);
        Path2D.Double all = new Path2D.Double();
        for (Run r : rs) {
            if (r.glyph != GLYPH_NONE) {
                bx += r.width;
                continue;
            }
            GlyphVector gv = r.font.createGlyphVector(FRC, r.text);
            Shape sh = gv.getOutline((float) bx, (float) (y + r.dy));
            all.append(sh, false);
            bx += r.width;
        }
        g.setColor(stroke);
        g.setStroke(new BasicStroke((float) lineWidth, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10f));
        g.draw(all);
        g.setColor(fill);
        g.fill(all);
    }

    /** Greedy word wrap, like the prototype. */
    public static List<String> wrap(Font f, String text, double maxW) {
        List<String> out = new ArrayList<>();
        String line = "";
        for (String w : text.split(" ")) {
            String t = line.isEmpty() ? w : line + " " + w;
            if (width(f, t) > maxW && !line.isEmpty()) {
                out.add(line);
                line = w;
            } else {
                line = t;
            }
        }
        if (!line.isEmpty()) {
            out.add(line);
        }
        return out;
    }
}
