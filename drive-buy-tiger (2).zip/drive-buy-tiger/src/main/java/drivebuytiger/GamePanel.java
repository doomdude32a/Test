package drivebuytiger;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import javax.swing.JPanel;
import javax.swing.Timer;

/** The game canvas: runs the game loop (about 65 frames per second) and forwards keyboard and mouse input. */
@SuppressWarnings("serial")
public final class GamePanel extends JPanel {
    private final Session ses;
    private final Renderer renderer;
    private final Input input = new Input();
    private final Timer timer;
    private long last = System.nanoTime();

    public GamePanel(Session session) {
        this.ses = session;
        this.renderer = new Renderer(session);
        setFocusable(true);
        setOpaque(true);
        setBackground(Palette.JUNGLE);
        setFocusTraversalKeysEnabled(false);

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                input.keyPressed(e.getKeyCode());
                e.consume();
            }

            @Override
            public void keyReleased(KeyEvent e) {
                input.keyReleased(e.getKeyCode());
                e.consume();
            }
        });
        addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                input.clear();
                ses.pauseIfPlaying();
            }
        });
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                requestFocusInWindow();
                Point2D p = renderer.toLogical(e.getX(), e.getY());
                if (!renderer.click(p.getX(), p.getY())
                    && (ses.phase == Session.Phase.MENU || ses.phase == Session.Phase.INTRO)) {
                    input.pressEnter();
                }
            }
        });
        timer = new Timer(15, e -> tick());
        timer.setCoalesce(true);
    }

    public Session session() {
        return ses;
    }

    public void start() {
        last = System.nanoTime();
        timer.start();
    }

    public void stop() {
        timer.stop();
    }

    private void tick() {
        long now = System.nanoTime();
        double dt = Math.min(0.05, (now - last) / 1e9);
        last = now;
        input.beginFrame();
        ses.update(dt, input);
        input.endFrame();
        repaint();
        Toolkit.getDefaultToolkit().sync();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        try {
            renderer.paint(g2, getWidth(), getHeight(), System.nanoTime() / 1e9);
        } finally {
            g2.dispose();
        }
    }
}
