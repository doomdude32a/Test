package drivebuytiger;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The texts of the summary screen ("Dein Ranger-Einsatz"), kept apart from the drawing so that they can be checked.
 * First the headline "Das nimmst du mit", then one card per bin with stars and two bonus facts that unlock with
 * 2 and 3 stars, then the chips and the initials for the scoreboard. The words come from the database (see {@link Texts}).
 */
final class Summary {
    private Summary() {}

    /** A bonus fact of a bin: shown when {@code open}, otherwise as a locked row that asks for {@code need} stars. */
    record Fact(int number, int need, boolean open, String text) {}

    record Card(Material mat, int stars, String line, List<Fact> facts) {}

    /** 0 stars = nothing thrown away, 1 = started, 2 = 60 % right at the first try, 3 = 90 % right (and at least 2 pieces). */
    static int stars(Game.Deposit q) {
        if (q.n == 0) {
            return 0;
        }
        double acc = (double) q.first / q.n;
        return (acc >= 0.9 && q.n >= 2) ? 3 : (acc >= 0.6 ? 2 : 1);
    }

    /** Weight text: grams below 1000, otherwise kilograms with at most one decimal. */
    static String fmtG(double g) {
        if (g >= 1000) {
            return Texts.t("unit.kg", "n", String.format(Locale.ROOT, "%.1f", g / 1000).replace(".0", ""));
        }
        return Texts.t("unit.g", "n", Math.round(g));
    }

    static String line(Game.Deposit q) {
        if (q.n == 0) {
            return Texts.t("summary.nothing");
        }
        return Texts.t(q.n == 1 ? "summary.pieces_one" : "summary.pieces_many", "n", q.n, "first", q.first);
    }

    static List<Card> cards(Game g) {
        List<Card> out = new ArrayList<>();
        for (Material m : Material.values()) {
            Game.Deposit q = g.dep.get(m);
            int st = stars(q);
            List<Fact> facts = new ArrayList<>();
            for (int i = 1; i <= 2; i++) {
                int need = i + 1; // fact 1 from 2 stars, fact 2 from 3 stars
                facts.add(new Fact(i, need, st >= need, Content.fact(m, i)));
            }
            out.add(new Card(m, st, line(q), facts));
        }
        return out;
    }

    static List<String> chips(Game g) {
        double kg = 0, co2 = 0;
        for (Game.Deposit q : g.dep.values()) {
            kg += q.g;
            co2 += q.co2;
        }
        List<String> chips = new ArrayList<>();
        chips.add(Texts.t("summary.chip.points", "score", g.score));
        if (g.quizRes != null) {
            chips.add(Texts.t("summary.chip.quiz", "ok", g.quizRes.ok(), "n", g.quizRes.n()));
        }
        chips.add(Texts.t("summary.chip.wrong", "n", g.stats.wrong));
        chips.add(Texts.t("summary.chip.weight", "weight", fmtG(kg)));
        chips.add(Texts.t("summary.chip.co2", "weight", fmtG(co2)));
        return chips;
    }

    /** Label above an unlocked bonus fact, e.g. "Bonus-Fakt 1". */
    static String factLabel(Fact f) {
        return Texts.t("summary.fact_label", "n", f.number());
    }

    /** Text of the locked row, e.g. "Bonus-Fakt 1: hol ★★ bei Glas". */
    static String lockedText(Material m, Fact f) {
        return Texts.t("summary.locked", "n", f.number(), "stars", "★".repeat(f.need()), "bin", m.label());
    }
}
