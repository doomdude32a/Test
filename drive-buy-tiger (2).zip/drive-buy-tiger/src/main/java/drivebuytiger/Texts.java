package drivebuytiger;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * All texts of the game that are not part of {@link Content}: HUD, messages, buttons, menus ... They live in the table
 * {@code ui_text} of the database (see db/seed.sql) and are loaded once by {@link Content#load(Db)}.
 *
 * <pre>
 *   Texts.t("pause.title")                                  // plain text
 *   Texts.t("fx.wrong", "pen", 50)                          // "Falsch! −{pen}" -> "Falsch! −50"
 * </pre>
 */
public final class Texts {
    private static volatile Map<String, String> texts = Map.of();
    private static final Set<String> WARNED = ConcurrentHashMap.newKeySet();

    private Texts() {}

    static void install(Map<String, String> all) {
        texts = Map.copyOf(all);
    }

    /** The text for a key. A missing key is reported once on stderr and shown as {@code [key]}. */
    public static String t(String key) {
        String s = texts.get(key);
        if (s == null) {
            if (WARNED.add(key)) {
                System.err.println("Missing text in the database (table ui_text): " + key + " - run seed.bat");
            }
            return "[" + key + "]";
        }
        return s;
    }

    /** Like {@link #t(String)}, then every {@code {name}} is replaced; the values come as name, value, name, value ... */
    public static String t(String key, Object... nameValue) {
        String s = t(key);
        if (nameValue.length == 0 || s.indexOf('{') < 0) {
            return s;
        }
        StringBuilder b = new StringBuilder(s.length() + 16);
        int i = 0;
        int n = s.length();
        while (i < n) {
            char c = s.charAt(i);
            if (c == '{') {
                int end = s.indexOf('}', i + 1);
                if (end > 0) {
                    int k = indexOfName(nameValue, s.substring(i + 1, end));
                    if (k >= 0) {
                        b.append(nameValue[k + 1]);
                        i = end + 1;
                        continue;
                    }
                }
            }
            b.append(c);
            i++;
        }
        return b.toString();
    }

    private static int indexOfName(Object[] nameValue, String name) {
        for (int k = 0; k + 1 < nameValue.length; k += 2) {
            if (name.equals(nameValue[k])) {
                return k;
            }
        }
        return -1;
    }
}
