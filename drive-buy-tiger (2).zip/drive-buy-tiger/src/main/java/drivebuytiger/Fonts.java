package drivebuytiger;

import java.awt.Font;
import java.awt.font.TextAttribute;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * The two fonts of the game, bundled in the JAR (SIL Open Font License, see /fonts):
 * Fredoka for headings and numbers, Nunito Sans for body text.
 */
public final class Fonts {
    private Fonts() {}

    private static final Map<String, Font> BASE = new HashMap<>();
    private static final Map<String, Font> CACHE = new HashMap<>();

    static {
        BASE.put("f600", load("Fredoka-SemiBold.ttf"));
        BASE.put("f700", load("Fredoka-Bold.ttf"));
        BASE.put("n400", load("NunitoSans-Regular.ttf"));
        BASE.put("n600", load("NunitoSans-SemiBold.ttf"));
        BASE.put("n700", load("NunitoSans-Bold.ttf"));
    }

    private static Font load(String file) {
        try (InputStream in = Fonts.class.getResourceAsStream("/fonts/" + file)) {
            if (in == null) {
                throw new IOException("resource not found");
            }
            return Font.createFont(Font.TRUETYPE_FONT, in);
        } catch (IOException | java.awt.FontFormatException e) {
            System.err.println("Font " + file + " could not be loaded (" + e.getMessage() + "), using SansSerif");
            return new Font(Font.SANS_SERIF, file.contains("Bold") ? Font.BOLD : Font.PLAIN, 12);
        }
    }

    /** Fredoka; weight 600 (semi-bold) or 700 (bold). */
    public static Font fredoka(int weight, double size) {
        return fredoka(weight, size, 0);
    }

    /** Fredoka with letter spacing (tracking in em, e.g. 0.14). */
    public static Font fredoka(int weight, double size, double tracking) {
        return get(weight >= 700 ? "f700" : "f600", size, tracking);
    }

    /** Nunito Sans; weight 400 (regular), 600 (semi-bold) or 700 (bold). */
    public static Font nunito(int weight, double size) {
        return nunito(weight, size, 0);
    }

    /** Nunito Sans with letter spacing (tracking in em, e.g. 0.14). */
    public static Font nunito(int weight, double size, double tracking) {
        return get(weight >= 700 ? "n700" : (weight >= 600 ? "n600" : "n400"), size, tracking);
    }

    private static synchronized Font get(String base, double size, double tracking) {
        String key = base + "/" + size + "/" + tracking;
        Font f = CACHE.get(key);
        if (f == null) {
            Map<TextAttribute, Object> a = new HashMap<>();
            a.put(TextAttribute.SIZE, (float) size);
            a.put(TextAttribute.KERNING, TextAttribute.KERNING_ON);
            if (tracking != 0) {
                a.put(TextAttribute.TRACKING, (float) tracking);
            }
            f = BASE.get(base).deriveFont(a);
            CACHE.put(key, f);
        }
        return f;
    }
}
