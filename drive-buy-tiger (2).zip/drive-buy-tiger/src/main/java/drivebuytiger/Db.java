package drivebuytiger;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * One SQLite database (a file or purely in memory) with a few small helpers. Everything that reads or writes the
 * database goes through this class. Only basic JDBC calls are used, so any SQLite JDBC driver works.
 *
 * <p>Where the file is: {@code ~/.drive-buy-tiger/drive-buy-tiger.db} (folder: {@code -Ddbt.dir=...},
 * complete file name: {@code -Ddbt.db=...}). The tables are created and filled by {@link Seeder}.
 */
public final class Db implements AutoCloseable {
    /** Turns the current row of a result set into an object. */
    @FunctionalInterface
    public interface RowMapper<T> {
        T map(ResultSet rs) throws SQLException;
    }

    /** A block of work that runs in one transaction. */
    @FunctionalInterface
    public interface Work<T> {
        T run(Db db) throws SQLException;
    }

    public static final String FILE_NAME = "drive-buy-tiger.db";

    private final Connection conn;
    private final String name;

    private Db(Connection conn, String name) {
        this.conn = conn;
        this.name = name;
    }

    // ------------------------------------------------------------------ opening

    /** Folder for the data of the game: {@code -Ddbt.dir=...} or {@code ~/.drive-buy-tiger}. */
    public static Path dataDir() {
        String custom = System.getProperty("dbt.dir");
        if (custom != null && !custom.isBlank()) {
            return Path.of(custom);
        }
        return Path.of(System.getProperty("user.home"), ".drive-buy-tiger");
    }

    /** The database file of the game: {@code -Ddbt.db=...} or {@code <data folder>/drive-buy-tiger.db}. */
    public static Path defaultFile() {
        String custom = System.getProperty("dbt.db");
        if (custom != null && !custom.isBlank()) {
            return Path.of(custom);
        }
        return dataDir().resolve(FILE_NAME);
    }

    /** Opens (and creates, if it does not exist yet) a database file. */
    public static Db open(Path file) throws SQLException {
        Path abs = file.toAbsolutePath();
        try {
            Path parent = abs.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
        } catch (IOException e) {
            throw new SQLException("Cannot create the folder of " + abs + ": " + e.getMessage(), e);
        }
        return connect("jdbc:sqlite:" + abs, abs.toString());
    }

    /** An empty database that lives in memory only (gone when closed). */
    public static Db memory() throws SQLException {
        return connect("jdbc:sqlite::memory:", "memory");
    }

    private static Db connect(String url, String name) throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException | LinkageError e) { // LinkageError: the driver is there, but slf4j-api.jar (which it needs) is not
            throw new SQLException("The SQLite driver is missing or incomplete. Put sqlite-jdbc.jar and slf4j-api.jar into the folder 'lib' next to drive-buy-tiger.jar. (" + e + ")", e);
        }
        Connection c = DriverManager.getConnection(url);
        Db db = new Db(c, name);
        db.exec("PRAGMA foreign_keys = ON");
        db.exec("PRAGMA busy_timeout = 4000");
        return db;
    }

    /** Where the data lives, for messages: the file name or "memory". */
    public String where() {
        return name;
    }

    @Override
    public synchronized void close() {
        try {
            conn.close();
        } catch (SQLException ignored) {
            // nothing left to do
        }
    }

    // ------------------------------------------------------------------ helpers

    private static void bind(PreparedStatement ps, Object[] params) throws SQLException {
        for (int i = 0; i < params.length; i++) {
            Object p = params[i];
            int k = i + 1;
            if (p instanceof String s) {
                ps.setString(k, s);
            } else if (p instanceof Integer n) {
                ps.setInt(k, n);
            } else if (p instanceof Long n) {
                ps.setLong(k, n);
            } else if (p instanceof Double x) {
                ps.setDouble(k, x);
            } else if (p instanceof Boolean b) {
                ps.setInt(k, b ? 1 : 0);
            } else {
                throw new SQLException("Unsupported parameter type: " + (p == null ? "null" : p.getClass().getName()));
            }
        }
    }

    /** Runs one statement without parameters (DDL, PRAGMA, one line of a script). */
    public synchronized void exec(String sql) throws SQLException {
        try (Statement st = conn.createStatement()) {
            st.execute(sql);
        }
    }

    /** INSERT / UPDATE / DELETE with {@code ?} parameters (String, Integer, Long, Double, Boolean); returns the number of rows. */
    public synchronized int update(String sql, Object... params) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            bind(ps, params);
            return ps.executeUpdate();
        }
    }

    /** SELECT: all rows, mapped one by one. */
    public synchronized <T> List<T> query(String sql, RowMapper<T> mapper, Object... params) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            bind(ps, params);
            try (ResultSet rs = ps.executeQuery()) {
                List<T> out = new ArrayList<>();
                while (rs.next()) {
                    out.add(mapper.map(rs));
                }
                return out;
            }
        }
    }

    /** SELECT that returns at most one row (null if there is none). */
    public <T> T queryOne(String sql, RowMapper<T> mapper, Object... params) throws SQLException {
        List<T> rows = query(sql, mapper, params);
        return rows.isEmpty() ? null : rows.get(0);
    }

    /** First column of the first row as text, or null. */
    public String text(String sql, Object... params) throws SQLException {
        return queryOne(sql, rs -> rs.getString(1), params);
    }

    /** Number of rows of a table. */
    public int count(String table) throws SQLException {
        Integer n = queryOne("SELECT COUNT(*) FROM " + table, rs -> rs.getInt(1));
        return n == null ? 0 : n;
    }

    /** Runs the work as one transaction: everything or nothing. */
    public synchronized <T> T transaction(Work<T> work) throws SQLException {
        boolean auto = conn.getAutoCommit();
        conn.setAutoCommit(false);
        try {
            T result = work.run(this);
            conn.commit();
            return result;
        } catch (SQLException | RuntimeException e) {
            try {
                conn.rollback();
            } catch (SQLException suppressed) {
                e.addSuppressed(suppressed);
            }
            throw e;
        } finally {
            conn.setAutoCommit(auto);
        }
    }
}
