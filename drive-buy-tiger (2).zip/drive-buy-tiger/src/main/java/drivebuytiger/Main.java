package drivebuytiger;

import java.nio.file.Path;
import java.util.Arrays;
import java.util.Locale;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * Drive Buy Tiger: collect waste in the jungle, scan it, sort it into the right bin and don't get caught by the tigers.
 *
 * <p>All texts, items, quiz questions and slider defaults, the scoreboard and the saved slider values live in one SQLite file,
 * {@code ~/.drive-buy-tiger/drive-buy-tiger.db} (folder: {@code -Ddbt.dir=/some/folder}, file: {@code -Ddbt.db=/some/file.db}).
 * It is created and filled on the first start; {@code java -jar drive-buy-tiger.jar --seed} (see {@link Seeder}) fills it again.
 */
public final class Main {
    private Main() {}

    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("--seed")) {
            System.exit(Seeder.run(Arrays.copyOfRange(args, 1, args.length), System.out, System.err));
            return;
        }
        Db db;
        try {
            Path file = Db.defaultFile().toAbsolutePath();
            db = Db.open(file);
            Seeder.ensureCurrent(db);
            Legacy.importIfNeeded(db, file.getParent());
            Content.load(db);
        } catch (Exception | LinkageError e) {
            fatal(e);
            return;
        }
        Runtime.getRuntime().addShutdownHook(new Thread(db::close));
        System.setProperty("apple.awt.application.name", Texts.t("win.title"));
        Settings settings = new Settings(db);
        HighScores scores = new HighScores(db);
        SwingUtilities.invokeLater(() -> {
            lookAndFeel();
            GameWindow window = new GameWindow(settings, scores);
            window.setVisible(true);
            window.focusGame();
        });
    }

    /** The database is needed for every text, so this one message cannot come from it. */
    private static void fatal(Throwable e) {
        Path file = Db.defaultFile();
        String msg = "Drive Buy Tiger konnte die Datenbank nicht öffnen oder füllen.\n\nDatei: " + file + "\nGrund: " + e.getMessage()
            + "\n\nTipps: Ordner 'lib' mit sqlite-jdbc.jar und slf4j-api.jar neben drive-buy-tiger.jar? "
            + "Mit seed.bat --reset (seed.sh --reset) wird die Datenbank neu angelegt.";
        System.err.println(msg);
        e.printStackTrace();
        try {
            JOptionPane.showMessageDialog(null, msg, "Drive Buy Tiger", JOptionPane.ERROR_MESSAGE);
        } catch (java.awt.HeadlessException ignored) {
            // no screen: the message above went to the console
        }
        System.exit(1);
    }

    private static void lookAndFeel() {
        try {
            String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
            if (os.contains("win") || os.contains("mac")) {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } else {
                UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
            }
        } catch (Exception ignored) {
            // keep the default look and feel
        }
    }
}
