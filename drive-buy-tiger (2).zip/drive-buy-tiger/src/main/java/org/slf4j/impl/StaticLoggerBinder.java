package org.slf4j.impl;

import org.slf4j.ILoggerFactory;
import org.slf4j.helpers.NOPLoggerFactory;
import org.slf4j.spi.LoggerFactoryBinder;

/**
 * Binds slf4j-api (which the SQLite driver needs) to "no logging". Without a binder slf4j prints three warning lines
 * on every start. This is what the small slf4j-nop jar contains, so nothing else has to be downloaded.
 */
public final class StaticLoggerBinder implements LoggerFactoryBinder {
    /** Every binder of slf4j 1.7 declares the API version it was written for. */
    public static String REQUESTED_API_VERSION = "1.7.16";

    private static final StaticLoggerBinder SINGLETON = new StaticLoggerBinder();

    private final ILoggerFactory factory = new NOPLoggerFactory();

    private StaticLoggerBinder() {}

    public static StaticLoggerBinder getSingleton() {
        return SINGLETON;
    }

    @Override
    public ILoggerFactory getLoggerFactory() {
        return factory;
    }

    @Override
    public String getLoggerFactoryClassStr() {
        return NOPLoggerFactory.class.getName();
    }
}
