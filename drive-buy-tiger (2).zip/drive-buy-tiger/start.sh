#!/usr/bin/env bash
# Starts Drive Buy Tiger (macOS and Linux). Needs Java 17 or newer.
cd "$(dirname "$0")" || exit 1

if ! command -v java >/dev/null 2>&1; then
  echo "Java was not found. Please install a JDK or JRE 17 or newer (see README.md)." >&2
  exit 1
fi

if [ ! -f drive-buy-tiger.jar ]; then
  echo "drive-buy-tiger.jar is missing, building it first ..."
  ./build.sh || exit 1
fi

exec java -jar drive-buy-tiger.jar "$@"
